# CHANGE LOG

## [1.1.0] 2018-12-05
### Fixes
- updated to Bootstrap 4
- updated to Angular 6
- added online documentation
- changed the datepicker

## [1.0.1] 2017-12-05
### Fixes
- update package.json
- fixed checkboxes in regular forms
- fixed wizard

## [1.0.0] 2017-06-27
### Initial Release
