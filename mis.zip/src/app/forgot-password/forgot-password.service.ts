import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class ForgotPasswordService {
    constructor(private http: HttpClient) { }

    resetPassword(forgotObj: any) {
        return this.http.post(environment.BASE_URL + "api/v1/users/change_password_from_recovery",
            {
                "password": forgotObj.password,
                "password2": forgotObj.password2,
                "token": forgotObj.token
            })
    }
}