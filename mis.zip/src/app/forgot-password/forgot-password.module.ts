import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ForgotPasswordRoutes } from './forgot-password.routing';
import { ForgotPasswordRoutingModule } from './forgot-password-routing.module';
import { ForgotPasswordComponent } from './forgot-password.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(ForgotPasswordRoutes),
    ForgotPasswordRoutingModule
  ],
  declarations: []
})
export class ForgotPasswordModule { ForgotPasswordComponent }