import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ForgotPasswordService } from './forgot-password.service';
import { Title } from '@angular/platform-browser';
import { environment } from '../../environments/environment';
import swal from 'sweetalert2';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  focus1;
  showPasswordError: boolean = false;
  showCPasswordError: boolean = false;
  passwordErrorMsg: String = '';
  forgotObj = {
    password: '',
    password2: '',
    token: ''
  };

  constructor(private forgotPasswordService: ForgotPasswordService,
    private _router: Router) { }

  ngOnInit() {
    console.log(window.location.href)
    let fullURL = window.location.href;
    let array = fullURL.split("/");
    console.log('Token: ', array[(array.length - 1)]);
    this.forgotObj.token = array[(array.length - 1)];
  }

  onResetClicked() {
    console.log('onResetClicked');
    var pattern = new RegExp(/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{6,19}$/);
    if (pattern.test(this.forgotObj.password)) {
      if (this.forgotObj.password === this.forgotObj.password2) {
        this.showPasswordError = false;
        this.showCPasswordError = false;
        this.forgotPasswordService.resetPassword(this.forgotObj).subscribe(res => {
          swal({
            title: "Password Changed!",
            text: "Try to login using new password",
            buttonsStyling: false,
            confirmButtonClass: "btn btn-success",
            type: "success"
          }).then((result) => {
            if (result.value) {
              this._router.navigate(['/login']);
            }
          })
        },
          err => {
            swal({
              type: 'warning',
              html: err.error._error_message.replace("Username", "Email") + ". Submit your email to reset password and try again.",
              confirmButtonClass: 'btn btn-success',
              buttonsStyling: false
            })
          }
        );
      } else {
        this.showPasswordError = false;
        this.showCPasswordError = true;
        this.passwordErrorMsg = '*Password does not matches';
      }
    } else {
      this.showPasswordError = true;
      this.showCPasswordError = false;
      this.passwordErrorMsg = '*Minimum 6 characters - should contain at least one capital letter, one numeric character and  one special character';
    }
  }
}