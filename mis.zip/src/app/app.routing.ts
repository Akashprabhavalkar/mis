import { Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { AuthLayoutComponent } from './layouts/auth/auth-layout.component';
import { ProjectsComponent } from './projects/projects.component';
import { AssetsComponent } from './assets/assets.component';
import { IssuesComponent } from './issues/issues.component';
import { LocationsComponent } from './locations/locations.component';
import { ReportsComponent } from './reports/reports.component';
import { UsersComponent } from './users/users.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';


export const AppRoutes: Routes = [{
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
}/*, {
    path: 'projects',
    component: ProjectsComponent,
    pathMatch: 'full',
}, {
    path: 'assets',
    component: AssetsComponent,
    pathMatch: 'full',
}, {
    path: 'compliances',
    component: CompliancesComponent,
    pathMatch: 'full',
}, {
    path: 'issues',
    component: IssuesComponent,
    pathMatch: 'full',
}, {
    path: 'accidents',
    component: AccidentsComponent,
    pathMatch: 'full',
}, {
    path: 'locations',
    component: LocationsComponent,
    pathMatch: 'full',
}, {
    path: 'reports',
    component: ReportsComponent,
    pathMatch: 'full',
}, {
    path: 'users',
    component: UsersComponent,
    pathMatch: 'full',
}, {
    path: 'profile',
    component: ProfileComponent,
    pathMatch: 'full',
}*/, {
    path: 'login',
    component: LoginComponent,
    pathMatch: 'full'
}, {
    path: 'register',
    component: RegisterComponent,
    pathMatch: 'full'
},{
    path: 'change-password/:token',
    component: ForgotPasswordComponent,
    pathMatch: 'full'
}, {
    path: '',
    component: AdminLayoutComponent,
    children: [{
        path: '',
        loadChildren: './dashboard/dashboard.module#DashboardModule',
        canActivate: [AuthGuard]
    }, {
        path: 'components',
        loadChildren: './components/components.module#ComponentsModule',
        canActivate: [AuthGuard]
    }, {
        path: 'forms',
        loadChildren: './forms/forms.module#Forms',
        canActivate: [AuthGuard]
    }, {
        path: 'tables',
        loadChildren: './tables/tables.module#TablesModule',
        canActivate: [AuthGuard]
    }, {
        path: 'maps',
        loadChildren: './maps/maps.module#MapsModule',
        canActivate: [AuthGuard]
    }, {
        path: 'charts',
        loadChildren: './charts/charts.module#ChartsModule',
        canActivate: [AuthGuard]
    }, {
        path: 'calendar',
        loadChildren: './calendar/calendar.module#CalendarModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './userpage/user.module#UserModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './timeline/timeline.module#TimelineModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './projects/projects.module#ProjectsModule',
        canActivate: [AuthGuard]
    }/*, {
        path: '',
        loadChildren: './projects/add-project/add-project.module#AddProjectModule'
    }*/, {
        path: '',
        loadChildren: './assets/assets.module#AssetsModule',
        canActivate: [AuthGuard]
    }, /*{
        path: '',
        loadChildren: './compliances/compliances.module#CompliancesModule',
        canActivate: [AuthGuard]
    },*/ {
        path: '',
        loadChildren: './issues/issues.module#IssuesModule',
        canActivate: [AuthGuard]
    }, /*{
        path: '',
        loadChildren: './accidents/accidents.module#AccidentsModule',
        canActivate: [AuthGuard]
    },*/ {
        path: '',
        loadChildren: './locations/locations.module#LocationsModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './reports/reports.module#ReportsModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './kpi-report/kpi-reports.module#KPIReportsModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './users/users.module#UsersModule',
        canActivate: [AuthGuard]
    }, {
        path: '',
        loadChildren: './profile/profile.module#ProfileModule',
        canActivate: [AuthGuard]
    }/*, {
        path: '',
        loadChildren: './login/login.module#LoginModule'
    }*/, {
        path: '',
        loadChildren: './widgets/widgets.module#WidgetsModule',
        canActivate: [AuthGuard]
    }]
}, {
    path: '',
    component: AuthLayoutComponent,
    children: [{
        path: 'pages',
        loadChildren: './pages/pages.module#PagesModule',
        canActivate: [AuthGuard]
    }]
},
{
    path: '**',
    component: RegisterComponent
}
];
