import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { APP_BASE_HREF } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

import { AppComponent } from './app.component';

import { SidebarModule } from './sidebar/sidebar.module';
import { FixedPluginModule } from './shared/fixedplugin/fixedplugin.module';
import { FooterModule } from './shared/footer/footer.module';
import { NavbarModule } from './shared/navbar/navbar.module';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { AuthLayoutComponent } from './layouts/auth/auth-layout.component';
import { AppRoutes } from './app.routing';
import { ProjectsComponent } from './projects/projects.component';
import { ProjectService } from './projects/project.service';
// import { startsWithPipe } from './projects/add-project/customstart.pipes';
import { ExponentialStrengthPipe } from './projects/add-project/exponential-strength.pipes';
import { AssetsComponent } from './assets/assets.component';
import { AssetsService } from './assets/assets.service';
import { IssuesComponent } from './issues/issues.component';
import { IssueService } from './issues/issue.service';
import { LocationsComponent } from './locations/locations.component';
import { ReportsComponent } from './reports/reports.component';
import { ReportsService } from './reports/reports.service';
import { KPIReportsService } from './kpi-report/kpi-reports.service';
import { UsersComponent } from './users/users.component';
import { UserService } from './users/user.service';
import { ProfileComponent } from './profile/profile.component';
import { ProfileService } from './profile/profile.service';
import { LoginComponent } from './login/login.component';
import { LoginService } from './login/login.service';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ForgotPasswordService } from './forgot-password/forgot-password.service';
import { RegisterComponent } from './register/register.component';
import { RegisterService } from './register/register.service';
import { DashboardService } from './dashboard/dashboard.service';

@NgModule({
    imports: [
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forRoot(AppRoutes),
        NgbModule.forRoot(),
        HttpModule,
        SidebarModule,
        NavbarModule,
        FooterModule,
        FixedPluginModule,
        HttpClientModule,
        NgxDaterangepickerMd.forRoot()
    ],
    providers: [
        LoginService,
        ProjectService,
        RegisterService,
        ProfileService,
        UserService,
        IssueService,
        AssetsService,
        ReportsService,
        KPIReportsService,
        DashboardService,
        ForgotPasswordService,
        {provide: LocationStrategy, useClass: HashLocationStrategy}],
    declarations: [
        AppComponent,
        AdminLayoutComponent,
        AuthLayoutComponent,
        ExponentialStrengthPipe,
        // startsWithPipe,
        // ProjectsComponent,
        // AssetsComponent,
        // IssuesComponent,
        // LocationsComponent,
        // ReportsComponent,
        // UsersComponent,
        // ProfileComponent,
        LoginComponent,
        RegisterComponent,
        ForgotPasswordComponent,
        // KpiReportComponent
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }
