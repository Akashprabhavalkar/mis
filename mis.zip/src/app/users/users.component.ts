import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import swal from 'sweetalert2';

declare var $: any;

declare interface DataTable {
  dataRows: string[][];
}

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  public dataTable: DataTable;
  users: any;
  allUsers: any;
  isActive: String;
  userType;
  search_user = '';
  isGetUserList = false;

  constructor(private _router: Router,
    private userService: UserService,
    private titleService: Title) {

  }

  ngOnInit() {
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    this.userType = user_data.custom_role;
    localStorage.setItem('page_title', 'Users');
    this.titleService.setTitle('Users - Asset Management Tool');
    this.getUsers();
    this.dataTable = {
      dataRows: []
    };
  }

  getUsers() {
    this.userService.getUsers().subscribe(res => {
      this.users = res;
      // this.dataTable.dataRows = this.users;
      this.dataTable = {
        dataRows: []
      };
      this.users = res;
      this.allUsers = res;
      this.dataTable.dataRows = this.users;
      this.isGetUserList = true;
    },
      err => {
          this.isGetUserList = true;
      }
    );
  }
  searchUsers(){
      if (this.search_user != '') {
          this.users = this.allUsers.filter((item) => {
              return ((item.full_name.toLowerCase().indexOf(this.search_user.toLowerCase()) > -1));
          })
          this.dataTable.dataRows = this.users;
      } else {
          this.users = this.allUsers;
          this.dataTable.dataRows = this.users;
      }
  }

  onEditUser(user: any) {
    this._router.navigate(['/user'], { queryParams: { user: user.id } });
  }

  onIsActiveChanged(event: any, user: any, i: any) {
    if (user.is_active) {
      this.userService.changeUserPermission(user, event.target.checked).subscribe(res => {
        this.users = res;
        this.dataTable.dataRows = this.users;
        this.getUsers();
      },
        err => {
        }
      );
    } else {
      this.userService.changeUserPermission(user, event.target.checked).subscribe(res => {
        this.users = res;
        this.dataTable.dataRows = this.users;
        this.getUsers();
      },
        err => {
        }
      );
    }
  }
  clearText() {
      this.users = this.allUsers;
      this.dataTable.dataRows = this.users;
      this.search_user = '';
  }

  onDeleteUser(user: any) {

  }

  ngAfterViewInit() {
    $('#datatable2').DataTable({
      "bFilter": false,
      "bPaginate": false,
      "bInfo": false,
      responsive: true,
      "language": {
        emptyTable: null,
        loadingRecords: null,
        zeroRecords: null
      }
    });
  }
}

/*
swal({
        title: 'Active User',
        text: "Are you sure, you want to active this user?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonClass: 'btn btn-success',
        cancelButtonClass: 'btn btn-danger',
        confirmButtonText: 'Active',
        buttonsStyling: false
      }).then((result) => {
        if (result.value) {
          this.userService.changeUserPermission(user, !user.is_active).subscribe(res => {
            this.users = res;
            this.dataTable.dataRows = this.users;
            this.getUsers();
          },
            err => {
            }
          );
        }
      })
*/