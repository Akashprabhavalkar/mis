import { Routes } from '@angular/router';

import { UsersComponent } from './users.component';
import { AddUserComponent } from './add-user/add-user.component';
import { PermissionsComponent } from './permissions/permissions.component';

export const UsersRoutes: Routes = [{
    path: 'users',
    children: [{
        path: '',
        component: UsersComponent
    },
    {
        path: 'permissions',
        component: PermissionsComponent
    }]
},{
    path: 'user',
    children: [{
        path: '',
        component: AddUserComponent
    }]
},{
    path: 'permissions',
    children: [{
        path: '',
        component: PermissionsComponent
    }]
}];