import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { JWBootstrapSwitchModule } from 'jw-bootstrap-switch-ng2';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TagInputModule } from 'ngx-chips';
import { FormsModule } from '@angular/forms';

import { UsersComponent } from './users.component';
import { UsersRoutingModule } from './users-routing.module';
import { UsersRoutes } from './users.routing';
import { AddUserComponent } from './add-user/add-user.component';
import { PermissionsComponent } from './permissions/permissions.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(UsersRoutes),
    UsersRoutingModule,
    TagInputModule,
    JWBootstrapSwitchModule,
    NgbModule,
    CommonModule,
    FormsModule,
    FormsModule
  ],
  declarations: [UsersComponent, AddUserComponent, PermissionsComponent]
})
export class UsersModule { }