import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../../projects/project.service';

declare var require: any
declare var $:any;

@Component({
    moduleId: module.id,
    selector: 'permissions-cmp',
    templateUrl: 'permissions.component.html'
})

export class PermissionsComponent implements OnInit{
    projectList: any;
    roleList: any;
    permissionList: any;
    projectId: any;
    inspection_add: boolean = false;
    maintenance_add: boolean = false;
    test_add: boolean = false;
    accidents_add: boolean = false;
    accidents_update: boolean = false;
    reports_download: boolean = false;

    constructor(private projectService: ProjectService) {
  
    }

    ngOnInit() {
      this.getProjects();
    }

    getProjects() {
        this.projectService.getProjects().subscribe(res => {
          this.projectList = res;
          this.getAllRoles(res[0]);
        },
          err => {
          }
        );
      }

    getAllRoles(project) {
      this.roleList = [];
      this.projectService.getRoles(project.id).subscribe(res => {
        this.roleList = res;
        this.getPermissions(res[0])
      },
        err => {
        }
      );
    }

    getPermissions(role) {
      console.log("getPermissions")
      this.permissionList = [];
      this.projectService.getPermissions(role.id).subscribe(res => {
        this.permissionList = res['permissions'];
        console.log(this.permissionList)
        this.inspection_add = this.permissionList.includes('add_inspections');
        this.maintenance_add = this.permissionList.includes('modify_maintenance_and_repair');
        this.test_add = this.permissionList.includes('add_test_and_investigations');
        this.accidents_add = this.permissionList.includes('add_accidents');
        this.accidents_update = this.permissionList.includes('modify_accidents');
        this.reports_download = this.permissionList.includes('export_reports');
      },
        err => {
        }
      );
    }

    onChange(){
      console.log("onChange")
    }

    onProjectSelected(selectedProject: any) {
        const optionIndex = selectedProject.selectedIndex;
        this.getAllRoles(this.projectList[optionIndex])
    }

    onRoleSelected(selectedRole: any) {
      console.log("onRoleSelected")
      const optionIndex = selectedRole.selectedIndex;
        this.getPermissions(this.roleList[optionIndex])
    }
}
