import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UserService } from '.././user.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import swal from 'sweetalert2';

declare interface User {
  text?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  number?: number;
  url?: string;
  idSource?: string;
  idDestination?: string;
}

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  isUpdateUser: boolean = false;
  sub: any;
  userId: any;
  public register: User;
  public login: User;
  public typeValidation: User;

  showNameError: boolean = true;
  showMobileError: boolean = true;
  showEmailError: boolean = true;
  showAddressError: boolean = true;
  showAadharError: boolean = true;
  showPasswordError: boolean = true;
  showCPasswordError: boolean = true;
  passwordErrorMsg = '*Invalid password';

  user = {
    id: "",
    email: "",
    full_name: "",
    password: "",
    cpassword: "",
    type: "public",
    username: "",
    accepted_terms: true,
    mobile_no: "",
    aadhaar_no: "",
    address: ""
  };

  ngOnInit() {
    this.sub = this.route
      .queryParams
      .subscribe(params => {
        this.userId = +params['user'] || 0;
        if (this.userId == 0) {
          this.isUpdateUser = false;
          localStorage.setItem('page_title', 'Add User');
          this.titleService.setTitle('Add User - Asset Management Tool');
        } else {
          localStorage.setItem('page_title', 'Update User Details');
          this.titleService.setTitle('Update User Details - Asset Management Tool');
          this.isUpdateUser = true;
          console.log('userId: ', this.userId);
          this.userService.getUser(String(this.userId)).subscribe(res => {
            console.log("user details ", res);
            this.user.id = res['id'];
            this.user.email = res['email'];
            this.user.full_name = res['full_name'];
            this.user.password = res['password'];
            this.user.cpassword = res['cpassword'];
            this.user.username = res['username'];
            this.user.mobile_no = res['mobile_no'];
            this.user.aadhaar_no = res['aadhaar_no'];
            this.user.address = res['address'];
          },
            err => {
              console.log(err);
            }
          );
        }
      });
    this.route
      .queryParams
      .subscribe(params => {
        console.log('user: ', params);
      });
    this.register = {
      email: '',
      password: '',
      confirmPassword: ''
    }
    this.login = {
      email: '',
      password: ''
    }
    this.typeValidation = {
      text: '',
      email: '',
      idSource: '',
      idDestination: '',
      url: ''
    }
  }

  constructor(private titleService: Title,
    private userService: UserService,
    private _router: Router,
    private route: ActivatedRoute) {

  }

  /*save(model: User, isValid: boolean) {
    // call API to save customer
    if (isValid) {
      console.log(model, isValid);
    }
  }
  save1(model: User, isValid: boolean) {
    // call API to save customer
    if (isValid) {
      console.log(model, isValid);
    }
  }
  save2(model: User, isValid: boolean) {
    // call API to save customer
    if (isValid) {
      console.log(model, isValid);
    }
  }*/

  onSubmit(value: any): void {
    console.log(value);
  }

  onRegister() {
    this.showNameError = true;
    this.showMobileError = true;
    this.showEmailError = true;
    this.showAddressError = true;
    this.showAadharError = true;
    this.showPasswordError = true;
    this.showCPasswordError = true;
    if (this.user.full_name.length >= 2 && /^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/.test(this.user.full_name)) {
      if (this.user.mobile_no.length == 10 && /^\d+$/.test(this.user.mobile_no) && (this.user.mobile_no.startsWith("9") || this.user.mobile_no.startsWith("8") || this.user.mobile_no.startsWith("7"))) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (re.test(String(this.user.email).toLowerCase())) {
          if (this.user.address.length >= 2) {
            if (/^\d+$/.test(this.user.aadhaar_no) && this.user.aadhaar_no.length == 12) {
              if (this.isUpdateUser) {
                this.processUserUpdate();
              } else {
                this.processRegistration();
              }
            } else
              this.showAadharError = false;
          } else
            this.showAddressError = false;
        } else
          this.showEmailError = false;
      } else
        this.showMobileError = false;
    } else
      this.showNameError = false;
  }

  processUserUpdate() {
    this.userService.updateUserDetails(this.user).subscribe(res => {
      swal({
        type: 'success',
        html: 'User Details updated successfully.',
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      }).then((result) => {
        if (result.value) {
          this._router.navigate(['/users']);
          console.log('ok clicked');
        }
      })
    },
      err => {
        console.log(err);
        swal({
          type: 'warning',
          html: err.error._error_message,
          confirmButtonClass: 'btn btn-success',
          buttonsStyling: false
        })
      }
    );
  }

  processRegistration() {
    var pattern = new RegExp(/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{6,19}$/);
    if (pattern.test(this.user.password)) {
      if (this.user.password === this.user.cpassword) {
        this.userService.registerUser(this.user).subscribe(res => {
          console.log("POST Request is successful ", res);
          swal({
            title: "Registration Successful!",
            text: "",
            buttonsStyling: false,
            confirmButtonClass: "btn btn-success",
            type: "success"
          }).then((result) => {
            if (result.value) {
              this._router.navigate(['/users']);
              console.log('ok clicked');
            }
          })
        },
          err => {
            console.log(err);
            swal({
              type: 'warning',
              html: err.error._error_message.replace("Username", "Email"),
              confirmButtonClass: 'btn btn-success',
              buttonsStyling: false
            })
          }
        );
      } else
        this.showCPasswordError = false;
    } else {
      this.showPasswordError = false;
      this.passwordErrorMsg = '*Minimum 6 characters - should contain at least one capital letter, one numeric character and  one special character';
    }
  }
}