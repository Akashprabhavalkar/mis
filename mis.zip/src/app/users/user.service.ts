import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class UserService {
    constructor(private http: HttpClient) { }

    registerUser(user: any) {
        return this.http.post(environment.BASE_URL + "api/v1/auth/register",
            {
                "email": user.email,
                "full_name": user.full_name,
                "password": user.password,
                "type": "public",
                "username": user.email,
                "mobile_no": user.mobile_no,
                "aadhaar_no": user.aadhaar_no,
                "address": user.address,
                accepted_terms: true
            }
        )
    }

    getUsers() {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/users", options)
    }

    getUser(id: string) {
        return this.http.get(environment.BASE_URL + "api/v1/users/" + id)
    }

    updateUserDetails(userDetails: any) {
        var payload = {
            id: userDetails.id,
            full_name: userDetails.full_name,
            username: userDetails.username,
            address: userDetails.address,
            read_new_terms: true,
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/users/" + userDetails.id, payload, options)
    }

    changeUserPermission(user: any, is_active: boolean) {
        var payload = {
            is_active: is_active,
            username: user.username,
            read_new_terms: true,
            address: user.address
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/users/" + user.id, payload, options)
    }
}