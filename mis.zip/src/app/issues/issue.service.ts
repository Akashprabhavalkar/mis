import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class IssueService {
    constructor(private http: HttpClient) {}

    addIssue(issueObj: any) {
        var payload = {
            issue_id: issueObj.issue_id,
            description: issueObj.description,
            chainage_from: issueObj.chainage_from,
            chainage_to: issueObj.chainage_to,
            chainage_side: issueObj.chainage_side,
            issue_category: issueObj.issue_category,
            issue_subcategory: issueObj.issue_subcategory,
            quantity: issueObj.quantity,
            unit_of_measurement: issueObj.unit_of_measurement,
            target_date: issueObj.target_date,
            issue_status: issueObj.issue_status,
            assigned_to: issueObj.assigned_to,
            reported_by: issueObj.reported_by,
            created_date: issueObj.created_date,
            project_id: issueObj.project_id,
            project: issueObj.project_id,
            raised: issueObj.raised_by,
            type_id: 'Issue',
            subject: 'Test',
            treatment: issueObj.treatment,
            inspection_category: issueObj.inspection_category,
            closed_by_id: '',
            status_name: 'Open',
            priority: issueObj.priority,
            violation_risk_category: issueObj.violation_risk_category,
            contractor: issueObj.contractor,
            report_submitted: issueObj.report_submitted
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/issue-type-issues?project=" + issueObj.project_id, payload, options)
    }

    addIssueCustomAttribute(issueObj: any) {
        var payload = {
            name:"Raised By",
            description: "Issue Raised By",
            project: issueObj.project_id,
            order: 1,
            type: "text"
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/issue-custom-attributes", payload, options)
    }


    getRaisedByUserList() {
        let options = {  };
        return this.http.post(environment.BASE_URL + "media/raised_user_list.json", {}, options)
    }


    addAccident(accidentObj: any, projectId: any) {
        var payload = {
            accident_date: accidentObj.accident_date,
            accident_time: accidentObj.accident_time,
            chainage_from: accidentObj.chainage_from,
            chainage_to: accidentObj.chainage_to,
            chainage_side: accidentObj.chainage_side,
            accident_nature: accidentObj.accident_nature,
            accident_classification: accidentObj.accident_classification,
            accident_causes: accidentObj.accident_causes,
            road_feature: accidentObj.road_feature,
            road_condition: accidentObj.road_condition,
            intersection_type: accidentObj.intersection_type,
            weather_condition: accidentObj.weather_condition,
            vehicle_responsible: accidentObj.vehicle_responsible,
            affected_persons_fatal: accidentObj.affected_persons_fatal,
            affected_persons_grievous: accidentObj.affected_persons_grievous,
            affected_persons_minor: accidentObj.affected_persons_minor,
            affected_persons_non_injured: accidentObj.affected_persons_non_injured,
            animals_killed: accidentObj.animals_killed,
            help_provided: accidentObj.help_provided,
            description: '',
            project_id: projectId,
            project: projectId,
            type_id: 'Accident',
            subject: 'Test'
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/accident-type-issues", payload, options)
    }

    addInvestigation(investigationObj: any, projectId: any) {
        var payload = {
            investigation_description: investigationObj.description,
            investigation_date: investigationObj.date,
            investigation_chainage_from:  investigationObj.chainage_from,
            investigation_chainage_to: investigationObj.chainage_to,
            investigation_chainage_side: investigationObj.chainage_side,
            asset_name: investigationObj.asset_name,
            test_name: investigationObj.test_name,
            test_specifications: investigationObj.test_specifications,
            desirable: investigationObj.desirable,
            acceptable: investigationObj.acceptable,
            frequency: investigationObj.frequency,
            image_url: investigationObj.los_image,
            testing_method: investigationObj.testing_method,
            project_id: projectId,
            project: projectId,
            type_id: 'Investigation',
            subject: 'Test'
        };
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/investigation-type-issues", payload, options)
    }

    getUsers(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/memberships?project=" + projectId, options)
    }

    getContractors(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/memberships/contractor?project=" + projectId, options)
    }


    getIssues(projectId: String, issueType: String, typeId: any, status: any, isPending: any, isRegisterCompliance: any, statusId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        if (status != '')
            if (status == 'Open')
                if(isPending)
                    return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId + "&status__name=Pending", options)
                else
                    if(isRegisterCompliance)
                        return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId + "&status=" + statusId, options)
                    else
                        return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId, options)
            else
                if(isRegisterCompliance)
                    return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId + "&status=" + statusId, options)
                else
                    return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId, options)
        else
            return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId, options)
    }

    getIssueTypes(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-types/" + projectId, options)
    }

    uploadIssueAttachmentFile(fileToUpload: File, object_id: any, projectId: any, issueType : any) {
        let headers = new HttpHeaders({
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        const formData: FormData = new FormData();
        formData.append('attached_file', fileToUpload, fileToUpload.name);
        formData.append('object_id', object_id.toString());
        formData.append('project', projectId);
        if(issueType == 'Compliances'){
            formData.append('description', issueType);
        }
        return this.http.post(environment.BASE_URL + "api/v1/issues/attachments", formData, { headers: headers })
    }
    addWatchers(issueId: String, version: String, watchers: any) {
        var payload = {
            watchers: watchers,
            version: version
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.patch(environment.BASE_URL + "api/v1/issues/" + issueId, payload, options)
    }

    getIssueDetails(issueId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issues/" + issueId, options)
    }

    getIssueAttachments(projectId: String, issueId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issues/attachments?object_id=" + issueId + "&project=" + projectId, options)
    }
//    getIssueWatchers(projectId: String, issueId: String) {
//        let headers = new HttpHeaders({
//            'Content-Type': 'application/json',
//            'Authorization': localStorage.getItem('auth_token')
//        });
//        let options = { headers: headers };
//        return this.http.get(environment.BASE_URL + "api/v1/issues/"+ issueId +"/watchers", options)
//    }

    deleteAttachment(attachmentId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.delete(environment.BASE_URL + "api/v1/issues/attachments/" + attachmentId, options)
    }

    updateIssueStatus(projectId: any, version: any, subject: String, status_name: String, issueId: String, memberId: any) {
        var payload = {
            project: projectId,
            version: version,
            subject: subject,
            status_name: status_name,
            assigned_to: memberId
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/issue-type-issues/" + issueId, payload, options)
    }

    updateIssueAssignedTO(projectId: any, version: any, subject: String, status_name: String, issueId: String, memberId: any) {
        var payload = {
            project: projectId,
            version: version,
            subject: subject,
            status_name: status_name,
            assigned_to: memberId
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1//" + issueId, payload, options)
    }

    updateIssue(projectId: any, version: any, subject: String, issueId: String, issueObj: any, issueType: String) {
        var payload = {
            issue_id: issueObj.issue_id,
            description: issueObj.description,
            chainage_from: issueObj.chainage_from,
            chainage_to: issueObj.chainage_to,
            chainage_side: issueObj.chainage_side,
            issue_category: issueObj.issue_category,
            issue_subcategory: issueObj.issue_subcategory,
            quantity: issueObj.quantity,
            unit_of_measurement: issueObj.unit_of_measurement,
            target_date: issueObj.target_date,
            issue_status: issueObj.issue_status,
            assigned_to: issueObj.assigned_to,
            reported_by: issueObj.reported_by,
            created_date: issueObj.created_date,
            project_id: issueObj.project_id,
            project: issueObj.project_id,
            type_name: 'Issue',
            assigned_to_extra_info: issueObj.assigned_to_extra_info,
            subject: 'Test',
            treatment: issueObj.treatment,
            version: version,
            status_name: issueObj.status_name,
            inspection_category: issueObj.inspection_category,
            compliance_is_update: issueObj.compliance_is_update,
            closed_by_id: '',
            contractor: issueObj.contractor,
            daily_output_achieved: issueObj.daily_output_achieved,
        }
        if(issueType == 'Compliances'){
            if(issueObj.status_name == 'Closed'){
                var user_data = JSON.parse(localStorage.getItem('user_data')) || {};
                payload['compliance_is_update'] = true;
                payload['closed_by_id'] = user_data['id'] || '';
            }
            payload['compliance_description'] = issueObj.complianceDescription;
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/issue-type-issues/" + issueId, payload, options)
    }

    updateAccident(projectId: any, version: any, subject: String, issueId: String, accidentObj: any) {
        var payload = {
            accident_date: accidentObj.accident_date,
            accident_time: accidentObj.accident_time,
            chainage_from: accidentObj.chainage_from,
            chainage_to: accidentObj.chainage_to,
            chainage_side: accidentObj.chainage_side,
            accident_nature: accidentObj.accident_nature,
            accident_classification: accidentObj.accident_classification,
            accident_causes: accidentObj.accident_causes,
            road_feature: accidentObj.road_feature,
            road_condition: accidentObj.road_condition,
            intersection_type: accidentObj.intersection_type,
            weather_condition: accidentObj.weather_condition,
            vehicle_responsible: accidentObj.vehicle_responsible,
            affected_persons_fatal: accidentObj.affected_persons_fatal,
            affected_persons_grievous: accidentObj.affected_persons_grievous,
            affected_persons_minor: accidentObj.affected_persons_minor,
            affected_persons_non_injured: accidentObj.affected_persons_non_injured,
            animals_killed: accidentObj.animals_killed,
            help_provided: accidentObj.help_provided,
            description: '',
            project_id: projectId,
            project: projectId,
            type_name: 'Accident',
            subject: 'Test',
            status_name: 'Open',
            version: accidentObj.version
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/accident-type-issues/" + issueId, payload, options)
    }
    updateInvestigation(projectId: any, version: any, subject: String, issueId: String, investigationObj: any) {
        var payload = {
            investigation_description: investigationObj.description,
            investigation_date: investigationObj.date,
            investigation_chainage_from:  investigationObj.chainage_from,
            investigation_chainage_to: investigationObj.chainage_to,
            investigation_chainage_side: investigationObj.chainage_side,
            asset_name: investigationObj.asset_name,
            test_name: investigationObj.test_name,
            test_specifications: investigationObj.test_specifications,
            desirable: investigationObj.desirable,
            acceptable: investigationObj.acceptable,
            frequency: investigationObj.frequency,
            image_url: investigationObj.los_image,
            testing_method: investigationObj.testing_method,
            project_id: projectId,
            project: projectId,
            type_id: 'Investigation',
            subject: 'Test',
            status_name: 'Open',
            version: investigationObj.version,
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/investigation-type-issues/" + issueId, payload, options)
    }

    getIssueStatusTypes(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-statuses?project=" + projectId, options)
    }

    getIssueTypeId(projectId: any, type: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-types?name=" + type + "&project=" + projectId, options)
    }

    getKPIPriority(defect_type: String){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/kpi/priority?performance_indicator=" + defect_type)
    }

    approveInspection(issueObj: any, issueId){
        var payload = {
            "is_approved": issueObj.is_approved,
            "approve_comment": issueObj.approve_comment
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/issues/approve?issue=" +issueId, payload)
    }

    getCustomAttributes(projectId : any){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-custom-attributes?project=" + projectId, options)
    }

    addCustomAttributeValue(attributeId : any, attributeValue : any, issueId : any){
        var payload = { 
            "attributes_values" : {
                [attributeId] : attributeValue
            },
            "version" : 1,
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.patch(environment.BASE_URL + "api/v1/issues/custom-attributes-values/" + issueId, payload, options);
    }

    getCustomAttributeValue(issueId : any){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issues/custom-attributes-values/" + issueId, options);
    }
}