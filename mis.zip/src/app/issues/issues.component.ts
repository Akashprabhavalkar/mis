import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { IssueService } from './issue.service';
import { forkJoin, Subject } from 'rxjs';

declare var $: any;

declare interface DataTable {
  dataRows: string[];
}

@Component({
  selector: 'app-issues',
  templateUrl: './issues.component.html',
  styleUrls: ['./issues.component.css']
})
export class IssuesComponent implements OnInit {
  issueType: String = '';
  isIssuesAvailable: boolean = false;
  isPending: boolean = false;
  isRegisterCompliance: boolean = false;
  statusId: String = '';
  sub: any;
  projectId: any;
  pageNo : number;
  issueTypeObj: any;
  public dataTable: DataTable;
  issues: any;
  issuesLength : any;
  pageChangeEvent : Subject<number> = new Subject();
  customAttributeSubs : any = [];
  startPage : number = 0;
  endPage : number = 9;

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private issueService: IssueService) {
  }

  ngOnInit() {

    this.pageChangeEvent.subscribe( data => {
      this.pageNo = data;
      this.startPage = this.pageNo * 10 - 10;
      this.endPage = this.pageNo * 10 - 1;
      if(this.endPage > this.issues.length - 1){
        this.endPage = this.issues.length - 1;
      }
      for(let i = this.startPage ; i <= this.endPage ; i++){
          this.getIssueCustomAttributes(i);
      }
      this.getCustomAttributesValues();
    });

    this.sub = this.route
      .queryParams
      .subscribe(params => {
        this.projectId = +params['project'] || 0;
        this.issueType = params['type'] || '';
        this.isPending = (params['isPending']=='true'? true: false) || false;
        this.isRegisterCompliance = (params['isRegisterCompliance']=='true'? true: false) || false;
        this.statusId = params['statusId'] || '';
        switch (this.issueType) {
          case 'Issues':
            localStorage.setItem('page_title', 'Inspections');
            this.titleService.setTitle('Inspections - Asset Management Tool');
            this.dataTable = {
              dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Issue', 'Open');
            break;
          case 'Compliances':
            localStorage.setItem('page_title', 'Maintenance and Repair');
            this.titleService.setTitle('Maintenance and Repair - Asset Management Tool');
            this.dataTable = {
              dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Issue', 'Closed');
            break;
          case 'Accidents':
            localStorage.setItem('page_title', 'Accidents');
            this.titleService.setTitle('Accidents - Asset Management Tool');
            this.dataTable = {
              dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Accident', 'Open');
            break;
          case 'Investigations':
            localStorage.setItem('page_title', 'Test And Investigations');
            this.titleService.setTitle('Test And Investigations - Asset Management Tool');
            this.dataTable = {
              dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Investigation', 'Open');
            break;
        }
      });
  }
  getProjectTitle() {
    let projectTitle = localStorage.getItem('project_title') || '';
    return projectTitle;
  }

  getIssues(typeId: any, status: any) {
      this.issueService.getIssues(this.projectId.toString(), this.issueType, typeId, status, this.isPending, this.isRegisterCompliance, this.statusId).subscribe(res => {
      this.dataTable = {
        dataRows: []
      };
      this.issues = res;
      this.issuesLength = this.issues.length;
      this.dataTable.dataRows = this.issues;
      this.dataTable.dataRows.forEach((item, index) => {
        this.dataTable.dataRows[index]['created_date'] = item['created_date'].substring(0, 10);
      });
      for(let i = this.startPage ; i <= this.endPage ; i++){
          this.getIssueCustomAttributes(i);
      }
      this.getCustomAttributesValues();
    },
      err => {
      }
    );
  }

  getIssueCustomAttributes(index : number){
    let issue = this.issues[index];
    this.customAttributeSubs[index] = this.issueService.getCustomAttributeValue(issue['id']);
  }

  getCustomAttributesValues(){
    let currentPageData = [];
    for(let i = this.startPage ; i <= this.endPage ; i++){
      currentPageData.push(this.customAttributeSubs[i]);
    }
    forkJoin(currentPageData).subscribe(data => {
      for(let i = 0 ; i < data.length ; i++){
        let customAttribute = data[i]['attributes_values'];
        let customAttributeKey;
        if(Object.keys(customAttribute).length > 0){
          customAttributeKey = Object.keys(customAttribute)[0];
          if(customAttributeKey && customAttribute[customAttributeKey] == "nhai"){
            this.issues[i + this.startPage].raised_by = customAttribute[customAttributeKey].toUpperCase();
          }
          else if(customAttributeKey && customAttribute[customAttributeKey] != "nhai"){
            this.issues[i + this.startPage].raised_by = customAttribute[customAttributeKey][0].toUpperCase() + customAttribute[customAttributeKey].substr(1).toLowerCase();
          }
          else if(!customAttributeKey){
            this.issues[i + this.startPage].raised_by = "-";
          }
        }
        else{
          this.issues[i + this.startPage].raised_by = "-";
        }
        this.dataTable.dataRows[i + this.startPage] = this.issues[i + this.startPage];      
      }
    });
  }

  getIssueTypeId(projectId, type, status) {
    this.issueService.getIssueTypeId(projectId, type).subscribe((res:any) => {
      this.issueTypeObj = res;
      if (res.length > 0) {
        this.getIssues(this.issueTypeObj[0].id, status);
      } else {
        this.dataTable = {
            dataRows: []
        };
        this.issues = [];
      }
    },
      err => {
      }
    );
  }
  

  onAddClicked(type: String) {
    this._router.navigate(['/issue'], { queryParams: { project: this.projectId, type: type } });
  }

  openIssueDetails(issueObj: any) {
    this._router.navigate(['/issue'], { queryParams: { project: this.projectId, type: this.issueType, id: issueObj.id } });
  }

  openAccidentDetails(issueObj: any) {
    this._router.navigate(['/issue'], { queryParams: { project: this.projectId, type: this.issueType, id: issueObj.id } });
  }
  openInvestigationDetails(issueObj: any) {
    this._router.navigate(['/issue'], { queryParams: { project: this.projectId, type: this.issueType, id: issueObj.id } });
  }

  ngAfterViewInit() {
    var columnIndex = 1;
    if(this.issueType == "Investigations"){
        columnIndex = 5;
    }
    $('#datatable').DataTable({
      "bFilter": false,
      "bInfo": false,
      responsive: true,
      "language": {
        emptyTable: null,
        loadingRecords: null,
        zeroRecords: null
      },
      "order": [[ columnIndex, "desc" ]]
    });

    var table = $('#datatable').DataTable(); 
    var self = this;

    $('#datatable').on('page.dt', function() {
      self.pageChangeEvent.next(Number(table.page() + 1));
    });

    table.on('click', '.edit', function () {
      let $tr = $(this).closest('tr');
      var data = table.row($tr).data();
      alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
    });
    table.on('click', '.remove', function (e) {
      let $tr = $(this).closest('tr');
      table.row($tr).remove().draw();
      e.preventDefault();
    });
    table.on('click', '.like', function () {
      alert('You clicked on Like button');
    });
  }
}