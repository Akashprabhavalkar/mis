import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { IssueService } from '.././issue.service';
import { Location } from '@angular/common';
import swal from 'sweetalert2';

declare interface User {
  text?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  number?: number;
  url?: string;
  idSource?: string;
  idDestination?: string;
}

@Component({
  selector: 'app-create-issue',
  templateUrl: './create-issue.component.html',
  styleUrls: ['./create-issue.component.css']
})
export class CreateIssueComponent implements OnInit {
  isCompliance: boolean = false;
  isUpdateIssue: boolean = false;
  showNameError: boolean = false;
  isStatusUpdated: boolean = false;
  isLoading: boolean = false;
  isClosed: boolean = false;
  isShowMultipleAssignee: boolean = true;
  isShowThirdAssignee: boolean = true;
  fileToUpload: File = null;
  selected_chainage_side;
  issueType: String = '';
  issueId: String;
  issueResponseObj: any;
  issueAttachments = [];
  complianceAttachments = [];
  allImageExtensions = ['jpg','JPG','jpeg','JPEG','png','PNG','gif','GIF','bmp','BMP','svg','SVG'];
  sub: any;
  userList;
  contractorList;
  stayusTypes;
  public register: User;
  public login: User;
  public typeValidation: User;
  srcIssueSubTypes = [];
  issueTypeList = [];
//  testAssetCategoryList = [];
  maintenanceAssetCategoryList = [];
  testAssetList = [];
  selectedAssetList = [];
  selectedTestNameList = [];
  testNameList = [];
  issueTypeListMaster = [];
  issueSubTypeList = [];
  issueStatusTypes = [];
  issueInspectionCategories = [];
  chainageSides = [];
  accidentTypes = [];
  severityTypes = [];
  accidentNature = [];
  accidentClassification = [];
  accidentCauses = [];
  roadFeature = [];
  roadCondition = [];
  intersectionType = [];
  weatherCondition = [];
  priority = [];
  report_submitted = [];
  violationRiskCategory = [];
  dailyOutputAchieved = [];
  createIssue = {
    priority_list: [],
    issue_id: '',
    description: '',
    complianceDescription: '',
    chainage_from: '',
    chainage_to: '',
    chainage_side: '',
    issue_category: '',
    issue_subcategory: '',
    quantity: '',
    unit_of_measurement: '',
    target_date: '',
    issue_status: '',
    assigned_to: '',
    assigned_to_second: '',
    assigned_to_third: '',
    raised_by: '',
    assigned_to_name: '',
    closed_by_name: '',
    reported_by: '',
    created_date: '',
    project_id: '',
    type_id: '',
    subject: '',
    treatment: '',
    status_name: '',
    version: '',
    inspection_category: '',
    compliance_is_update: false,
    priority: '',
    approve_comment: '',
    is_approved: false,
    violation_risk_category: '',
    contractor: '',
    report_submitted: '',
    daily_output_achieved: '',
  }
  accidentObj = {
    accident_date: '',
    accident_time: '',
    chainage_from: '',
    chainage_to: '',
    chainage_side: '',
    accident_nature: '',
    accident_classification: '',
    accident_causes: '',
    road_feature: '',
    road_condition: '',
    intersection_type: '',
    weather_condition: '',
    vehicle_responsible: '',
    affected_persons_fatal: '',
    affected_persons_grievous: '',
    affected_persons_minor: '',
    affected_persons_non_injured: '',
    animals_killed: '',
    help_provided: '',
    version: ''
  }
  investigationObj = {
    description: '',
    date: '',
    time: '',
    chainage_from: '',
    chainage_to: '',
    chainage_side: '',
//    asset_category: '',
    asset_name: '',
    test_name: '',
    test_specifications: '',
    desirable: '',
    los_image: '',
    acceptable: '',
    frequency: '',
    testing_method: '',
    version: ''
  }
  raisedByList=[
    { name: "NHAI", value: "nhai"},
    { name: "Independent", value: "independent"},
    { name: "Engineer", value: "engineer"},
    { name: "Concessionaire", value: "concessionaire"},
    { name: "Contractor", value: "contractor"}
    ]
  userType;
  comment_active: boolean;
  customAttributes : any;

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private issueService: IssueService,
    private _location: Location) {}

  ngOnInit() {
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    if ((user_data.username == 'admin@gmail.com' || user_data.username == 'neelmani.katdare@safewayconcessions.com' || user_data.username == 'parmod.kumar@safewayconcessions.com' || user_data.username == 'nandan.kunal@safewayconcessions.com' || user_data.username == 'rahul.mishra@safewayconcessions.com') || (user_data.custom_role == 1 || user_data.custom_role == 3)){
      this.comment_active = true;
    }
    this.initIssues();
    this.getRaisedByListByJSON();
    this.sub = this.route
      .queryParams
      .subscribe(params => {
        this.createIssue.project_id = params['project'] || '0';
        this.issueType = params['type'] || '';
        this.issueId = params['id'] || '';
        this.getUserList();
        this.getContractorList();
        this.getIssueStatusTypes();
        switch (this.issueType) {
          case 'Issues':
            this.isCompliance = false;
            if (this.issueId == '') {
              this.isUpdateIssue = false;
              localStorage.setItem('page_title', 'Inspection');
              this.titleService.setTitle('Add Inspection - Asset Management Tool');
              this.createIssue.status_name = 'Open';
              this.retrieveProjectCustomAttributes(params['project']);
            } else {
              this.isUpdateIssue = true;
              localStorage.setItem('page_title', 'Inspection Details');
              this.titleService.setTitle('Inspection Details - Asset Management Tool');
              this.getIssueDetails();
              this.getIssueAttachments();
              this.retrieveProjectCustomAttributes(params['project']);
              this.retrieveIssueCustomAttributeValues(this.issueId);
//              this.getIssueWatchers();
            }
            break;
          case 'Compliances':
            this.isCompliance = true;
            if (this.issueId == '') {
              this.isUpdateIssue = false;
              localStorage.setItem('page_title', 'Maintenance And Repair');
              this.titleService.setTitle('Maintenance And Repair - Asset Management Tool');
            } else {
              this.isUpdateIssue = true;
              localStorage.setItem('page_title', 'Maintenance And Repair Details');
              this.titleService.setTitle('Maintenance And Repair Details - Asset Management Tool');
              this.getIssueDetails();
              this.getIssueAttachments();
            }
            break;
          case 'Accidents':
            this.isCompliance = false;
            if (this.issueId == '') {
              this.isUpdateIssue = false;
              localStorage.setItem('page_title', 'Accident');
              this.titleService.setTitle('Accident - Asset Management Tool');
            } else {
              this.isUpdateIssue = true;
              localStorage.setItem('page_title', 'Accident Details');
              this.titleService.setTitle('Accident Details - Asset Management Tool');
              this.getAccidentDetails();
            }
            break;
          case 'Investigations':
            this.isCompliance = false;
            if (this.issueId == '') {
              this.isUpdateIssue = false;
              localStorage.setItem('page_title', 'Investigation');
              this.titleService.setTitle('Investigation - Asset Management Tool');
            } else {
              this.isUpdateIssue = true;
              localStorage.setItem('page_title', 'Investigation Details');
              this.titleService.setTitle('Investigation Details - Asset Management Tool');
              this.getInvestigationDetails();
              this.getIssueAttachments();
            }
            break;
        }
      });
  }

  onApprovalSelected(approve_comment: any){
    this.createIssue.approve_comment = approve_comment;
    
  }

  getIssueDetails() {
    this.isLoading = true;
    this.issueService.getIssueDetails(this.issueId).subscribe(res => {
      this.isLoading = false;
      this.issueResponseObj = res;
      this.createIssue.issue_id = this.issueResponseObj['issue_id'];
      this.createIssue.description = this.issueResponseObj['description'];
      this.createIssue.complianceDescription = this.issueResponseObj['compliance_description'] || '';
      this.createIssue.chainage_from = this.issueResponseObj['chainage_from'];
      this.createIssue.chainage_to = this.issueResponseObj['chainage_to'];
      this.createIssue.chainage_side = this.issueResponseObj['chainage_side'];
      this.createIssue.issue_category = this.issueResponseObj['issue_category'];
      this.createIssue.issue_subcategory = this.issueResponseObj['issue_subcategory'];
      this.createIssue.quantity = this.issueResponseObj['quantity'];
      this.createIssue.unit_of_measurement = this.issueResponseObj['unit_of_measurement'];
      this.createIssue.target_date = this.issueResponseObj['target_date'];
      this.createIssue.issue_status = this.issueResponseObj['issue_status'];
      this.createIssue.status_name = this.issueResponseObj['status_name'];
      this.createIssue.priority =this.issueResponseObj['priority'];
      this.createIssue.approve_comment = this.issueResponseObj['approve_comment'];
      this.createIssue.is_approved = this.issueResponseObj['is_approved'];
      this.createIssue.priority_list = this.issueResponseObj['priority_list'];
      if(this.issueResponseObj['status_name'] == 'Closed'){
          this.isClosed = true;
      }

      for (var prior in this.createIssue.priority_list){
        this.createIssue.priority_list[prior]['priority'];
        this.priority.push(this.createIssue.priority_list[prior]['priority']);

      }
      this.createIssue.assigned_to = this.issueResponseObj['assigned_to'];
      this.createIssue.contractor = this.issueResponseObj['contractor'];
      this.createIssue.violation_risk_category = this.issueResponseObj['violation_risk_category'];
      this.createIssue.report_submitted = this.issueResponseObj['report_submitted'];
      this.createIssue.reported_by = this.issueResponseObj['reported_by'];
      this.createIssue.created_date = this.issueResponseObj['created_date'];
      this.createIssue.project_id = this.issueResponseObj['project'];
      this.createIssue.type_id = this.issueResponseObj['type_id'];
      this.createIssue.subject = this.issueResponseObj['subject'];
      this.createIssue.treatment = this.issueResponseObj['treatment'];
      this.createIssue.assigned_to_name = this.issueResponseObj['assigned_to_extra_info'].full_name_display;
      this.createIssue.closed_by_name = this.issueResponseObj['closed_by_name'];
      this.createIssue.version = this.issueResponseObj['version'];
      this.createIssue.inspection_category = this.issueResponseObj['inspection_category'];
      this.createIssue.compliance_is_update = this.issueResponseObj['compliance_is_update'];
      if(this.issueResponseObj['total_watchers']>0){
          this.isShowMultipleAssignee = true;
          this.createIssue.assigned_to_second = this.issueResponseObj['watchers'][0];
          if(this.issueResponseObj['total_watchers']>1){
              this.isShowThirdAssignee = true;
              this.createIssue.assigned_to_third = this.issueResponseObj['watchers'][1];
          }else{
              this.isShowThirdAssignee = false;
          }
      }else{
          this.isShowMultipleAssignee = false;
      }
        var inspectCatId;
        var catId;
        this.issueInspectionCategories.forEach((item, index) => {
          if (item.name == this.createIssue.inspection_category) {
            inspectCatId = item.id;
          }
        });
        this.issueTypeList = [];
        this.issueTypeListMaster.forEach((item, index) => {
          if (item.inspec_id == inspectCatId) {
            this.issueTypeList.push(item);
          }
        });
        this.issueTypeList.forEach((item, index) => {
            if (item.name == this.createIssue.issue_category) {
              catId = item.id;
            }
        });
        this.issueSubTypeList = [];
        this.srcIssueSubTypes.forEach((item, index) => {
          if (item.cat_id == catId && item.inspec_id == inspectCatId) {
            this.issueSubTypeList.push(item);
          }
        });
    },err => {});
  }

  onApprove(){
    this.createIssue.is_approved = true;
    
    this.issueService.approveInspection(this.createIssue, this.issueId).subscribe(res =>{
      swal(
        {
          title: 'Approved!',
          text: 'Approved!',
          type: 'success',
          confirmButtonClass: "btn btn-success",
          buttonsStyling: false
        }
      )
    });
  }

  getAccidentDetails() {
    this.isLoading = true;
    this.issueService.getIssueDetails(this.issueId).subscribe(res => {
      this.isLoading = false;
      this.issueResponseObj = res;
      this.accidentObj.accident_date = this.issueResponseObj['accident_date'];
      this.accidentObj.accident_time = this.issueResponseObj['accident_time'];
      this.accidentObj.chainage_from = this.issueResponseObj['chainage_from'];
      this.accidentObj.chainage_to = this.issueResponseObj['chainage_to'];
      this.accidentObj.chainage_side = this.issueResponseObj['chainage_side'];
      this.accidentObj.accident_nature = this.issueResponseObj['accident_nature'];
      this.accidentObj.accident_classification = this.issueResponseObj['accident_classification'];
      this.accidentObj.accident_causes = this.issueResponseObj['accident_causes'];
      this.accidentObj.road_feature = this.issueResponseObj['road_feature'];
      this.accidentObj.road_condition = this.issueResponseObj['road_condition'];
      this.accidentObj.intersection_type = this.issueResponseObj['intersection_type'];
      this.accidentObj.weather_condition = this.issueResponseObj['weather_condition'];
      this.accidentObj.vehicle_responsible = this.issueResponseObj['vehicle_responsible'];
      this.accidentObj.affected_persons_fatal = this.issueResponseObj['affected_persons_fatal'];
      this.accidentObj.affected_persons_grievous = this.issueResponseObj['affected_persons_grievous'];
      this.accidentObj.affected_persons_minor = this.issueResponseObj['affected_persons_minor'];
      this.accidentObj.affected_persons_non_injured = this.issueResponseObj['affected_persons_non_injured'];
      this.accidentObj.animals_killed = this.issueResponseObj['animals_killed'];
      this.accidentObj.help_provided = this.issueResponseObj['help_provided'];
      this.accidentObj.version = this.issueResponseObj['version'];
    },
      err => {
      }
    );
  }

  getInvestigationDetails() {
    this.isLoading = true;
    this.issueService.getIssueDetails(this.issueId).subscribe(res => {
      this.isLoading = false;
      this.issueResponseObj = res;
      this.investigationObj.description = this.issueResponseObj['investigation_description'];
      this.investigationObj.date = this.issueResponseObj['investigation_date'];
      this.investigationObj.chainage_from = this.issueResponseObj['investigation_chainage_from'];
      this.investigationObj.chainage_to = this.issueResponseObj['investigation_chainage_to'];
      this.investigationObj.chainage_side = this.issueResponseObj['investigation_chainage_side'];
      this.investigationObj.asset_name = this.issueResponseObj['asset_name'];
      this.onInvestigationAssetSelected(this.issueResponseObj['asset_name']);
      this.investigationObj.test_name = this.issueResponseObj['test_name'];
      this.investigationObj.test_specifications = this.issueResponseObj['test_specifications'];
      this.investigationObj.desirable = this.issueResponseObj['desirable'];
      this.investigationObj.los_image = this.issueResponseObj['image_url'];
      this.investigationObj.testing_method = this.issueResponseObj['testing_method'];
      this.investigationObj.acceptable = this.issueResponseObj['acceptable'];
      this.investigationObj.frequency = this.issueResponseObj['frequency'];
      this.investigationObj.version = this.issueResponseObj['version'];
    },
      err => {
      }
    );
  }

  getIssueAttachments() {
    this.isLoading = true;
    this.issueService.getIssueAttachments(this.createIssue.project_id, this.issueId).subscribe((res: any) => {
      this.isLoading = false;
      var newIssueAttachments = [];
      var newComplianceAttachments = [];
      res.forEach((attachmentDetails, index) => {
        var url = attachmentDetails.url;
        var extension = (/[.]/.exec(url)) ? /[^.]+$/.exec(url) : undefined;
        if (this.allImageExtensions.indexOf(extension+'')==-1){
            attachmentDetails['isFile'] = true;
        }else{
            attachmentDetails['isFile'] = false;
        }
        if (attachmentDetails.description == 'Compliances') {
            newComplianceAttachments.push(attachmentDetails);
        }else{
            newIssueAttachments.push(attachmentDetails);
        }
      });
      this.issueAttachments = newIssueAttachments;
      this.complianceAttachments = newComplianceAttachments;
    },
      err => {
      }
    );
  }

//  getIssueWatchers() {
//    this.isLoading = true;
//    this.issueService.getIssueWatchers(this.createIssue.project_id, this.issueId).subscribe(res => {
//      this.isLoading = false;
//      console.log("<<<<<<<<");
//      console.log(res);
//      console.log("<<<<<<<<");
//    },
//      err => {
//      }
//    );
//  }

retrieveProjectCustomAttributes(projectId : any){
  this.issueService.getCustomAttributes(projectId).subscribe( (res : any) => {
      let data = res;
      this.customAttributes = data.find( element => element.name = "Raised By");
      if(!this.customAttributes){
        this.issueService.addIssueCustomAttribute(this.createIssue).subscribe((res : any) => {
            let customAttributeData = {
              name: res['name'],
              description: res['description'],
              project: res['project'],
              order: res['order'],
              type: res['type']
          }
          this.customAttributes = customAttributeData;
        });
      }
  }); 
}


retrieveIssueCustomAttributeValues(issueId : any){
  this.issueService.getCustomAttributeValue(issueId).subscribe ( (res : any) => {
    let attributeId = this.customAttributes['id']
    this.createIssue['raised_by'] =  res['attributes_values'][attributeId]
  });
}

  onUpdate(issueType: String) {
    switch (issueType) {
      case 'Issues':
      case 'Compliances':
        if (this.createIssue.description == '' && issueType=='Issues') {
          this.showErrorMsg('Please enter description');
          return;
        }
        if (this.createIssue.complianceDescription == '' && issueType=='Compliances') {
          this.showErrorMsg('Please enter maintenance and repair description');
          return;
        }
        if (this.createIssue.chainage_from == '') {
          this.showErrorMsg('Please enter chainage from');
          return;
        }
        if (this.createIssue.chainage_side == '') {
          this.showErrorMsg('Please select chainage side');
          return;
        }
        if (this.complianceAttachments.length == 0 && this.fileToUpload==null && issueType=='Compliances') {
            this.showErrorMsg('Please upload attachment');
            return;
        }
        if (this.createIssue.inspection_category == '') {
          this.showErrorMsg('Please select inspection category');
          return;
        }
        if (this.createIssue.issue_category == '') {
          this.showErrorMsg('Please select asset category');
          return;
        }
        if (this.createIssue.issue_subcategory == '') {
          this.showErrorMsg('Please select performance category');
          return;
        }
        if (this.createIssue.assigned_to == '') {
          this.showErrorMsg('Please select assignee');
          return;
        }
        if (issueType=='Compliances' && !this.createIssue.compliance_is_update && this.issueResponseObj['total_watchers']!=2 && (this.createIssue.assigned_to_second != '' || this.createIssue.assigned_to_third != '')) {
          if(this.createIssue.assigned_to == this.createIssue.assigned_to_second || this.createIssue.assigned_to == this.createIssue.assigned_to_third || this.createIssue.assigned_to_second == this.createIssue.assigned_to_third){
            this.showErrorMsg('Assignee should not be duplicated');
            return;
          }
        }
       

        this.isLoading = true;
        this.issueService.updateIssue(this.createIssue.project_id, (parseInt(this.createIssue.version)), this.createIssue.subject, this.issueId, this.createIssue, issueType).subscribe(res => {
          this.isLoading = false;
          this.issueResponseObj = res;
          this.issueId = this.issueResponseObj.id;
          if (this.fileToUpload != null){
            if (issueType=='Compliances' && !this.createIssue.compliance_is_update && this.issueResponseObj['total_watchers']!=2 && (this.createIssue.assigned_to_second != '' || this.createIssue.assigned_to_third != '')) {
                var watcherList = [];
                if(this.createIssue.assigned_to_second!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_second));
                }
                if(this.createIssue.assigned_to_third!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_third));
                }
                this.addWatchers(this.issueResponseObj.id, this.issueResponseObj.version, watcherList, 'updated');
            }else{
                this.uploadAttachment(this.issueId, 'updated');
            }
          }else{
            if (issueType=='Compliances' && !this.createIssue.compliance_is_update && this.issueResponseObj['total_watchers']!=2 && (this.createIssue.assigned_to_second != '' || this.createIssue.assigned_to_third != '')) {
                var watcherList = [];
                if(this.createIssue.assigned_to_second!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_second));
                }
                if(this.createIssue.assigned_to_third!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_third));
                }
                this.addWatchers(this.issueResponseObj.id, this.issueResponseObj.version, watcherList, 'updated');
            }else{
                swal(
                  {
                    title: 'Successful!',
                    text: 'Details updated successfully',
                    type: 'success',
                    confirmButtonClass: "btn btn-success",
                    buttonsStyling: false
                  }
                ).then((result) => {
                  if (result.value) {
                    this._location.back();
                  }
                })
            }
          }
        },
          err => {
          }
        );
        break;
      case 'Accidents':
        this.isLoading = true;
        this.issueService.updateAccident(this.createIssue.project_id, (parseInt(this.createIssue.version)), this.createIssue.subject, this.issueId, this.accidentObj).subscribe(res => {
          this.isLoading = false;
          this.issueResponseObj = res;
          this.issueId = this.issueResponseObj.id;
          swal(
            {
              title: 'Successful!',
              text: 'Accident details are updated',
              type: 'success',
              confirmButtonClass: "btn btn-success",
              buttonsStyling: false
            }
          ).then((result) => {
            if (result.value) {
              this._location.back();
            }
          })
        },
          err => {
          }
        );
        break;
      case 'Investigations':
        if (this.investigationObj.description == '') {
          this.showErrorMsg('Please enter description');
          return;
        }
        if (this.investigationObj.date == '') {
          this.showErrorMsg('Please enter date');
          return;
        }
        if (this.investigationObj.time == '') {
          this.showErrorMsg('Please enter time');
          return;
        }
        if (this.investigationObj.chainage_from == '') {
          this.showErrorMsg('Please enter chainage from');
          return;
        }
        if (this.investigationObj.chainage_side == '') {
          this.showErrorMsg('Please select chainage side');
          return;
        }
//        if (this.investigationObj.asset_category == '') {
//          this.showErrorMsg('Please select asset category');
//          return;
//        }
        if (this.investigationObj.asset_name == '') {
          this.showErrorMsg('Please select asset type');
          return;
        }
        if (this.investigationObj.test_name == '') {
          this.showErrorMsg('Please select performance parameter');
          return;
        }
        this.isLoading = true;
        this.issueService.updateInvestigation(this.createIssue.project_id, (parseInt(this.createIssue.version)), this.createIssue.subject, this.issueId, this.investigationObj).subscribe(res => {
            this.isLoading = false;
            this.issueResponseObj = res;
            this.issueId = this.issueResponseObj.id;
            if (this.fileToUpload != null){
                this.uploadAttachment(this.issueId, 'updated');
            }else{
                swal(
                    {
                        title: 'Successful!',
                        text: 'Details updated successfully',
                        type: 'success',
                        confirmButtonClass: "btn btn-success",
                        buttonsStyling: false
                    }
                ).then((result) => {
                    if (result.value) {
                        this._location.back();
                    }
                });
            }
        },
            err => {
                swal({
                    type: 'warning',
                    html: err.error._error_message,
                    confirmButtonClass: 'btn btn-success',
                    buttonsStyling: false
                })
            }
        );
        break;
    }
  }
  
  onBlurChainage(fieldName, objectName){
      if(this[objectName][fieldName]==''){
          this[objectName][fieldName]='+000';
      }
  }
  onChangeChainage(fieldName, objectName){
      let oldString = this[objectName][fieldName];
      let newString = oldString.replace(/[^a-zA-Z0-9]/g,'+');
      this[objectName][fieldName] = newString;
  }

  getRaisedByListByJSON(){
    this.issueService.getRaisedByUserList().subscribe(res => {
     console.log("res=", res);
        },
          err => {
                      console.log("err=", err);
          })
  }

  onSubmit(issueType: String) {
    switch (issueType) {
      case 'Issues':
        if (this.createIssue.description == '') {
          this.showErrorMsg('Please enter description');
          return;
        }
        if (this.createIssue.chainage_from == '') {
          this.showErrorMsg('Please enter chainage from');
          return;
        }
        if (this.createIssue.chainage_side == '') {
          this.showErrorMsg('Please select chainage side');
          return;
        }
        if (this.createIssue.inspection_category == '') {
          this.showErrorMsg('Please select inspection category');
          return;
        }
        if (this.createIssue.issue_category == '') {
          this.showErrorMsg('Please select asset category');
          return;
        }
        if (this.createIssue.issue_subcategory == '') {
          this.showErrorMsg('Please select performance category');
          return;
        }
        if (this.createIssue.priority == '') {
          this.showErrorMsg('Please select KPI priority');
          return;
        }
        if (this.createIssue.assigned_to == '') {
          this.showErrorMsg('Please select assignee');
          return;
        } else if (this.createIssue.assigned_to_second != '' || this.createIssue.assigned_to_third != '') {
          if(this.createIssue.assigned_to == this.createIssue.assigned_to_second || this.createIssue.assigned_to == this.createIssue.assigned_to_third || this.createIssue.assigned_to_second == this.createIssue.assigned_to_third){
            this.showErrorMsg('Assignee should not be duplicated');
            return;
          }
        }

        this.isLoading = true;
        // this.issueService.addIssueCustomAttribute(this.createIssue).subscribe(res => {
        //   console.log("res=", res);
        // },
        //   err => {
        //               console.log("err=", err);
        //   });



        this.issueService.addIssue(this.createIssue).subscribe(res => {
          
          this.isLoading = false;
          this.issueResponseObj = res;
          this.issueId = this.issueResponseObj.id;
          if (this.fileToUpload != null){
            if(this.createIssue.assigned_to_second!='' || this.createIssue.assigned_to_third!=''){
                var watcherList = [];
                if(this.createIssue.assigned_to_second!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_second));
                }
                if(this.createIssue.assigned_to_third!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_third));
                }
                this.addWatchers(this.issueResponseObj.id, this.issueResponseObj.version, watcherList, 'added');
            }else{
                this.uploadAttachment(this.issueId, 'added');
            }
          } else {
            if(this.createIssue.assigned_to_second!='' || this.createIssue.assigned_to_third!=''){
                var watcherList = [];
                if(this.createIssue.assigned_to_second!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_second));
                }
                if(this.createIssue.assigned_to_third!=''){
                    watcherList.push(parseInt(this.createIssue.assigned_to_third));
                }
                this.addWatchers(this.issueResponseObj.id, this.issueResponseObj.version, watcherList, 'added');
            }else{
                var messageText = 'Issue has been added';
                if(this.issueType == 'Investigations'){
                    messageText = 'Report has been added';
                }
                this.issueService.addCustomAttributeValue(this.customAttributes['id'], this.createIssue['raised_by'], this.issueResponseObj.id).subscribe( data => {
                  let resKeys = Object.keys(data);
                  if(resKeys.indexOf('attributes_values') !== -1 && resKeys.indexOf('issue') !== -1 && resKeys.indexOf('version') !== -1)
                  {
                    swal(
                      {
                        title: 'Successful!',
                        text: messageText,
                        type: 'success',
                        confirmButtonClass: "btn btn-success",
                        buttonsStyling: false
                      }
                    ).then((result) => {
                      if (result.value) {
                        this._location.back();
                      }
                    });
                  }
                });
            }
          }
        },
          err => {
          }
        );
        break;
      case 'Accidents':
        this.isLoading = true;
        this.issueService.addAccident(this.accidentObj, this.createIssue.project_id).subscribe(res => {
          this.isLoading = false;
          this.issueResponseObj = res;
          this.issueId = this.issueResponseObj.id;
          swal(
            {
              title: 'Successful!',
              text: 'Accident has been added',
              type: 'success',
              confirmButtonClass: "btn btn-success",
              buttonsStyling: false
            }
          ).then((result) => {
            if (result.value) {
              this._router.navigate(['/issues'], { queryParams: { project: this.createIssue.project_id, type: 'Accidents' } });
            }
          })
        },
          err => {
          }
        );
        break;
      case 'Investigations':
        if (this.investigationObj.description == '') {
          this.showErrorMsg('Please enter description');
          return;
        }
        if (this.investigationObj.date == '') {
          this.showErrorMsg('Please enter date');
          return;
        }
        if (this.investigationObj.time == '') {
          this.showErrorMsg('Please enter time');
          return;
        }
        if (this.investigationObj.chainage_from == '') {
          this.showErrorMsg('Please enter chainage from');
          return;
        }
        if (this.investigationObj.chainage_side == '') {
          this.showErrorMsg('Please select chainage side');
          return;
        }
        if (this.fileToUpload==null) {
            this.showErrorMsg('Please upload attachment');
            return;
        }
        if (this.investigationObj.asset_name == '') {
          this.showErrorMsg('Please select asset type');
          return;
        }
        if (this.investigationObj.test_name == '') {
          this.showErrorMsg('Please select performance parameter');
          return;
        }
        this.isLoading = true;
        this.issueService.addInvestigation(this.investigationObj, this.createIssue.project_id).subscribe(res => {
            this.isLoading = false;
            this.issueResponseObj = res;
            this.issueId = this.issueResponseObj.id;
            if (this.fileToUpload != null){
                this.uploadAttachment(this.issueId, 'added');
            } else {
                swal(
                    {
                        title: 'Successful!',
                        text: 'Investigation has been added',
                        type: 'success',
                        confirmButtonClass: "btn btn-success",
                        buttonsStyling: false
                    }
                ).then((result) => {
                    if (result.value) {
                        this._router.navigate(['/issues'], {queryParams: {project: this.createIssue.project_id, type: 'Investigations'}});
                    }
                });
            }
        },err => {
            swal({
              type: 'warning',
              html: err.error._error_message,
              confirmButtonClass: 'btn btn-success',
              buttonsStyling: false
            });
        });
        break;
    }
  }

  uploadAttachment(issueId: any, msg: String) {
    this.isLoading = true;
    this.issueService.uploadIssueAttachmentFile(this.fileToUpload, this.issueId, this.createIssue.project_id, this.issueType).subscribe(res => {
      this.isLoading = false;
      var messageText = 'Issue has been ' + msg;
      if(this.issueType == 'Investigations'){
          messageText = 'Report has been ' + msg;
      }
      this.issueService.addCustomAttributeValue(this.customAttributes['id'], this.createIssue['raised_by'], this.issueResponseObj.id).subscribe( data => {
        let resKeys = Object.keys(data);
        if(resKeys.indexOf('attributes_values') !== -1 && resKeys.indexOf('issue') !== -1 && resKeys.indexOf('version') !== -1)
        {
          swal(
            {
              title: 'Successful!',
              text: messageText,
              type: 'success',
              confirmButtonClass: "btn btn-success",
              buttonsStyling: false
            }
          ).then((result) => {
            if (result.value) {
              this._location.back();
            }
          });
        }
      });
    });
  }

  addWatchers(issueId: any, version: String, watchers: any, msg: String) {
    this.isLoading = true;
    this.issueService.addWatchers(issueId, version, watchers).subscribe(res => {
      this.isLoading = false;
      if (this.fileToUpload != null){
        this.uploadAttachment(issueId, msg);
      } else {
        var messageText = 'Issue has been ' + msg;
        if(this.issueType == 'Investigations'){
            messageText = 'Report has been ' + msg;
        }
        swal(
          {
            title: 'Successful!',
            text: messageText,
            type: 'success',
            confirmButtonClass: "btn btn-success",
            buttonsStyling: false
          }
        ).then((result) => {
          if (result.value) {
            this._location.back();
          }
        })
      }
    },
      err => {
      }
    );
  }

  getUserList() {
    this.issueService.getUsers(this.createIssue.project_id).subscribe(res => {
      this.userList = res;
    },
      err => {
      }
    );
  }

  getContractorList() {
    this.issueService.getContractors(this.createIssue.project_id).subscribe(res => {
      this.contractorList = res;
    },
      err => {
      }
    );
  }

  getIssueStatusTypes() {
    this.issueService.getIssueStatusTypes(this.createIssue.project_id).subscribe((res: any) => {
      this.stayusTypes = res;
      for (let eachStatus of res) {
          if (eachStatus.slug == 'pending') {
              this.issueStatusTypes.splice(1, 0, eachStatus.name);
          }
      }
    },
      err => {
      }
    );
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  onChainageSideSelected(chainageSide: any) {
    this.createIssue.chainage_side = chainageSide;
    this.accidentObj.chainage_side = chainageSide;
    this.investigationObj.chainage_side = chainageSide;
  }

  onRoadFeatureSelected(roadFeature: any) {
    this.accidentObj.road_feature = roadFeature;
  }

  onRoadConditionSelected(roadCondition: any) {
    this.accidentObj.road_condition = roadCondition;
  }

  onAccidentNatureSelected(accidentNature: any) {
    this.accidentObj.accident_nature = accidentNature;
  }

  onAccidentClassifivationSelected(accidentClassification: any) {
    this.accidentObj.accident_classification = accidentClassification;
  }

  onAccidentCauseSelected(accidentCause: any) {
    this.accidentObj.accident_causes = accidentCause;
  }

  onAccidentIntersectionSelected(accidentIntersection: any) {
    this.accidentObj.intersection_type = accidentIntersection;
  }

  onAccidentWeatherSelected(accidentWeather: any) {
    this.accidentObj.weather_condition = accidentWeather;
  }

    userSelectionUpdated(selected_issue: String) {
    }

  userStatusUpdated(userStatusUpdated: any) {
    if (this.createIssue.approve_comment){
      this.isStatusUpdated = true;
      this.createIssue.status_name = userStatusUpdated;
      if (this.createIssue.status_name == 'Open')
        this.isCompliance = false;
      else
        this.isCompliance = true;  
    }
    else{
      console.log("----------------------this------------------->");
      this.showErrorMsg('Please approve issue');
      return;
    }
    
  }

  onIssueStatusUpdated() {
    this.issueService.updateIssueStatus(this.createIssue.project_id, (parseInt(this.createIssue.version)), this.createIssue.subject, this.createIssue.status_name, this.issueId, this.createIssue.assigned_to).subscribe(res => {
      this.isStatusUpdated = false;
      swal({
        title: "Successful!",
        text: "Status updated",
        buttonsStyling: false,
          confirmButtonClass: "btn btn-success",
        type: "success"
      }).catch(swal.noop)
    },
      err => {
        swal({
          type: 'warning',
          html: err.error._error_message,
          confirmButtonClass: 'btn btn-success',
          buttonsStyling: false
        })
      }
    );
  }

  onContractorAssigned(issueAssigned: any){
    this.createIssue.contractor = issueAssigned;
    this.issueService.updateIssueStatus(this.createIssue.project_id, (parseInt(this.createIssue.version)), this.createIssue.subject, this.createIssue.status_name, this.issueId, this.createIssue.assigned_to).subscribe(res => {
      swal({
        title: "Successful!",
        text: "Issue assigned",
        buttonsStyling: false,
        confirmButtonClass: "btn btn-success",
        type: "success"
      }).catch(swal.noop)
    },
      err => {
//        swal({
//          type: 'warning',
//          html: err.error._error_message,
//          confirmButtonClass: 'btn btn-success',
//          buttonsStyling: false
//        })
      }
    );
  }

  onIssueAssigned(issueAssigned: any) {
    this.createIssue.assigned_to = issueAssigned;
    this.issueService.updateIssueStatus(this.createIssue.project_id, (parseInt(this.createIssue.version)), this.createIssue.subject, this.createIssue.status_name, this.issueId, this.createIssue.assigned_to).subscribe(res => {
      swal({
        title: "Successful!",
        text: "Issue assigned",
        buttonsStyling: false,
        confirmButtonClass: "btn btn-success",
        type: "success"
      }).catch(swal.noop)
    },
      err => {
//        swal({
//          type: 'warning',
//          html: err.error._error_message,
//          confirmButtonClass: 'btn btn-success',
//          buttonsStyling: false
//        })
      }
    );
  }
  onIssueAssignedSecond(issueAssigned: any) {
    this.createIssue.assigned_to_second = issueAssigned;
  }
  onIssueAssignedThird(issueAssigned: any) {
    this.createIssue.assigned_to_third = issueAssigned;
  }

  onRaisedBy(raisedBy: any) {
    this.createIssue.raised_by = raisedBy;
  }

  onInspectionCategoryChanged(selectedInsCategory: any) {
    this.createIssue.inspection_category = selectedInsCategory;
    var inspectCatId;
    this.issueInspectionCategories.forEach((item, index) => {
      if (item.name == selectedInsCategory) {
        inspectCatId = item.id;
      }
    });
    this.issueTypeList = [];
    this.issueTypeListMaster.forEach((item, index) => {
      if (item.inspec_id == inspectCatId) {
        this.issueTypeList.push(item);
      }
    });
    this.createIssue.issue_category = this.issueTypeList[0].name;
    this.onIssueCategorySelected(this.createIssue.issue_category);
  }

  onIssueCategorySelected(selectedCategory: any) {
    var catId;
    var inspectCatId;
    this.issueInspectionCategories.forEach((item, index) => {
      if (item.name == this.createIssue.inspection_category) {
        inspectCatId = item.id;
      }
    });
    this.issueTypeList.forEach((item, index) => {
      if (item.name == selectedCategory) {
        this.createIssue.issue_category = item.name;
        catId = item.id;
      }
    });
    this.issueSubTypeList = [];
    this.srcIssueSubTypes.forEach((item, index) => {
      if (item.cat_id == catId && item.inspec_id == inspectCatId) {
        this.issueSubTypeList.push(item);
      }
    });
    this.createIssue.issue_subcategory = this.issueSubTypeList[0].name;
    this.onIssueSubCategorySelected(this.createIssue.issue_subcategory);
  }

  onIssueSubCategorySelected(selectedSubCategory: any) {
    var subCatId, deadlineDays;
    this.srcIssueSubTypes.forEach((item, index) => {
      if (item.name == selectedSubCategory) {
        subCatId = item.id;
        deadlineDays = item.deadline_days;
        this.createIssue.issue_subcategory = item.name;
        this.createIssue.treatment = item.treatment;
      }
    });
    var today = new Date();
    today.setDate(today.getDate() + deadlineDays);
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var y = today.getFullYear();
    // YYYY-MM-DD
    // this.createIssue.target_date = dd + '/' + mm + '/' + y;
    this.createIssue.target_date = y + '-' + mm + '-'+ dd

    this.issueService.getKPIPriority(selectedSubCategory).subscribe(res =>{
      this.priority = [];
      for (var prior in res){
        this.priority.push(res[prior]['priority']);

      }
    })


    
  }

  onRiskSelected(risk: any){
    this.createIssue.violation_risk_category = risk;
  }

  onReportSubmittedSelected(report_submitted: any){
    this.createIssue.report_submitted = report_submitted;
  }

  onoutputSubmittedSelected(output: any){
    this.createIssue.daily_output_achieved = output;
  }

  onIssuePrioritySelected(priority: any) {
    this.createIssue.priority = priority;
  }
  

  deleteAttachment(attachment: any) {
    this.issueService.deleteAttachment(attachment.id).subscribe(res => {
      swal({
        type: 'success',
        html: 'Attachment deleted.',
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      })
      this.getIssueAttachments();
    },
      err => {
      }
    );
  }

  showErrorMsg(msg: any) {
    swal({
      type: 'warning',
      html: msg,
      confirmButtonClass: 'btn btn-success',
      buttonsStyling: false
    })
  }

  initIssues() {
    var currentDateObject = new Date();
    var oldDate = currentDateObject.getDate();
    var oldMonth = currentDateObject.getMonth() + 1;
    var newDate;
    if (oldDate < 10) {
        newDate = '0' + oldDate;
    } else {
        newDate = oldDate;
    }
    var newMonth;
    if (oldMonth < 10) {
        newMonth = '0' + oldMonth;
    } else {
        newMonth = oldMonth;
    }
    var newDateString = newDate + '-' + newMonth + '-' + currentDateObject.getFullYear();
    var oldHours = currentDateObject.getHours();
    var oldMinutes = currentDateObject.getMinutes();
    var newHours;
    if (oldHours < 10) {
        newHours = '0' + oldHours;
    } else {
        newHours = oldHours;
    }
    var newMinutes;
    if (oldMinutes < 10) {
        newMinutes = '0' + oldMinutes;
    } else {
        newMinutes = oldMinutes;
    }
    var newTimeString = newHours + ':' + newMinutes;
    this.investigationObj.date = newDateString;
    this.investigationObj.time = newTimeString;
//    this.testAssetCategoryList=[
//        { id: 1, name: 'Road' },
//        { id: 2, name: 'Structures' }
//    ];
    this.testAssetList=[
        { id: 1, cat_id: 1, name: 'Flexible Pavement'},
        { id: 2, cat_id: 1, name: 'Rigid Pavement'},
        { id: 3, cat_id: 1, name: 'Road'},
        { id: 4, cat_id: 1, name: 'Pavement Marking'},
        { id: 5, cat_id: 1, name: 'Road Signs'},
        { id: 6, cat_id: 1, name: 'Kerb'},
        { id: 7, cat_id: 1, name: 'Highway Lights'},
        { id: 8, cat_id: 1, name: 'Toll Plaza Lights'},
        { id: 9, cat_id: 2, name: 'Pipe/box/slab culverts'},
        { id: 10, cat_id: 2, name: 'Bridge -Super Structure'},
        { id: 11, cat_id: 2, name: 'Bridge -Super Structure Span more than 40m'},
        { id: 12, cat_id: 2, name: 'Bridge -Super Structure Span more than 30m'},
        { id: 13, cat_id: 2, name: 'Bridge -Super Structure Span between 15 to 30m'},
        { id: 14, cat_id: 2, name: 'Bridge- substructure'},
        { id: 15, cat_id: 2, name: 'Bridge Foundations'}
    ];
    this.selectedAssetList = this.testAssetList;
    this.testNameList=[
        {id: 1, asset_id: 1, name: 'Roughness IRI', specification: 'Class I Profilometer : ASTM E950 (98) measuring Longitudinal Profile', desirable: '2000mm/km', acceptable: '3000mm/km', frequency: 'Bi-Annually', los_image: '', testing_method: 'Class I Profilometer'},
        {id: 2, asset_id: 1, name: 'Skid Number', specification: 'Class I Profilometer : ASTM E950 (98) measuring Longitudinal Profile', desirable: '60SN', acceptable: '50SN', frequency: 'Bi-Annually', los_image: '', testing_method: 'Class I Profilometer'},
        {id: 3, asset_id: 1, name: 'Rutting', specification: 'MORT&H Specification 3004.2', desirable: '<10mm for any 50 m section and/or, length of section <5m', acceptable: '<10mm for any 50 m section and/or, length of section <10m', frequency: 'Bi-Annually', los_image: '', testing_method: 'Straight Edge'},
        {id: 4, asset_id: 1, name: 'Pavement Condition Index', specification: 'IRC:82-2015', desirable: '>85', acceptable: '>70', frequency: 'Bi-Annually', los_image: '', testing_method: ''},
        {id: 5, asset_id: 1, name: 'Other Pavement Distresses', specification: 'IRC:82-2015', desirable: 'NIL', acceptable: 'NIL', frequency: 'Bi-Annually', los_image: '', testing_method: ''},
        {id: 6, asset_id: 1, name: 'Deflection/Remaining ng Life', specification: 'Falling Weight Deflectometer IRC 115: 2014', desirable: 'NIL', acceptable: 'NIL', frequency: 'Annually', los_image: '', testing_method: 'Falling Weight Deflectometer'},
        {id: 7, asset_id: 2, name: 'Roughness IRI BI', specification: 'Class I Profilometer ASTM E950 (98) :2004 and ASTM E1656 -94: 2000', desirable: '< 2200mm/km', acceptable: '3000mm/km', frequency: 'Bi-Annually', los_image: '', testing_method: 'Class I Profilometer'},
        {id: 8, asset_id: 2, name: 'Skid', specification: 'British Pendulum Tester IRC:SP:83-2008', desirable: '> 65 BPN', acceptable: '> 45 BPN', frequency: 'Bi-Annually', los_image: '', testing_method: 'British Pendulum Tester'},
        {id: 9, asset_id: 3, name: 'Availability of Safe Sight Distance', specification: 'As per IRC SP :84-2014, a minimum of safe stopping sight distance shall be available throughout.', desirable: '', acceptable: '', frequency: 'Monthly', los_image: './assets/img/LOS/Availability-of-Safe-Sight-Distance.png', testing_method: 'Manual Measurements with Odometer along with video/image backup'},
        {id: 10, asset_id: 4, name: 'Wear', specification: 'Visual Assessment as per Annexure-F of IRC:35-2015', desirable: 'NIL', acceptable: '<70% of marking remaining', frequency: 'Bi-Annually', los_image: '', testing_method: 'Visual Assessment as per Annexure-F of IRC:35-2015'},
        {id: 11, asset_id: 4, name: 'Day time Visibility', specification: 'As per Annexure-D of IRC:35-2015', desirable: 'NIL', acceptable: 'During expected life Service Time 1. Cement Road - 130mcd/m2/lux 2. Bituminous Road - 100mcd/m2/lux', frequency: 'Monthly', los_image: '', testing_method: 'As per Annexure-D of IRC:35-2015'},
        {id: 12, asset_id: 4, name: 'Night Time Visibility Dry Condition', specification: 'As per Annexure-E of IRC:35-2015', desirable: '', acceptable: '', frequency: 'Bi-Annually', los_image: './assets/img/LOS/Night-Time-Visibility-Dry-Condition.png', testing_method: 'As per Annexure-E of IRC:35-2015'},
        {id: 13, asset_id: 4, name: 'Night Time Visibility in Wet Condition', specification: 'As per Annexure-E of IRC:35-2015', desirable: 'NIL', acceptable: 'Initial and Minimum Performance for Night Visibility under wet condition (Retro reflectivity): 1.Initial 7 days Retro reflectivity: 100 mcd/m2/lux 2.Minimum Threshold Level:  100 mcd/m2/lux', frequency: 'Bi-Annually', los_image: '', testing_method: 'As per Annexure-E of IRC:35-2015'},
        {id: 14, asset_id: 4, name: 'Skid Resistance', specification: '', desirable: 'NIL', acceptable: 'Initial and Minimum performance for Skid Resistance: 1. Initial (7days): 55BPN 2. Min. Threshold: 44BPN *Note: shall be considered under urban/city traffic condition encompassing the locations like pedestrian crossings, bus bay, bus stop, cycle track intersection delineation, transverse bar markings etc Signboard should be clearly visible for the design speed of the section.', frequency: 'Bi-Annually', los_image: '', testing_method: 'As per Annexure-G of IRC:35-2015'},
        {id: 15, asset_id: 5, name: 'Shape and Position', specification: 'Shape and Position as per IRC:67- 2012.', desirable: 'NIL', acceptable: 'Signboard should be clearly visible for the design speed of the section.', frequency: 'Daily', los_image: '', testing_method: 'Visual with video/image backup'},
        {id: 16, asset_id: 5, name: 'Retro reflectivity', specification: 'Testing of each signboard using Retro Reflectivity Measuring Device. In accordance with ASTM D 4956-09.', desirable: 'NIL', acceptable: 'As per specifications in IRC:67-2012', frequency: 'Bi-Annually', los_image: '', testing_method: 'Testing of each signboard using Retro Reflectivity Measuring Device. In accordance with ASTM D 4956-09.'},
        {id: 17, asset_id: 6, name: 'Kerb Height', specification: 'As per IRC 86:1983 depending upon type of Kerb', desirable: 'NIL', acceptable: 'Use of distance measuring tape', frequency: 'Bi-Annually', los_image: '', testing_method: 'Use of distance measuring tape'},
        {id: 18, asset_id: 7, name: 'Illumination', specification: 'IRC:SP:84-2014', desirable: 'NIL', acceptable: 'Illumination: Minimum 40 Lux illumination on the road surface', frequency: 'Daily', los_image: '', testing_method: 'The illumination level shall be measured with luxmeter'},
        {id: 19, asset_id: 8, name: 'Illumination', specification: 'IRC:SP:84-2015', desirable: 'NIL', acceptable: 'Illumination Minimum 40 Lux illumination on the road surface', frequency: 'Daily', los_image: '', testing_method: 'The illumination level shall be measured with luxmeter'},
        {id: 20, asset_id: 9, name: 'Leak-proof expansion joints if any', specification: 'IRC SP:40-1993 and IRC SP:69- 2011', desirable: 'NIL', acceptable: 'No leakage through expansion joints', frequency: 'Bi-Annually', los_image: '', testing_method: 'Physical inspection of expansion joints as per IRC SP: 35- 1990 if any, for leakage strains on walls at joints.'},
        {id: 21, asset_id: 9, name: 'Spalling', specification: 'IRC SP 40-1993 and MORTH Specifications clause 2800', desirable: 'NIL', acceptable: 'Spalling of concrete not more than 0.25 sqm', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed inspection of all components of culvert as per IRC SP:35-1990 and recording the defects'},
        {id: 22, asset_id: 9, name: 'Delamination of concrete', specification: 'IRC SP 40-1993 and MORTH Specifications clause 2800', desirable: 'Delamination of concrete not more than 0.25 sq.m.', acceptable: 'NIL', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed inspection of all components of culvert as per IRC SP:35-1990 and recording the defects'},
        {id: 23, asset_id: 9, name: 'Cracks', specification: 'IRC SP 40-1993 and MORTH Specifications clause 2800 recording the defects', desirable: 'NIL', acceptable: 'Cracks wider than 0.3 mm not more than 1m aggregate length', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed inspection of all components of culvert as per IRC SP:35-1990 and recording the defects'},
        {id: 24, asset_id: 9, name: 'Protection works in good condition', specification: 'IRC: SP 40-1993 and IRC:SP:13- 2004.', desirable: 'NIL', acceptable: 'Damaged of rough stone apron or bank revetment not more than 3 sq.m, damage to solid apron (concrete apron) not more than 1 sq.m', frequency: '2 times in a year (before and after rainy season)', los_image: '', testing_method: 'Condition survey as per IRC SP:35- 1990'},
        {id: 25, asset_id: 10, name: 'Rusted reinforcement', specification: 'IRC SP: 40-1993 and MORTH Specification 1600.', desirable: 'NIL', acceptable: 'Not more than 0.25 sq.m', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed condition survey as per IRC SP: 35-1990.'},
        {id: 26, asset_id: 10, name: 'Spalling of concrete', specification: 'IIRC SP: 40-1993 and MORTH Specification 1600.', desirable: 'NIL', acceptable: 'Not more than 0.50 sq.m', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed condition survey as per IRC SP: 35-1990.'},
        {id: 27, asset_id: 10, name: 'Delamination', specification: 'IRC SP: 40-1993 and MORTH Specification 1600.', desirable: 'NIL', acceptable: 'Not more than 0.50 sq.m', frequency: 'Bi-Annually', los_image: '', testing_method: ''},
        {id: 28, asset_id: 10, name: 'Cracks wider than 0.30 mm', specification: 'IRC SP: 40-1993 and MORTH Specification 2800.', desirable: 'NIL', acceptable: 'Not more than 1m total length', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed condition survey as per IRC: SP 35-1990.'},
        {id: 29, asset_id: 10, name: 'Rainwater seepage through deck slab', specification: 'MORTH specifications 2600 & 2700.', desirable: 'NIL', acceptable: 'Leakage - nil', frequency: 'Quarterly', los_image: '', testing_method: 'Detailed condition survey as per IRC: SP 35-1990.'},
        {id: 30, asset_id: 11, name: 'Deflection due to permanent loads and live loads', specification: 'IRC SP: 51-1999.', desirable: 'NIL', acceptable: 'Within design limits.', frequency: 'Once in every 10 years', los_image: '', testing_method: 'Load test method'},
        {id: 31, asset_id: 12, name: 'Vibrations in bridge deck due to moving trucks', specification: 'AASHTO LRFD specifications', desirable: 'NIL', acceptable: 'Frequency of vibrations shall not be more than 5 Hz', frequency: 'Once in every 5 years', los_image: '', testing_method: 'Laser displacement sensors or laser vibro-meters'},
        {id: 32, asset_id: 13, name: 'Vibrations in bridge deck due to moving trucks', specification: 'AASHTO LRFD specifications', desirable: 'NIL', acceptable: 'Frequency of vibrations shall not be more than 5 Hz', frequency: 'Every 10 years', los_image: '', testing_method: 'Laser displacement sensors or laser vibro-meters'},
        {id: 33, asset_id: 14, name: 'Leakage in Expansion joints', specification: 'MORTH specifications 2600 and IRC SP: 40-1993.', desirable: 'NIL', acceptable: 'No damage to elastomeric sealant compound in strip seal expansion joint, no leakage of rain water through expansion joint in case of buried and asphalt plug and copper strip joint.', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed condition survey as per IRC SP:35-1990.'},
        {id: 34, asset_id: 14, name: 'Debris and dust in strip seal expansion joint', specification: 'MORTH specifications 2600 and IRC SP: 40-1993.', desirable: 'NIL', acceptable: 'No dust or debris in expansion joint gap.', frequency: 'Monthly', los_image: '', testing_method: 'Detailed condition survey as per IRC SP:35-1990.'},
        {id: 35, asset_id: 14, name: 'Drainage spouts', specification: 'MORTH specification 2700.', desirable: 'NIL', acceptable: 'No down take pipe missing/broken below soffit of the deck slab. No silt, debris, clogging of drainage spout collection chamber.', frequency: 'Monthly', los_image: '', testing_method: 'Detailed condition survey as per IRC SP: 35-1990.'},
        {id: 36, asset_id: 14, name: 'Cracks/spalling of concrete/rusted steel', specification: 'IRC SP: 40-1993 and MORTH specification 2800.', desirable: 'NIL', acceptable: 'No cracks, spalling of concrete and rusted steel', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed condition survey as per IRC SP: 35-1990.'},
        {id: 37, asset_id: 14, name: 'Bearings', specification: 'MORTH specification 2810 and IRC SP: 40-199.', desirable: 'NIL', acceptable: 'Delamination of bearing reinforcement not more than 5%, cracking or tearing of rubber not more than 2 locations per side, no rupture of reinforcement or rubber', frequency: 'Bi-Annually', los_image: '', testing_method: 'Detailed condition survey as per IRC SP: 35-1990.'},
        {id: 38, asset_id: 15, name: 'Scouring around foundations', specification: 'IRC SP: 40- 1993, IRC 83- 2014, MORTH specification 2500', desirable: 'NIL', acceptable: 'Scouring shall not be lower than maximum scour level for the bridge', frequency: 'Bi-Annually', los_image: '', testing_method: 'Condition survey and visual inspection as per IRC SP:35-1990'},
    ];
    this.issueStatusTypes = [
      'Open',
      'Closed'
    ];
    this.issueInspectionCategories = [
        {
            id: 1,
            name: 'Routine'
        },
        {
            id: 2,
            name: 'Close'
        },
        {
            id: 3,
            name: 'Thorough'
        }
    ]
    this.accidentTypes = [
      'Vehicle Rollover',
      'Single Car Accident',
      'Rear End Collision',
      'Crane Accidents',
      'Ladder Accidents'
    ];
    this.accidentNature = [
      'Over turning',
      'Head on collision',
      'Rear End collision',
      'Collision Brush/Side Wipe',
      'Left Turn collision',
      'Skidding',
      'Right Turn Collision',
      'Others'
    ];
    this.accidentClassification = [
      'Fatal',
      'Grievous Injury',
      'Minor Injured',
      'Non-Injury'
    ];
    this.accidentCauses = [
      'Drunken driving',
      'Over speeding',
      'Vehicle out of control',
      'Fault of driver of motor vehicle/cyclist/pedestrian/passenger',
      'Defect in mechanical /electrical condition of motor vehicle',
      'Wrong side driving',
      'Tyre bust',
      'Rain',
      'Poor visibility(fog/dust)',
      'Poor Road condition',
      'Others'
    ];
    this.roadFeature = [
      'Single lane',
      'Two lanes',
      'Three lanes or more without central divider (median)',
      'Four lanes or more with central divider'
    ];
    this.roadCondition = [
      'Straight road',
      'Slight Curve',
      'Curve',
      'Flat Road',
      'Gentle incline',
      'Steep incline',
      'Hump',
      'Dip'
    ];
    this.intersectionType = [
      'T-junction',
      'Y-junction',
      'Four arm junction',
      'Staggered junction',
      'Junction with more than 4 arms',
      'Round about junction',
      'Manned Rail crossing',
      'Unmanned Rail crossing'
    ];
    this.weatherCondition = [
      'Fine',
      'Mist/Fog',
      'Cloudy',
      'Light rain',
      'Heavy rain',
      'Hail/sleet',
      'Snow',
      'Strong Wind',
      'Dust Storm',
      'Very Hot',
      'Very Cold',
      'Other extraordinary weather condition'
    ];
    this.severityTypes = [
      '0.00%',
      '20.00%',
      '40.00%',
      '60.00%',
      '80.00%',
      '100.00%'
    ];

    this.violationRiskCategory = [
      'High',
      'Medium',
      "Low"
    ]
    this.dailyOutputAchieved = [
      'Full',
      'None'
    ]
    this.report_submitted = [
      'Yes',
      'No'
    ]
    this.issueTypeListMaster = [
      { id: 1, inspec_id: 1, name: 'Maintenance - Main Carriageway, and Service Road' },
      { id: 2, inspec_id: 1, name: 'Road Furniture' },
      { id: 3, inspec_id: 1, name: 'Road Structure' },
      { id: 4, inspec_id: 1, name: 'Road Safety' },
      { id: 5, inspec_id: 1, name: 'Landscaping/Planting' },
      { id: 6, inspec_id: 1, name: 'General upkeep/Housekeeping' },
      { id: 7, inspec_id: 1, name: 'Reporting Compliance' }
      // { id: 1, inspec_id: 1, name: 'Pavement' },
      // { id: 1, inspec_id: 2, name: 'Pavement' },
      // { id: 2, inspec_id: 1, name: 'Embankment/Slope' },
      // { id: 3, inspec_id: 1, name: 'Rigid Pavement' },
      // { id: 3, inspec_id: 2, name: 'Rigid Pavement' },
      // { id: 4, inspec_id: 2, name: 'Pavement Marking' },
      // { id: 5, inspec_id: 1, name: 'Road Signs' },
      // { id: 5, inspec_id: 3, name: 'Road Signs' },
      // { id: 6, inspec_id: 1, name: 'Kerb' },
      // { id: 6, inspec_id: 2, name: 'Kerb' },
      // { id: 7, inspec_id: 1, name: 'Furnitures' },
      // { id: 8, inspec_id: 1, name: 'Tree plantation' },
      // { id: 8, inspec_id: 2, name: 'Tree plantation' },
      // { id: 9, inspec_id: 1, name: 'Other' },
      // { id: 10, inspec_id: 2, name: 'Culverts' },
      // { id: 11, inspec_id: 1, name: 'Bridges' },
      // { id: 11, inspec_id: 2, name: 'Bridges' },
      // { id: 12, inspec_id: 1, name: 'Drainage' },
      // { id: 13, inspec_id: 1, name: 'Amenities' },
      // { id: 14, inspec_id: 1, name: 'Toll_Plaza' },
      // { id: 15, inspec_id: 2, name: 'Highway' },
      // { id: 16, inspec_id: 1, name: 'Other Road Furniture' },
      // { id: 17, inspec_id: 1, name: 'Highway Lighting System' },
      // { id: 17, inspec_id: 2, name: 'Highway Lighting System' },
      // { id: 18, inspec_id: 1, name: 'Rest Areas' },
      // { id: 19, inspec_id: 2, name: 'Pipe/box/slab culverts' },
      // { id: 20, inspec_id: 1, name: 'Bridge- Super Structure' },
      // { id: 20, inspec_id: 2, name: 'Bridge- Super Structure' },
      // { id: 20, inspec_id: 3, name: 'Bridge- Super Structure' },
      // { id: 21, inspec_id: 2, name: 'Bridge- Substructure' },
      // { id: 22, inspec_id: 2, name: 'Bridge Foundation' },
      // { id: 23, inspec_id: 1, name: 'TMS Lane System' },
      // { id: 24, inspec_id: 1, name: 'Plaza System' }
    ]
    this.issueTypeList = [];
    this.chainageSides = [
      'LHS',
      'RHS',
      'BHS'
    ];
    this.issueSubTypeList = [];
    this.srcIssueSubTypes = [
      { id: 1, cat_id: 1, inspec_id: 1, name: 'Pothole', deadline_days: 2, treatment: 'Pot hole repairs' },
      { id: 2, cat_id: 1, inspec_id: 1, name: 'Cracking', deadline_days: 15, treatment: 'Crack sealing' },
    { id: 3, cat_id: 1, inspec_id: 1, name: 'Rutting',deadline_days: 30, treatment: 'Rutting repairs'  },
    { id: 4, cat_id: 1, inspec_id: 1, name: 'Corrugations and Shoving', deadline_days: 7, treatment: 'Corrugation & Shoving repairs' },
    { id: 5, cat_id: 1, inspec_id: 1, name: 'Bleeding', deadline_days: 7, treatment: 'Bleeding repairs' },
    { id: 6, cat_id: 1, inspec_id: 1, name: 'Ravelling/Stripping', deadline_days: 15, treatment: 'Ravelling repairs' },
    { id: 7, cat_id: 1, inspec_id: 1, name: 'Edge Deformation/Breaking', deadline_days: 15, treatment: 'Edge repairs' },
    { id: 8, cat_id: 1, inspec_id: 1, name: 'Edge Drop at shoulders', deadline_days: 15, treatment: 'Shoulder repairs' },
    { id: 9, cat_id: 1, inspec_id: 1, name: 'Embankment Slopes', deadline_days: 15, treatment: 'Slope protection repairs' },
    { id: 10, cat_id: 1, inspec_id: 1, name: 'Embankment Protection', deadline_days: 15, treatment: 'Slope protection repairs' },
    { id: 11, cat_id: 1, inspec_id: 2, name: 'Camber/Cross-fall at shoulders', deadline_days: 15, treatment: 'Slope protection repairs' },
    // 
    { id: 12, cat_id: 2, inspec_id: 1, name: 'Road Markings', deadline_days: 60, treatment: 'New installation' },
    { id: 13, cat_id: 2, inspec_id: 1, name: 'Signages (Cautionary,Mandatory Information, etc.)', deadline_days: 2, treatment: '' },
    { id: 14, cat_id: 2, inspec_id: 1, name: 'Signages (Gantry/Cantilever Sign Boards)', deadline_days: 2, treatment: '' },
    { id: 15, cat_id: 2, inspec_id: 1, name: 'Highway Lights', deadline_days: 1, treatment: 'Improvement in Lighting System' },
    { id: 16, cat_id: 2, inspec_id: 1, name: 'Toll Plaza Canopy Lights', deadline_days: 1, treatment: 'Improvement in Lighting System' },
    { id: 17, cat_id: 2, inspec_id: 1, name: 'Kerb', deadline_days: 30, treatment: '' },
    { id: 18, cat_id: 2, inspec_id: 1, name: 'Reflective Pavement Markers(Road Studs)', deadline_days: 60, treatment: 'New Installation' },
    { id: 19, cat_id: 2, inspec_id: 1, name: 'Guard Rails, MBCB, Crash Barriers and Boundary/Km stones etc', deadline_days: 3, treatment: 'Repair/Replacement' },
    // // 
    { id: 20, cat_id: 3, inspec_id: 1, name: 'Bridges-Riding quality or user comfort', deadline_days: 15, treatment: 'Repairing of wearing coat' },
    { id: 21, cat_id: 3, inspec_id: 1, name: 'Bumps', deadline_days: 30, treatment: '' },
    { id: 22, cat_id: 3, inspec_id: 1, name: 'User safety (condition of crash barrier and guard rail)', deadline_days: 3, treatment: '' },
    { id: 23, cat_id: 3, inspec_id: 1, name: 'Debris and dust in strip seal expansion joint', deadline_days: 3, treatment: '' },
    { id: 24, cat_id: 3, inspec_id: 1, name: 'Drainage spouts', deadline_days: 3, treatment: '' },
    // // 
    { id: 25, cat_id: 4, inspec_id: 1, name: 'PPE', deadline_days: 3, treatment: '' },
    { id: 26, cat_id: 4, inspec_id: 1, name: 'Work Zone Safety', deadline_days: 3, treatment: '' },
    { id: 27, cat_id: 4, inspec_id: 1, name: 'Work permit not available', deadline_days: 3, treatment: '' },
    { id: 28, cat_id: 4, inspec_id: 1, name: 'SOP not available', deadline_days: 3, treatment: '' },
    { id: 29, cat_id: 4, inspec_id: 1, name: 'Work in buffer zone', deadline_days: 3, treatment: '' },
    { id: 30, cat_id: 4, inspec_id: 1, name: 'Any Other', deadline_days: 3, treatment: '' },
    // // 
    { id: 31, cat_id: 5, inspec_id: 1, name: 'Watering the Plants and Trees', deadline_days: 2, treatment: ''},
    { id: 32, cat_id: 5, inspec_id: 1, name: 'Trimming of the Plants', deadline_days: 20, treatment: '' },
    { id: 33, cat_id: 5, inspec_id: 1, name: 'Removal of all sort of obstructions', deadline_days: 1, treatment: '' },
    { id: 34, cat_id: 5, inspec_id: 1, name: 'Maintaining vegetation', deadline_days: 20, treatment: '' },
    { id: 35, cat_id: 5, inspec_id: 1, name: 'Replacement of decayed Plants and Trees', deadline_days: 50, treatment: '' },
    // // 
    { id: 36, cat_id: 6, inspec_id: 1, name: 'Cleaning of Main Carriageway (MCW)', deadline_days: 10, treatment: '' },
    { id: 37, cat_id: 6, inspec_id: 1, name: 'Cleaning of Service Road (SR)', deadline_days: 10, treatment: '' },
    { id: 38, cat_id: 6, inspec_id: 1, name: 'Cleaning of Toll Collection Building', deadline_days: 1, treatment: '' },
    { id: 39, cat_id: 6, inspec_id: 1, name: 'Cleaning of Rest Area (if any)', deadline_days: 1, treatment: '' },
    { id: 40, cat_id: 6, inspec_id: 1, name: 'Cleaning of Public Toilets', deadline_days: 3, treatment: '' },
    { id: 41, cat_id: 6, inspec_id: 1, name: 'Cleaning of open and Covered Drains', deadline_days: 30, treatment: '' },
    { id: 42, cat_id: 6, inspec_id: 1, name: 'Petty repair to railings, Parapet wall and Footpath & Ducts etc', deadline_days: 1, treatment: '' },
    
    { id: 43, cat_id: 7, inspec_id: 1, name: 'Daily/ Routine Inspection Report', deadline_days: 3, treatment: ''},
    { id: 44, cat_id: 7, inspec_id: 1, name: 'Monthly Status/ Inspection Report', deadline_days: 3, treatment: ''},
    { id: 45, cat_id: 7, inspec_id: 1, name: 'Test Reports', deadline_days: 3, treatment: ''},
    { id: 46, cat_id: 7, inspec_id: 1, name: 'Remedial measures report', deadline_days: 3, treatment: ''},
    { id: 47, cat_id: 7, inspec_id: 1, name: 'Daily Reports of Unusual Occurrence', deadline_days: 3, treatment: ''},
    { id: 48, cat_id: 7, inspec_id: 1, name: 'Weekly Reports of Unusual Occurrence', deadline_days: 3, treatment: ''},
    { id: 49, cat_id: 7, inspec_id: 1, name: 'Monthly Reports of Unusual Occurrence', deadline_days: 3, treatment: ''},
      
      
      // { id: 1, cat_id: 1, inspec_id: 1, name: 'Pot holes', deadline_days: 2, treatment: 'Pot hole repairs' },
      // { id: 2, cat_id: 1, inspec_id: 1, name: 'Cracking', deadline_days: 15, treatment: 'Crack sealing' },
      // { id: 3, cat_id: 1, inspec_id: 1, name: 'Rutting', deadline_days: 30, treatment: 'Rutting repairs' },
      // { id: 4, cat_id: 1, inspec_id: 1, name: 'Corrugations & Shoving', deadline_days: 7, treatment: 'Corrugation & Shoving repairs' },
      // { id: 5, cat_id: 1, inspec_id: 1, name: 'Bleeding/Skidding', deadline_days: 7, treatment: 'Bleeding repairs' },
      // { id: 6, cat_id: 1, inspec_id: 1, name: 'Ravelling/Stripping', deadline_days: 15, treatment: 'Ravelling repairs' },
      // { id: 7, cat_id: 1, inspec_id: 1, name: 'Edge Deformation/Breaking', deadline_days: 15, treatment: 'Edge repairs' },
      // { id: 8, cat_id: 1, inspec_id: 2, name: 'Others', deadline_days: 7, treatment: 'Appropriate repairs' },
      // { id: 9, cat_id: 2, inspec_id: 1, name: 'Edge Drop at shoulders', deadline_days: 15, treatment: 'Shoulder repairs' },
      // { id: 10, cat_id: 2, inspec_id: 1, name: 'Slope of Camber/ Cross fall', deadline_days: 15, treatment: 'Camber correction' },
      // { id: 11, cat_id: 2, inspec_id: 1, name: 'Change in embankment slope', deadline_days: 15, treatment: 'Slope protection repairs' },
      // { id: 12, cat_id: 2, inspec_id: 1, name: 'Rain cuts/ gullies in slope', deadline_days: 15, treatment: 'Slope protection repairs' },
      // { id: 13, cat_id: 3, inspec_id: 1, name: 'Cracking', deadline_days: 15, treatment: 'Suitable cracking repairs' },
      // { id: 14, cat_id: 3, inspec_id: 1, name: 'Ravelling/Honeycomb type surface', deadline_days: 15, treatment: 'Ravelling repairs' },
      // { id: 15, cat_id: 3, inspec_id: 1, name: 'Scaling', deadline_days: 15, treatment: 'Scaling repairs' },
      // { id: 16, cat_id: 3, inspec_id: 1, name: 'Popout/Pothole', deadline_days: 2, treatment: 'Pothole repairs' },
      // { id: 17, cat_id: 3, inspec_id: 1, name: 'Joint Defects', deadline_days: 15, treatment: 'Joints repairs / replacement' },
      // { id: 18, cat_id: 3, inspec_id: 1, name: 'Blowup/ Bulking', deadline_days: 15, treatment: 'Full depth repair' },
      // { id: 19, cat_id: 3, inspec_id: 1, name: 'Depression', deadline_days: 15, treatment: 'Reinstate pavement' },
      // { id: 20, cat_id: 3, inspec_id: 1, name: 'Heave', deadline_days: 15, treatment: 'Stabilize subgrade' },
      // { id: 21, cat_id: 3, inspec_id: 1, name: 'Bump', deadline_days: 15, treatment: 'Gring the surface' },
      // { id: 22, cat_id: 3, inspec_id: 1, name: 'Lane/Shoulder drop off', deadline_days: 15, treatment: 'Fill the shoulder' },
      // { id: 23, cat_id: 3, inspec_id: 1, name: 'Drainage', deadline_days: 15, treatment: 'Drain repairs' },
      // { id: 24, cat_id: 4, inspec_id: 2, name: 'Wear (Cat 1)', deadline_days: 1, treatment: 'As per IRC 35:2015' },
      // { id: 25, cat_id: 4, inspec_id: 2, name: 'Wear (Cat 2)', deadline_days: 60, treatment: 'As per IRC 35:2015' },
      // { id: 26, cat_id: 4, inspec_id: 2, name: 'Improper Day Time Visibility (Cat 1)', deadline_days: 1, treatment: 'As per IRC 35:2015' },
      // { id: 27, cat_id: 4, inspec_id: 2, name: 'Improper Day Time Visibility (Cat 2)', deadline_days: 60, treatment: 'As per IRC 35:2015' },
      // { id: 28, cat_id: 4, inspec_id: 2, name: 'Improper Night Time Visibility (Cat 1)', deadline_days: 1, treatment: 'As per IRC 35:2015' },
      // { id: 29, cat_id: 4, inspec_id: 2, name: 'Improper Night Time Visibility (Cat 2)', deadline_days: 60, treatment: 'As per IRC 35:2015' },
      // { id: 30, cat_id: 5, inspec_id: 1, name: 'Shape & Position (Mandatory Signboards)', deadline_days: 2, treatment: 'Improvement/Relocation' },
      // { id: 31, cat_id: 5, inspec_id: 1, name: 'Shape & Position (Gantry/Cantilever Signboards)', deadline_days: 15, treatment: 'Improvement/Relocation' },
      // { id: 32, cat_id: 5, inspec_id: 3, name: 'Retro reflectivity (Mandatory Signboards)', deadline_days: 2, treatment: 'Change of Sign board' },
      // { id: 33, cat_id: 5, inspec_id: 3, name: 'Retro reflectivity (Gantry/Cantilever Signboards)', deadline_days: 30, treatment: 'Change of Sign board' },
      // { id: 34, cat_id: 6, inspec_id: 2, name: 'Inadequate Height', deadline_days: 30, treatment: 'Raising of Kerb height' },
      // { id: 35, cat_id: 6, inspec_id: 1, name: 'Worn out Paint', deadline_days: 7, treatment: 'Repainting' },
      // { id: 36, cat_id: 7, inspec_id: 1, name: 'Road studs - Damaged/Theft', deadline_days: 60, treatment: 'New installation' },
      // { id: 37, cat_id: 7, inspec_id: 1, name: 'Crash barrier / PGR - Damaged', deadline_days: 15, treatment: 'Replacement of crash barrier / PGR' },
      // { id: 38, cat_id: 7, inspec_id: 1, name: 'Traffic safety barrier - Damaged', deadline_days: 7, treatment: 'Rectification' },
      // { id: 39, cat_id: 7, inspec_id: 1, name: 'Attenuators - Damaged', deadline_days: 7, treatment: 'Rectification' },
      // { id: 40, cat_id: 7, inspec_id: 1, name: 'Guard post/ Delineators/ Overhead sign structure - Damaged', deadline_days: 15, treatment: 'Rectification' },
      // { id: 41, cat_id: 7, inspec_id: 1, name: 'Traffic Blinkers - Damaged', deadline_days: 7, treatment: 'Rectification' },
      // { id: 42, cat_id: 7, inspec_id: 1, name: 'Milestones - Damaged / Theft', deadline_days: 25, treatment: 'Replacement of milestones' },
      // { id: 43, cat_id: 7, inspec_id: 1, name: 'Traffic Signs - Damaged / Theft', deadline_days: 25, treatment: 'Replacement of sign board' },
      // { id: 44, cat_id: 7, inspec_id: 1, name: 'Light fixtures - Damaged / Theft', deadline_days: 1, treatment: 'Replacement / repair of fixtures' },
      // { id: 45, cat_id: 7, inspec_id: 1, name: 'Light fixtures - Non-functioning', deadline_days: 1, treatment: 'Replacement / electric repairs' },
      // { id: 46, cat_id: 8, inspec_id: 2, name: 'Tree causing obstruction in a min headroom of 5.5m', deadline_days: 1, treatment: 'Removal of tree' },
      // { id: 47, cat_id: 8, inspec_id: 1, name: 'Detoration in health of trees', deadline_days: 90, treatment: 'Timely watering/necessary treatment' },
      // { id: 48, cat_id: 9, inspec_id: 1, name: 'Other Project facilities & approach roads - Damage/detoriation', deadline_days: 15, treatment: 'Repair' },
      // { id: 49, cat_id: 10, inspec_id: 2, name: 'Obstructed flow section', deadline_days: 30, treatment: 'Clearing of debris' },
      // { id: 50, cat_id: 10, inspec_id: 2, name: 'Expansion joint - Damaged', deadline_days: 30, treatment: 'Fixing with sealant ' },
      // { id: 51, cat_id: 10, inspec_id: 2, name: 'Protection works - Damaged', deadline_days: 30, treatment: 'Suitable repairs' },
      // { id: 52, cat_id: 11, inspec_id: 1, name: 'Poor riding quality', deadline_days: 15, treatment: 'Repairing of wearing coat' },
      // { id: 53, cat_id: 11, inspec_id: 1, name: 'Bump at expansion Joint', deadline_days: 15, treatment: 'Repair of BC/Profile correction' },
      // { id: 54, cat_id: 11, inspec_id: 1, name: 'Crash barrier/ Guard rail - Damaged', deadline_days: 3, treatment: 'Repair/Replacement' },
      // { id: 55, cat_id: 11, inspec_id: 2, name: 'Rusted reinforcements', deadline_days: 15, treatment: 'Applynig anti-corrosive coat' },
      // { id: 56, cat_id: 11, inspec_id: 2, name: 'Spaling of concrete', deadline_days: 15, treatment: 'Repair with epoxy mortar/concrete' },
      // { id: 57, cat_id: 11, inspec_id: 1, name: 'Delamination', deadline_days: 15, treatment: 'Repair with epoxy mortar/concrete' },
      // { id: 58, cat_id: 11, inspec_id: 1, name: 'Deck surface defects', deadline_days: 30, treatment: 'Deck surface repairs' },
      // { id: 59, cat_id: 11, inspec_id: 2, name: 'Exp joints deformation / damage', deadline_days: 15, treatment: 'Joints repairs / replacement' },
      // { id: 60, cat_id: 11, inspec_id: 2, name: 'Clogging of drainage spouts', deadline_days: 3, treatment: 'Cleaning' },
      // { id: 61, cat_id: 11, inspec_id: 2, name: 'Bearing deformation / damage', deadline_days: 90, treatment: 'Bearing repairs / replacements' },
      // { id: 62, cat_id: 11, inspec_id: 2, name: 'Scouring around foundation', deadline_days: 30, treatment: 'Suitable protection works' },
      // { id: 63, cat_id: 12, inspec_id: 1, name: 'Median drains - Chocking/silt', deadline_days: 25, treatment: 'Median Drain cleaning' },
      // { id: 64, cat_id: 12, inspec_id: 1, name: 'RCC drains - Chocking/silt', deadline_days: 25, treatment: 'RCC drain cleaning' },
      // { id: 65, cat_id: 12, inspec_id: 1, name: 'Earthen drains - Chocking/silt', deadline_days: 25, treatment: 'Earthen drain cleaning' },
      // { id: 66, cat_id: 12, inspec_id: 1, name: 'Culverts - Chocking/silt', deadline_days: 25, treatment: 'Culvert cleaning' },
      // { id: 67, cat_id: 13, inspec_id: 1, name: 'Truck/Bus Bay - Litter/Dust/Dirt', deadline_days: 25, treatment: 'Cleaning & repairs' },
      // { id: 68, cat_id: 13, inspec_id: 1, name: 'Toilet blocks - Unhygienic condition', deadline_days: 1, treatment: 'Cleaning & repairs' },
      // { id: 69, cat_id: 14, inspec_id: 1, name: 'Plaza Rigid pavement -  defects & damages', deadline_days: 25, treatment: 'PPot hole / panel repairot' },
      // { id: 70, cat_id: 14, inspec_id: 1, name: 'Plaza cleaning - litter/dust/dirt', deadline_days: 1, treatment: 'Plaza cleaning' },
      // { id: 71, cat_id: 15, inspec_id: 2, name: 'Availability of Safe Sight Distance', deadline_days: 1, treatment: 'Removal of obstruction within 24 hours, in case of sight line affected by temporary objects such as trees, temporary encroachments.In case of permanent structure or design deficiency: Removal of obstruction/improvement of deficiency at the earliest. Speed Restriction boards and suitable traffic calming measures such as transverse bar marking, blinkers, etc. shall be applied during the period of rectification.' },
      // { id: 72, cat_id: 16, inspec_id: 1, name: 'Reflective PavementMarkers (Road Studs)', deadline_days: 60, treatment: 'New Installation' },
      // { id: 73, cat_id: 16, inspec_id: 1, name: 'Pedestrian Guardrail', deadline_days: 15, treatment: 'Rectification' },
      // { id: 74, cat_id: 16, inspec_id: 1, name: 'Traffic Safety Barriers', deadline_days: 7, treatment: 'Rectification' },
      // { id: 75, cat_id: 16, inspec_id: 1, name: 'End Treatment of Traffic Safety Barriers', deadline_days: 7, treatment: 'Rectification' },
      // { id: 76, cat_id: 16, inspec_id: 1, name: 'Attenuators', deadline_days: 7, treatment: 'Rectification' },
      // { id: 77, cat_id: 16, inspec_id: 1, name: 'Guard Posts and Delineators', deadline_days: 1, treatment: '' },
      // { id: 78, cat_id: 16, inspec_id: 1, name: 'Overhead Sign Structure', deadline_days: 15, treatment: 'Rectification' },
      // { id: 79, cat_id: 16, inspec_id: 1, name: 'Traffic Blinkers', deadline_days: 7, treatment: 'Rectification' },
      // { id: 80, cat_id: 17, inspec_id: 1, name: 'Highway Lights', deadline_days: 1, treatment: 'Improvement in Lighting System' },
      // { id: 81, cat_id: 17, inspec_id: 2, name: 'Highway Lights', deadline_days: 1, treatment: 'Rectification of failure' },
      // { id: 82, cat_id: 17, inspec_id: 1, name: 'Toll Plaza Canopy Lights', deadline_days: 1, treatment: 'Improvement in Lighting System' },
      // { id: 83, cat_id: 18, inspec_id: 1, name: 'Cleaning of toilets', deadline_days: 1, treatment: '' },
      // { id: 84, cat_id: 18, inspec_id: 1, name: 'Defects in electrical, water and sanitary - installations', deadline_days: 1, treatment: '' },
      // { id: 85, cat_id: 19, inspec_id: 2, name: 'Free waterway/unobstructed flow section', deadline_days: 15, treatment: 'Cleaning silt up soils and debris in culvert barrel after rainy season, removal of bushes and vegetation, U/s of barrel, under barrel and D/s of barrel before rainy season.' },
      // { id: 86, cat_id: 19, inspec_id: 2, name: 'Leak-proof expansion joints if any', deadline_days: 30, treatment: 'Fixing with sealant suitably' },
      // { id: 87, cat_id: 19, inspec_id: 2, name: 'Structurally sound', deadline_days: 15, treatment: 'Repairs to spalling, cracking, delamination, rusting shall be followed as per IRC:SP:40-1993.' },
      // { id: 88, cat_id: 19, inspec_id: 2, name: 'Protection works in good condition', deadline_days: 30, treatment: 'Repairs to damaged aprons and pitching' },
      // { id: 89, cat_id: 20, inspec_id: 1, name: 'User safety (condition of crash barrier and guard rail) (condition of crash barrier and guard rail)', deadline_days: 3, treatment: 'Repairs and replacement of safety barriers as the case may be' },
      // { id: 90, cat_id: 20, inspec_id: 2, name: 'Rusted reinforcement', deadline_days: 15, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti-corrosive coating before carrying out the repairs to affected concrete portion with epoxy mortar/concrete.' },
      // { id: 91, cat_id: 20, inspec_id: 2, name: 'Spalling of concrete', deadline_days: 15, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti-corrosive coating before carrying out the repairs to affected concrete portion with epoxy mortar/concrete.' },
      // { id: 92, cat_id: 20, inspec_id: 1, name: 'Delamination', deadline_days: 15, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti-corrosive coating before carrying out the repairs to affected concrete portion with epoxy mortar/concrete.' },
      // { id: 93, cat_id: 20, inspec_id: 2, name: 'Cracks wider than 0.30 mm', deadline_days: 2, treatment: 'Grouting with epoxy mortar, investigating causes for cracks development and carry out necessary rehabilitation.' },
      // { id: 94, cat_id: 20, inspec_id: 2, name: 'Rainwater seepage through deck slab', deadline_days: 30, treatment: 'Grouting of deck slab at leakage areas, waterproofing, repairs to drainage spouts' },
      // { id: 95, cat_id: 20, inspec_id: 3, name: 'Deflection due to permanent loads and live loads', deadline_days: 180, treatment: 'Carry out major rehabilitation works on bridge to retain original design loads capacity' },
      // { id: 96, cat_id: 20, inspec_id: 3, name: 'Vibrations in bridge deck due to moving trucks', deadline_days: 120, treatment: 'Strengthening of super structure' },
      // { id: 97, cat_id: 20, inspec_id: 2, name: 'Leakage in Expansion joints', deadline_days: 15, treatment: 'Replace of seal in expansion joint' },
      // { id: 98, cat_id: 20, inspec_id: 2, name: 'Debris and dust in strip seal expansion joint', deadline_days: 3, treatment: 'Cleaning of expansion joint gaps thoroughly' },
      // { id: 99, cat_id: 20, inspec_id: 2, name: 'Drainage spouts', deadline_days: 3, treatment: 'Cleaning of drainage spouts thoroughly. Replacement of missing/broken down take pipes with a minimum pipe extension of 500mm below soffit of slab. Providing sealant around the drainage spout if any leakages observed.' },
      // { id: 100, cat_id: 21, inspec_id: 2, name: 'Cracks/spalling of concrete/rusted steel', deadline_days: 30, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti- corrosive coating before carrying out repairs to substructure by grouting/guiniting and micro concreting depending on type of defect noticed' },
      // { id: 101, cat_id: 21, inspec_id: 2, name: 'Bearings', deadline_days: 90, treatment: 'In case of failure of even one bearing on any pier/abutment, all the bearings on that pier/abutment shall be replaced, in order to get uniform load transfer on to bearings.' },
      // { id: 102, cat_id: 22, inspec_id: 2, name: 'Scouring around foundations', deadline_days: 30, treatment: 'Suitable protection works around pier/abutment' },
      // { id: 103, cat_id: 23, inspec_id: 1, name: 'Toll Lane Controller', deadline_days: 1, treatment: '' },
      // { id: 104, cat_id: 23, inspec_id: 1, name: 'AVC Controller', deadline_days: 1, treatment: '' },
      // { id: 105, cat_id: 23, inspec_id: 1, name: 'Operator Monitor', deadline_days: 1, treatment: '' },
      // { id: 106, cat_id: 23, inspec_id: 1, name: 'Dedicated Keyboard', deadline_days: 1, treatment: '' },
      // { id: 107, cat_id: 23, inspec_id: 1, name: 'Receipt Printer', deadline_days: 1, treatment: '' },
      // { id: 108, cat_id: 23, inspec_id: 1, name: 'Overhead Lane Signal', deadline_days: 1, treatment: '' },
      // { id: 109, cat_id: 23, inspec_id: 1, name: 'User Fare Display', deadline_days: 1, treatment: '' },
      // { id: 110, cat_id: 23, inspec_id: 1, name: 'High Speed Barriers (0.9 sec)', deadline_days: 1, treatment: '' },
      // { id: 111, cat_id: 23, inspec_id: 1, name: 'Traffic light', deadline_days: 1, treatment: '' },
      // { id: 112, cat_id: 23, inspec_id: 1, name: 'Manual Booth Controller', deadline_days: 1, treatment: '' },
      // { id: 113, cat_id: 23, inspec_id: 1, name: 'Siren with Amber light', deadline_days: 1, treatment: '' },
      // { id: 114, cat_id: 23, inspec_id: 1, name: 'Bar Code Readers', deadline_days: 1, treatment: '' },
      // { id: 115, cat_id: 23, inspec_id: 1, name: 'Panic Alarm Switch', deadline_days: 1, treatment: '' },
      // { id: 116, cat_id: 23, inspec_id: 1, name: 'Incident Camera', deadline_days: 1, treatment: '' },
      // { id: 117, cat_id: 23, inspec_id: 1, name: 'Cash drawers', deadline_days: 1, treatment: '' },
      // { id: 118, cat_id: 23, inspec_id: 1, name: 'Smart card reader', deadline_days: 1, treatment: '' },
      // { id: 119, cat_id: 23, inspec_id: 1, name: 'SSWIM', deadline_days: 1, treatment: '' },
      // { id: 120, cat_id: 23, inspec_id: 1, name: 'ETC Reader', deadline_days: 1, treatment: '' },
      // { id: 121, cat_id: 24, inspec_id: 1, name: 'Plaza Server', deadline_days: 1, treatment: '' },
      // { id: 122, cat_id: 24, inspec_id: 1, name: 'Workstations', deadline_days: 1, treatment: '' },
      // { id: 123, cat_id: 24, inspec_id: 1, name: 'Laser Printer', deadline_days: 1, treatment: '' },
      // { id: 124, cat_id: 24, inspec_id: 1, name: 'Point of Sale', deadline_days: 1, treatment: '' },
      // { id: 125, cat_id: 24, inspec_id: 1, name: 'Networking Switches', deadline_days: 1, treatment: '' },
      // { id: 126, cat_id: 24, inspec_id: 1, name: 'Networking Wiring', deadline_days: 1, treatment: '' },
      // { id: 127, cat_id: 24, inspec_id: 1, name: 'Cabling & Accessories', deadline_days: 1, treatment: '' },
      // { id: 128, cat_id: 24, inspec_id: 1, name: 'Master Intercom', deadline_days: 1, treatment: '' },
      // { id: 129, cat_id: 24, inspec_id: 1, name: 'UPS Control Room', deadline_days: 1, treatment: '' },
      // { id: 130, cat_id: 24, inspec_id: 1, name: 'Incident Capture Software', deadline_days: 1, treatment: '' },
      // { id: 131, cat_id: 24, inspec_id: 1, name: 'UPS ETC Lane', deadline_days: 1, treatment: '' },
      // { id: 132, cat_id: 24, inspec_id: 1, name: 'UPS Cash Lane', deadline_days: 1, treatment: '' },
      // { id: 133, cat_id: 24, inspec_id: 1, name: 'UPS AVC', deadline_days: 1, treatment: '' },
      // { id: 134, cat_id: 24, inspec_id: 1, name: 'Plaza monitoring camera', deadline_days: 1, treatment: '' },
      // { id: 135, cat_id: 24, inspec_id: 1, name: 'DVR (Toll Plaza)', deadline_days: 1, treatment: '' },
      // { id: 136, cat_id: 24, inspec_id: 1, name: 'CCTV Monitor', deadline_days: 1, treatment: '' },
      // { id: 137, cat_id: 1, inspec_id: 2, name: 'Roughness beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008' },
      // { id: 138, cat_id: 1, inspec_id: 2, name: 'Skid number beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008' },
      // { id: 139, cat_id: 1, inspec_id: 2, name: 'Rutting beyond LOS', deadline_days: 30, treatment: 'MORT&H Specification 3004.2' },
      // { id: 140, cat_id: 1, inspec_id: 2, name: 'Pavement Condition Index beyond LOS', deadline_days: 180, treatment: 'IRC:82-2015' },
      // { id: 141, cat_id: 1, inspec_id: 2, name: 'Other Pavement Distresses beyond LOS', deadline_days: 7, treatment: 'IRC:82-2015' },
      // { id: 142, cat_id: 1, inspec_id: 2, name: 'Deflection/Remaining Life criteria infringement', deadline_days: 180, treatment: 'IRC:115-2014' },
      // { id: 143, cat_id: 3, inspec_id: 2, name: 'Roughness beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008' },
      // { id: 144, cat_id: 3, inspec_id: 2, name: 'Skid number beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008' },
      // // dummy
      // { id: 145, cat_id: 8, inspec_id: 1, name: 'Trimming of the Plants', deadline_days: 90, treatment: 'Timely watering/necessary treatment' },

      // { id: 146, cat_id: 8, inspec_id: 1, name: 'Removal of all sort of obstructions', deadline_days: 90, treatment: 'Timely watering/necessary treatment' },

      // { id: 147, cat_id: 8, inspec_id: 1, name: 'Maintaining vegetation', deadline_days: 90, treatment: 'Timely watering/necessary treatment' },

      // // 
      // { id: 147, cat_id: 8, inspec_id: 1, name: 'Replacement of decayed Plants and Trees', deadline_days: 90, treatment: 'Timely watering/necessary treatment' },

      // { id: 148, cat_id: 18, inspec_id: 1, name: 'Cleaning of Main Carriageway (MCW)', deadline_days: 1, treatment: '' },
      // { id: 149, cat_id: 18, inspec_id: 1, name: 'Cleaning of Service Road (SR)', deadline_days: 1, treatment: '' },

      // { id: 150, cat_id: 18, inspec_id: 1, name: 'Cleaning of Toll Collection Building', deadline_days: 1, treatment: '' },

      // { id: 151, cat_id: 18, inspec_id: 1, name: 'Cleaning of Rest Area (if any)', deadline_days: 1, treatment: '' },
      // { id: 152, cat_id: 18, inspec_id: 1, name: 'Cleaning of Public Toilets', deadline_days: 1, treatment: '' },
      // { id: 153, cat_id: 18, inspec_id: 1, name: 'Cleaning of open and Covered Drains', deadline_days: 1, treatment: '' },
      // { id: 154, cat_id: 18, inspec_id: 1, name: 'Petty repair to railings, Parapet wall and Footpath & Ducts etc', deadline_days: 1, treatment: '' },
    ];
  }
//  onInvestigationCategorySelected(selectedCategory:any){
//      if(selectedCategory!=''){
//        var cat_id='';
//        this.testAssetCategoryList.forEach((item, index) => {
//            if(item.name == selectedCategory){
//                cat_id = item.id
//            }
//        });
//        var newAssetList = [];
//        this.testAssetList.forEach((item, index) => {
//            if(item.cat_id == cat_id){
//                newAssetList.push(item);
//            }
//        });
//        this.selectedAssetList = newAssetList;
//        this.selectedTestNameList = [];
//        this.investigationObj.asset_name = '';
//        this.investigationObj.test_name = '';
//        this.investigationObj.test_specifications = '';
//        this.investigationObj.desirable = '';
//        this.investigationObj.acceptable = '';
//        this.investigationObj.frequency = '';
//        this.investigationObj.los_image = '';
//      }
//  }
  onInvestigationAssetSelected(selectedAsset:any){
      if(selectedAsset!=''){
        var cat_id='';
        this.testAssetList.forEach((item, index) => {
            if(item.name == selectedAsset){
                cat_id = item.id
            }
        });
        var newAssetList = [];
        this.testNameList.forEach((item, index) => {
            if(item.asset_id == cat_id){
                newAssetList.push(item);
            }
        });
        this.selectedTestNameList = newAssetList;
        this.investigationObj.test_name = '';
        this.investigationObj.test_specifications = '';
        this.investigationObj.desirable = '';
        this.investigationObj.acceptable = '';
        this.investigationObj.frequency = '';
        this.investigationObj.los_image = '';
      }
  }
  onInvestigationTestSelected(selectedTest:any){
      if(selectedTest!=''){
        this.testNameList.forEach((item, index) => {
            if(item.name == selectedTest){
                this.investigationObj.test_specifications = item.specification;
                this.investigationObj.desirable = item.desirable;
                this.investigationObj.acceptable = item.acceptable;
                this.investigationObj.frequency = item.frequency;
                this.investigationObj.los_image = item.los_image;
                this.investigationObj.testing_method = item.testing_method;
            }
        });
      }
  }
}