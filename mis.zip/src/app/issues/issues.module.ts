import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { JWBootstrapSwitchModule } from 'jw-bootstrap-switch-ng2';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TagInputModule } from 'ngx-chips';

import { IssuesComponent } from './issues.component';
import { IssuesRoutingModule } from './issues-routing.module';
import { IssuesRoutes } from './issues.routing';
import { CreateIssueComponent } from './create-issue/create-issue.component';

@NgModule({
  imports: [
    RouterModule.forChild(IssuesRoutes),
    IssuesRoutingModule,
    TagInputModule,
    JWBootstrapSwitchModule,
    NgbModule,
    CommonModule,
    FormsModule
  ],
  declarations: [IssuesComponent, CreateIssueComponent]
})
export class IssuesModule { }