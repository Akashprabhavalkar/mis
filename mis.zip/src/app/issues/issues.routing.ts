import { Routes } from '@angular/router';

import { IssuesComponent } from './issues.component';
import { CreateIssueComponent } from './create-issue/create-issue.component';

export const IssuesRoutes: Routes = [{
    path: 'issues',
    children: [{
        path: '',
        component: IssuesComponent
    }]
}, {
    path: 'issue',
    children: [{
        path: '',
        component: CreateIssueComponent
    }]
}];