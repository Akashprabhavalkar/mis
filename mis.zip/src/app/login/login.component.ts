import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { LoginService } from './login.service';
import { Title } from '@angular/platform-browser';
import { environment } from '../../environments/environment';
import swal from 'sweetalert2';
declare var $: any;

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    user = { username: '', password: '', type: 'normal' };
    forgotPassword = { forgot_username: '' };
    isLoginVisible: boolean = true;
    showEmailError: boolean = false;
    showForgotEmailError: boolean = false;
    showPasswordError: boolean = false;
    forgotEmailErrorMsg = '*Invalid email address';
    emailErrorMsg = '*Invalid email address';
    passwordErrorMsg = '*Invalid password';
    focus;
    focus1;
    focus2;
    test: Date = new Date();
    private toggleButton;
    private sidebarVisible: boolean;
    private nativeElement: Node;

    constructor(private element: ElementRef,
        private loginService: LoginService,
        private _router: Router,
        private titleService: Title,
        private http: HttpClient) {
        this.nativeElement = element.nativeElement;
        this.sidebarVisible = false;
    }

    ngOnInit() {
        this.titleService.setTitle('Login - Asset Management Tool');
        this.showEmailError = false;
        this.showPasswordError = false;
        this.checkFullPageBackgroundImage();
        var body = document.getElementsByTagName('body')[0];
        body.classList.add('login-page');
        var navbar: HTMLElement = this.element.nativeElement;
        this.toggleButton = navbar.getElementsByClassName('navbar-toggle')[0];
        setTimeout(function () {
            $('.card').removeClass('card-hidden');
        }, 700)
    }

    checkFullPageBackgroundImage() {
        var $page = $('.full-page');
        var image_src = $page.data('image');
        if (image_src !== undefined) {
            var image_container = '<div class="full-page-background" style="background-image: url(' + image_src + ') "/>'
            $page.append(image_container);
        }
    };

    login() {
        this.showEmailError = false;
        this.showPasswordError = false;
        if (this.user.username.length >= 6) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test(String(this.user.username).toLowerCase())) {
                if (this.user.password.length >= 6) {
                    var pattern = new RegExp(/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{7,19}$/);
                    if (pattern.test(this.user.password)) {
                        this.loginService.authLogin(this.user).subscribe(res => {
                            localStorage.setItem('auth_token', "Bearer " + res['auth_token']);
                            localStorage.setItem('user_data', JSON.stringify(res));
                            this._router.navigate(['/dashboard']);
                        },
                            err => {
                                this.showPasswordError = true;
                                this.passwordErrorMsg = '*Invalid email or password';
                            }
                        );
                    } else {
                        this.showPasswordError = true;
                        this.passwordErrorMsg = '*Invalid password';
                    }
                } else {
                    this.showPasswordError = true;
                    this.passwordErrorMsg = '*Invalid password';
                }
            } else {
                this.showEmailError = true;
            }
        } else {
            this.showEmailError = true;
        }
    }

    ngOnDestroy() {
        var body = document.getElementsByTagName('body')[0];
        body.classList.remove('login-page');
    }

    sidebarToggle() {
        var toggleButton = this.toggleButton;
        var body = document.getElementsByTagName('body')[0];
        var sidebar = document.getElementsByClassName('navbar-collapse')[0];
        if (this.sidebarVisible == false) {
            setTimeout(function () {
                toggleButton.classList.add('toggled');
            }, 500);
            body.classList.add('nav-open');
            this.sidebarVisible = true;
        } else {
            this.toggleButton.classList.remove('toggled');
            this.sidebarVisible = false;
            body.classList.remove('nav-open');
        }
    }

    showLoginView() {
        this.isLoginVisible = true;
    }

    resetPassword() {
        this.showForgotEmailError = false;
        if (this.forgotPassword.forgot_username.length >= 6) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test(String(this.forgotPassword.forgot_username).toLowerCase())) {
                this.loginService.forgotPassword(this.forgotPassword).subscribe(res => {
                    this.isLoginVisible = true;
                    swal({
                        title: "Check your inbox!",
                        text: "We sent you an email with the instructions to set a new password",
                        timer: 2000,
                        showConfirmButton: false
                    }).catch(swal.noop)
                },
                    err => {
                        this.showForgotEmailError = true;
                        this.forgotEmailErrorMsg = '*You are not registered user';
                    }
                );
            } else {
                this.showForgotEmailError = true;
            }
        } else {
            this.showForgotEmailError = true;
        }
    }

    openForgotPopup() {
        this.isLoginVisible = false;
    }
}