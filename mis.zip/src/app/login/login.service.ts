import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class LoginService {
    constructor(private http: HttpClient) { }

    authLogin(user: any) {
        return this.http.post(environment.BASE_URL + "api/v1/auth",
            {
                "password": user.password,
                "type": "normal",
                "username": user.username
            })
    }

    forgotPassword(forgotPassObj: any) {
        return this.http.post(environment.BASE_URL + "api/v1/users/password_recovery",
            {
                username: forgotPassObj.forgot_username
            })
    }
}