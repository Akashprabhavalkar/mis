import { Routes } from '@angular/router';
import { AssetsComponent } from './assets.component';

export const AssetsRoutes: Routes = [{
    path: 'project-files',
    children: [{
        path: '',
        component: AssetsComponent
    }]
}];