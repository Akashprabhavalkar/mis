import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AssetsService } from './assets.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-assets',
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.component.css']
})
export class AssetsComponent implements OnInit {
  projectId: any;
  assetId: any;
  type: any;
  sub: any;
  fileList: any;
  isAssetFilesAvaialble: boolean = false;
  userType;

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private assetsService: AssetsService) {

  }

  ngOnInit() {
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    this.userType = user_data.custom_role;
    this.sub = this.route
      .queryParams
      .subscribe(params => {
        this.projectId = params['project'];
        this.assetId = params['id'];
        this.type = params['type'];
        switch (this.type) {
          case "assets":
            localStorage.setItem('page_title', 'Assets');
            this.titleService.setTitle('Assets - Asset Management Tool');
            break;
          case "locations":
            localStorage.setItem('page_title', 'Locations');
            this.titleService.setTitle('Locations - Asset Management Tool');
            break;
        }
      });
    this.getAssetFiles();
  }
  
  getProjectTitle() {
    let projectTitle = localStorage.getItem('project_title') || '';
    return projectTitle;
  }

  getAssetFiles() {
    this.assetsService.getAssetFiles(this.projectId.toString(), this.assetId.toString()).subscribe(res => {
      this.fileList = res;
      if (this.fileList.length == 0) {
        this.isAssetFilesAvaialble = true;
      }
      this.fileList.forEach((item, index) => {
        this.fileList[index]['created_date'] = item['created_date'].substring(0, 10);
      });
    },
      err => {
      }
    );
  }

  deleteAttachment(file: any) {
    this.assetsService.deleteAttachment(file.id).subscribe(res => {
      swal({
        type: 'success',
        html: 'Attachment deleted.',
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      })
      this.getAssetFiles();
    },
      err => {
      }
    );
  }
}