import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AssetsComponent } from './assets.component';
import { AssetsRoutes } from './assets.routing';
import { AssetsRoutingModule } from './assets-routing.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AssetsRoutes),
    AssetsRoutingModule
  ],
  declarations: [AssetsComponent]
})
export class AssetsModule { }