import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class AssetsService {
    constructor(private http: HttpClient) { }

    getAssetFiles(projectId: String, assetId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/wiki/attachments?object_id=" + assetId + "&project=" + projectId, options)
    }

    deleteAttachment(attachmentId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.delete(environment.BASE_URL + "api/v1/wiki/attachments/" + attachmentId, options)
    }
}