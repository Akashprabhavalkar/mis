import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { LocationsComponent } from './locations.component';
import { LocationsRoutingModule } from './locations-routing.module';
import { LocationsRoutes } from './locations.routing';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(LocationsRoutes),
    LocationsRoutingModule
  ],
  declarations: [LocationsComponent]
})
export class LocationsModule { }
