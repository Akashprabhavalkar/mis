import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.css']
})
export class LocationsComponent implements OnInit {

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute) {

  }

  ngOnInit() {
    localStorage.setItem('page_title', 'Locations');
    this.titleService.setTitle('Locations - Asset Management Tool');
  }
}
