import { Routes } from '@angular/router';

import { LocationsComponent } from './locations.component';

export const LocationsRoutes: Routes = [{
    path: 'issues',
    children: [{
        path: '',
        component: LocationsComponent
    }]
}];
