import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ReportsComponent } from './reports.component';
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsRoutes } from './reports.routing';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(ReportsRoutes),
    ReportsRoutingModule,
    NgxDaterangepickerMd.forRoot(),
    FormsModule
  ],
  declarations: [ReportsComponent]
})
export class ReportsModule { }