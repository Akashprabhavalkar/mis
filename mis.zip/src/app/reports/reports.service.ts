import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class ReportsService {
    constructor(private http: HttpClient) { }

    exportProject(projectId: String, type: String, startDate: String, endDate: String, asset_type: String, performace_parameter: String, photo_selection: String, exportType: String, statusId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        var params = {
            start_date: startDate,
            end_date: endDate,
            type: type,
            asset_cat: asset_type,
            performance_cat: performace_parameter,
            photo: photo_selection,
            doc_type: exportType,
            type_name: type,
        };
        if(type == 'Compliance'){
            params['type'] = 'Issue';
            params['statusId'] = statusId;
        }
        return this.http.post(environment.BASE_URL + "api/v1/projects/" + projectId + "/regenerate_issues_csv_uuid", params, options)
    }

    downloadExport(url: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/exporter/", options)
    }
    getIssueTypeId(projectId: any, type: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-types?name=" + type + "&project=" + projectId, options)
    }
    getIssues(projectId: String, typeId: any, typeName: any, status: any, statusId: any, startDate: any, endDate: any, asset_type: any, performace_parameter: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issues?project=" + projectId + "&type_id=" + typeId + "&type_name=" + typeName +"&issue_cat=" + asset_type + "&issue_sub=" + performace_parameter + "&start_date=" + startDate + "&end_date=" + endDate, options)
    }
    getIssueAttachments(projectId: String, issueId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issues/attachments?object_id=" + issueId + "&project=" + projectId, options)
    }
}