import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { ReportsService } from './reports.service';
import { environment } from '../../environments/environment';
import * as moment from 'moment';

declare var $: any;
declare var swal: any;

declare interface DataTable {
  dataRows: string[];
}

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  projectId: any;
  statusId: String = '';
  assetId: any;
  sub: any;
  reportObj: any;
  isReportGenerated: boolean = false;
  exportMsg: String = '';
  downloadURL: String = '';
  asset_type: String = '';
  performace_parameter: String = '';
  photo_selection: String = 'with photo';
  report_type: String = 'Summary';
  selectedType: String = '';
  typeId: String = '';
  typeName: String = '';
  issueStatus: String = '';
  selectedFromDate: any;
  selectedToDate: any;
  maxDate: any;
  startDate: any;
  endDate: any;
  selectedAssetList = [];
  testAssetList = [];
  issueTypeListMaster = [];
  srcIssueSubTypes = [];
  selectedTestNameList = [];
  testNameList = [];
  allImageExtensions = ['jpg','JPG','jpeg','JPEG','png','PNG','gif','GIF','bmp','BMP','svg','SVG'];
  public dataTable: DataTable;
  issues = [];

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private reportService: ReportsService) {
    this.maxDate = moment();
    this.selectedFromDate = moment();
    this.selectedToDate = moment();
    this.startDate = moment();
    this.endDate = moment();
  }

  ngOnInit() {
      localStorage.setItem('page_title', 'Reports');
      this.titleService.setTitle('Reports - Asset Management Tool');
      this.sub = this.route.queryParams.subscribe(params => {
          this.projectId = params['project'];
          this.statusId = params['statusId'] || '';
      });
      this.testAssetList = [
          {id: 1, cat_id: 1, name: 'Flexible Pavement'},
          {id: 2, cat_id: 1, name: 'Rigid Pavement'},
          {id: 3, cat_id: 1, name: 'Road'},
          {id: 4, cat_id: 1, name: 'Pavement Marking'},
          {id: 5, cat_id: 1, name: 'Road Signs'},
          {id: 6, cat_id: 1, name: 'Kerb'},
          {id: 7, cat_id: 1, name: 'Highway Lights'},
          {id: 8, cat_id: 1, name: 'Toll Plaza Lights'},
          {id: 9, cat_id: 2, name: 'Pipe/box/slab culverts'},
          {id: 10, cat_id: 2, name: 'Bridge -Super Structure'},
          {id: 11, cat_id: 2, name: 'Bridge -Super Structure Span more than 40m'},
          {id: 12, cat_id: 2, name: 'Bridge -Super Structure Span more than 30m'},
          {id: 13, cat_id: 2, name: 'Bridge -Super Structure Span between 15 to 30m'},
          {id: 14, cat_id: 2, name: 'Bridge- substructure'},
          {id: 15, cat_id: 2, name: 'Bridge Foundations'}
      ];
      this.testNameList = [
          {id: 1, asset_id: 1, name: 'Roughness IRI', specification: 'Class I Profilometer : ASTM E950 (98) measuring Longitudinal Profile', desirable: '2000mm/km', acceptable: '3000mm/km', frequency: 'Bi-Annually', los_image: ''},
          {id: 2, asset_id: 1, name: 'Skid Number', specification: 'Class I Profilometer : ASTM E950 (98) measuring Longitudinal Profile', desirable: '60SN', acceptable: '50SN', frequency: 'Bi-Annually', los_image: ''},
          {id: 3, asset_id: 1, name: 'Rutting', specification: 'MORT&H Specification 3004.2', desirable: '<10mm for any 50 m section and/or, length of section <5m', acceptable: '<10mm for any 50 m section and/or, length of section <10m', frequency: 'Bi-Annually', los_image: ''},
          {id: 4, asset_id: 1, name: 'Pavement Condition Index', specification: 'IRC:82-2015', desirable: '>85', acceptable: '>70', frequency: 'Bi-Annually', los_image: ''},
          {id: 5, asset_id: 1, name: 'Other Pavement Distresses', specification: 'IRC:82-2015', desirable: 'NIL', acceptable: 'NIL', frequency: 'Bi-Annually', los_image: ''},
          {id: 6, asset_id: 1, name: 'Deflection/Remaining ng Life', specification: 'Falling Weight Deflectometer IRC 115: 2014', desirable: 'NIL', acceptable: 'NIL', frequency: 'Annually', los_image: ''},
          {id: 7, asset_id: 2, name: 'Roughness IRI BI', specification: 'Class I Profilometer ASTM E950 (98) :2004 and ASTM E1656 -94: 2000', desirable: '< 2200mm/km', acceptable: '3000mm/km', frequency: 'Bi-Annually', los_image: ''},
          {id: 8, asset_id: 2, name: 'Skid', specification: 'British Pendulum Tester IRC:SP:83-2008', desirable: '> 65 BPN', acceptable: '> 45 BPN', frequency: 'Bi-Annually', los_image: ''},
          {id: 9, asset_id: 3, name: 'Availability of Safe Sight Distance', specification: 'As per IRC SP :84-2014, a minimum of safe stopping sight distance shall be available throughout.', desirable: '', acceptable: '', frequency: 'Monthly', los_image: './assets/img/LOS/Availability-of-Safe-Sight-Distance.png'},
          {id: 10, asset_id: 4, name: 'Wear', specification: 'Visual Assessment as per Annexure-F of IRC:35-2015', desirable: 'NIL', acceptable: '<70% of marking remaining', frequency: 'Bi-Annually', los_image: ''},
          {id: 11, asset_id: 4, name: 'Day time Visibility', specification: 'As per Annexure-D of IRC:35-2015', desirable: 'NIL', acceptable: 'During expected life Service Time 1. Cement Road - 130mcd/m2/lux 2. Bituminous Road - 100mcd/m2/lux', frequency: 'Monthly', los_image: ''},
          {id: 12, asset_id: 4, name: 'Night Time Visibility Dry Condition', specification: 'As per Annexure-E of IRC:35-2015', desirable: '', acceptable: '', frequency: 'Bi-Annually', los_image: './assets/img/LOS/Night-Time-Visibility-Dry-Condition.png'},
          {id: 13, asset_id: 4, name: 'Night Time Visibility in Wet Condition', specification: 'As per Annexure-E of IRC:35-2015', desirable: 'NIL', acceptable: 'Initial and Minimum Performance for Night Visibility under wet condition (Retro reflectivity): 1.Initial 7 days Retro reflectivity: 100 mcd/m2/lux 2.Minimum Threshold Level:  100 mcd/m2/lux', frequency: 'Bi-Annually', los_image: ''},
          {id: 14, asset_id: 4, name: 'Skid Resistance', specification: '', desirable: 'NIL', acceptable: 'Initial and Minimum performance for Skid Resistance: 1. Initial (7days): 55BPN 2. Min. Threshold: 44BPN *Note: shall be considered under urban/city traffic condition encompassing the locations like pedestrian crossings, bus bay, bus stop, cycle track intersection delineation, transverse bar markings etc Signboard should be clearly visible for the design speed of the section.', frequency: 'Bi-Annually', los_image: ''},
          {id: 15, asset_id: 5, name: 'Shape and Position', specification: 'Shape and Position as per IRC:67- 2012.', desirable: 'NIL', acceptable: 'Signboard should be clearly visible for the design speed of the section.', frequency: 'Daily', los_image: ''},
          {id: 16, asset_id: 5, name: 'Retro reflectivity', specification: 'Testing of each signboard using Retro Reflectivity Measuring Device. In accordance with ASTM D 4956-09.', desirable: 'NIL', acceptable: 'As per specifications in IRC:67-2012', frequency: 'Bi-Annually', los_image: ''},
          {id: 17, asset_id: 6, name: 'Kerb Height', specification: 'As per IRC 86:1983 depending upon type of Kerb', desirable: 'NIL', acceptable: 'Use of distance measuring tape', frequency: 'Bi-Annually', los_image: ''},
          {id: 18, asset_id: 7, name: 'Illumination', specification: 'IRC:SP:84-2014', desirable: 'NIL', acceptable: 'Illumination: Minimum 40 Lux illumination on the road surface', frequency: 'Daily', los_image: ''},
          {id: 19, asset_id: 8, name: 'Illumination', specification: 'IRC:SP:84-2015', desirable: 'NIL', acceptable: 'Illumination Minimum 40 Lux illumination on the road surface', frequency: 'Daily', los_image: ''},
          {id: 20, asset_id: 9, name: 'Leak-proof expansion joints if any', specification: 'IRC SP:40-1993 and IRC SP:69- 2011', desirable: 'NIL', acceptable: 'No leakage through expansion joints', frequency: 'Bi-Annually', los_image: ''},
          {id: 21, asset_id: 9, name: 'Spalling', specification: 'IRC SP 40-1993 and MORTH Specifications clause 2800', desirable: 'NIL', acceptable: 'Spalling of concrete not more than 0.25 sqm', frequency: 'Bi-Annually', los_image: ''},
          {id: 22, asset_id: 9, name: 'Delamination of concrete', specification: 'IRC SP 40-1993 and MORTH Specifications clause 2800', desirable: 'Delamination of concrete not more than 0.25 sq.m.', acceptable: 'NIL', frequency: 'Bi-Annually', los_image: ''},
          {id: 23, asset_id: 9, name: 'Cracks', specification: 'IRC SP 40-1993 and MORTH Specifications clause 2800 recording the defects', desirable: 'NIL', acceptable: 'Cracks wider than 0.3 mm not more than 1m aggregate length', frequency: 'Bi-Annually', los_image: ''},
          {id: 24, asset_id: 9, name: 'Protection works in good condition', specification: 'IRC: SP 40-1993 and IRC:SP:13- 2004.', desirable: 'NIL', acceptable: 'Damaged of rough stone apron or bank revetment not more than 3 sq.m, damage to solid apron (concrete apron) not more than 1 sq.m', frequency: '2 times in a year (before and after rainy season)', los_image: ''},
          {id: 25, asset_id: 10, name: 'Rusted reinforcement', specification: 'IRC SP: 40-1993 and MORTH Specification 1600.', desirable: 'NIL', acceptable: 'Not more than 0.25 sq.m', frequency: 'Bi-Annually', los_image: ''},
          {id: 26, asset_id: 10, name: 'Spalling of concrete', specification: 'IIRC SP: 40-1993 and MORTH Specification 1600.', desirable: 'NIL', acceptable: 'Not more than 0.50 sq.m', frequency: 'Bi-Annually', los_image: ''},
          {id: 27, asset_id: 10, name: 'Delamination', specification: 'IRC SP: 40-1993 and MORTH Specification 1600.', desirable: 'NIL', acceptable: 'Not more than 0.50 sq.m', frequency: 'Bi-Annually', los_image: ''},
          {id: 28, asset_id: 10, name: 'Cracks wider than 0.30 mm', specification: 'IRC SP: 40-1993 and MORTH Specification 2800.', desirable: 'NIL', acceptable: 'Not more than 1m total length', frequency: 'Bi-Annually', los_image: ''},
          {id: 29, asset_id: 10, name: 'Rainwater seepage through deck slab', specification: 'MORTH specifications 2600 & 2700.', desirable: 'NIL', acceptable: 'Leakage - nil', frequency: 'Quarterly', los_image: ''},
          {id: 30, asset_id: 11, name: 'Deflection due to permanent loads and live loads', specification: 'IRC SP: 51-1999.', desirable: 'NIL', acceptable: 'Within design limits.', frequency: 'Once in every 10 years', los_image: ''},
          {id: 31, asset_id: 12, name: 'Vibrations in bridge deck due to moving trucks', specification: 'AASHTO LRFD specifications', desirable: 'NIL', acceptable: 'Frequency of vibrations shall not be more than 5 Hz', frequency: 'Once in every 5 years', los_image: ''},
          {id: 32, asset_id: 13, name: 'Vibrations in bridge deck due to moving trucks', specification: 'AASHTO LRFD specifications', desirable: 'NIL', acceptable: 'Frequency of vibrations shall not be more than 5 Hz', frequency: 'Every 10 years', los_image: ''},
          {id: 33, asset_id: 14, name: 'Leakage in Expansion joints', specification: 'MORTH specifications 2600 and IRC SP: 40-1993.', desirable: 'NIL', acceptable: 'No damage to elastomeric sealant compound in strip seal expansion joint, no leakage of rain water through expansion joint in case of buried and asphalt plug and copper strip joint.', frequency: 'Bi-Annually', los_image: ''},
          {id: 34, asset_id: 14, name: 'Debris and dust in strip seal expansion joint', specification: 'MORTH specifications 2600 and IRC SP: 40-1993.', desirable: 'NIL', acceptable: 'No dust or debris in expansion joint gap.', frequency: 'Monthly', los_image: ''},
          {id: 35, asset_id: 14, name: 'Drainage spouts', specification: 'MORTH specification 2700.', desirable: 'NIL', acceptable: 'No down take pipe missing/broken below soffit of the deck slab. No silt, debris, clogging of drainage spout collection chamber.', frequency: 'Monthly', los_image: ''},
          {id: 36, asset_id: 14, name: 'Cracks/spalling of concrete/rusted steel', specification: 'IRC SP: 40-1993 and MORTH specification 2800.', desirable: 'NIL', acceptable: 'No cracks, spalling of concrete and rusted steel', frequency: 'Bi-Annually', los_image: ''},
          {id: 37, asset_id: 14, name: 'Bearings', specification: 'MORTH specification 2810 and IRC SP: 40-199.', desirable: 'NIL', acceptable: 'Delamination of bearing reinforcement not more than 5%, cracking or tearing of rubber not more than 2 locations per side, no rupture of reinforcement or rubber', frequency: 'Bi-Annually', los_image: ''},
          {id: 38, asset_id: 15, name: 'Scouring around foundations', specification: 'IRC SP: 40- 1993, IRC 83- 2014, MORTH specification 2500', desirable: 'NIL', acceptable: 'Scouring shall not be lower than maximum scour level for the bridge', frequency: 'Bi-Annually', los_image: ''},
      ];
      this.issueTypeListMaster = [
          {id: 1, inspec_id: 1, name: 'Pavement'},
          {id: 2, inspec_id: 1, name: 'Embankment/Slope'},
          {id: 3, inspec_id: 1, name: 'Rigid Pavement'},
          {id: 4, inspec_id: 2, name: 'Pavement Marking'},
          {id: 5, inspec_id: 1, name: 'Road Signs'},
          {id: 6, inspec_id: 1, name: 'Kerb'},
          {id: 7, inspec_id: 1, name: 'Furnitures'},
          {id: 8, inspec_id: 1, name: 'Tree plantation'},
          {id: 9, inspec_id: 1, name: 'Other'},
          {id: 10, inspec_id: 2, name: 'Culverts'},
          {id: 11, inspec_id: 1, name: 'Bridges'},
          {id: 12, inspec_id: 1, name: 'Drainage'},
          {id: 13, inspec_id: 1, name: 'Amenities'},
          {id: 14, inspec_id: 1, name: 'Toll_Plaza'},
          {id: 15, inspec_id: 2, name: 'Highway'},
          {id: 16, inspec_id: 1, name: 'Other Road Furniture'},
          {id: 17, inspec_id: 1, name: 'Highway Lighting System'},
          {id: 18, inspec_id: 1, name: 'Rest Areas'},
          {id: 19, inspec_id: 2, name: 'Pipe/box/slab culverts'},
          {id: 20, inspec_id: 1, name: 'Bridge- Super Structure'},
          {id: 21, inspec_id: 2, name: 'Bridge- Substructure'},
          {id: 22, inspec_id: 2, name: 'Bridge Foundation'},
          {id: 23, inspec_id: 1, name: 'TMS Lane System'},
          {id: 24, inspec_id: 1, name: 'Plaza System'}
      ];
      this.srcIssueSubTypes = [
          {id: 1, cat_id: 1, inspec_id: 1, name: 'Pot holes', deadline_days: 2, treatment: 'Pot hole repairs'},
          {id: 2, cat_id: 1, inspec_id: 1, name: 'Cracking', deadline_days: 15, treatment: 'Crack sealing'},
          {id: 3, cat_id: 1, inspec_id: 1, name: 'Rutting', deadline_days: 30, treatment: 'Rutting repairs'},
          {id: 4, cat_id: 1, inspec_id: 1, name: 'Corrugations & Shoving', deadline_days: 7, treatment: 'Corrugation & Shoving repairs'},
          {id: 5, cat_id: 1, inspec_id: 1, name: 'Bleeding/Skidding', deadline_days: 7, treatment: 'Bleeding repairs'},
          {id: 6, cat_id: 1, inspec_id: 1, name: 'Ravelling/Stripping', deadline_days: 15, treatment: 'Ravelling repairs'},
          {id: 7, cat_id: 1, inspec_id: 1, name: 'Edge Deformation/Breaking', deadline_days: 15, treatment: 'Edge repairs'},
          {id: 8, cat_id: 1, inspec_id: 2, name: 'Others', deadline_days: 7, treatment: 'Appropriate repairs'},
          {id: 9, cat_id: 2, inspec_id: 1, name: 'Edge Drop at shoulders', deadline_days: 15, treatment: 'Shoulder repairs'},
          {id: 10, cat_id: 2, inspec_id: 1, name: 'Slope of Camber/ Cross fall', deadline_days: 15, treatment: 'Camber correction'},
          {id: 11, cat_id: 2, inspec_id: 1, name: 'Change in embankment slope', deadline_days: 15, treatment: 'Slope protection repairs'},
          {id: 12, cat_id: 2, inspec_id: 1, name: 'Rain cuts/ gullies in slope', deadline_days: 15, treatment: 'Slope protection repairs'},
          {id: 13, cat_id: 3, inspec_id: 1, name: 'Cracking', deadline_days: 15, treatment: 'Suitable cracking repairs'},
          {id: 14, cat_id: 3, inspec_id: 1, name: 'Ravelling/Honeycomb type surface', deadline_days: 15, treatment: 'Ravelling repairs'},
          {id: 15, cat_id: 3, inspec_id: 1, name: 'Scaling', deadline_days: 15, treatment: 'Scaling repairs'},
          {id: 16, cat_id: 3, inspec_id: 1, name: 'Popout/Pothole', deadline_days: 2, treatment: 'Pothole repairs'},
          {id: 17, cat_id: 3, inspec_id: 1, name: 'Joint Defects', deadline_days: 15, treatment: 'Joints repairs / replacement'},
          {id: 18, cat_id: 3, inspec_id: 1, name: 'Blowup/ Bulking', deadline_days: 15, treatment: 'Full depth repair'},
          {id: 19, cat_id: 3, inspec_id: 1, name: 'Depression', deadline_days: 15, treatment: 'Reinstate pavement'},
          {id: 20, cat_id: 3, inspec_id: 1, name: 'Heave', deadline_days: 15, treatment: 'Stabilize subgrade'},
          {id: 21, cat_id: 3, inspec_id: 1, name: 'Bump', deadline_days: 15, treatment: 'Gring the surface'},
          {id: 22, cat_id: 3, inspec_id: 1, name: 'Lane/Shoulder drop off', deadline_days: 15, treatment: 'Fill the shoulder'},
          {id: 23, cat_id: 3, inspec_id: 1, name: 'Drainage', deadline_days: 15, treatment: 'Drain repairs'},
          {id: 24, cat_id: 4, inspec_id: 2, name: 'Wear (Cat 1)', deadline_days: 1, treatment: 'As per IRC 35:2015'},
          {id: 25, cat_id: 4, inspec_id: 2, name: 'Wear (Cat 2)', deadline_days: 60, treatment: 'As per IRC 35:2015'},
          {id: 26, cat_id: 4, inspec_id: 2, name: 'Improper Day Time Visibility (Cat 1)', deadline_days: 1, treatment: 'As per IRC 35:2015'},
          {id: 27, cat_id: 4, inspec_id: 2, name: 'Improper Day Time Visibility (Cat 2)', deadline_days: 60, treatment: 'As per IRC 35:2015'},
          {id: 28, cat_id: 4, inspec_id: 2, name: 'Improper Night Time Visibility (Cat 1)', deadline_days: 1, treatment: 'As per IRC 35:2015'},
          {id: 29, cat_id: 4, inspec_id: 2, name: 'Improper Night Time Visibility (Cat 2)', deadline_days: 60, treatment: 'As per IRC 35:2015'},
          {id: 30, cat_id: 5, inspec_id: 1, name: 'Shape & Position (Mandatory Signboards)', deadline_days: 2, treatment: 'Improvement/Relocation'},
          {id: 31, cat_id: 5, inspec_id: 1, name: 'Shape & Position (Gantry/Cantilever Signboards)', deadline_days: 15, treatment: 'Improvement/Relocation'},
          {id: 32, cat_id: 5, inspec_id: 3, name: 'Retro reflectivity (Mandatory Signboards)', deadline_days: 2, treatment: 'Change of Sign board'},
          {id: 33, cat_id: 5, inspec_id: 3, name: 'Retro reflectivity (Gantry/Cantilever Signboards)', deadline_days: 30, treatment: 'Change of Sign board'},
          {id: 34, cat_id: 6, inspec_id: 2, name: 'Inadequate Height', deadline_days: 30, treatment: 'Raising of Kerb height'},
          {id: 35, cat_id: 6, inspec_id: 1, name: 'Worn out Paint', deadline_days: 7, treatment: 'Repainting'},
          {id: 36, cat_id: 7, inspec_id: 1, name: 'Road studs - Damaged/Theft', deadline_days: 60, treatment: 'New installation'},
          {id: 37, cat_id: 7, inspec_id: 1, name: 'Crash barrier / PGR - Damaged', deadline_days: 15, treatment: 'Replacement of crash barrier / PGR'},
          {id: 38, cat_id: 7, inspec_id: 1, name: 'Traffic safety barrier - Damaged', deadline_days: 7, treatment: 'Rectification'},
          {id: 39, cat_id: 7, inspec_id: 1, name: 'Attenuators - Damaged', deadline_days: 7, treatment: 'Rectification'},
          {id: 40, cat_id: 7, inspec_id: 1, name: 'Guard post/ Delineators/ Overhead sign structure - Damaged', deadline_days: 15, treatment: 'Rectification'},
          {id: 41, cat_id: 7, inspec_id: 1, name: 'Traffic Blinkers - Damaged', deadline_days: 7, treatment: 'Rectification'},
          {id: 42, cat_id: 7, inspec_id: 1, name: 'Milestones - Damaged / Theft', deadline_days: 25, treatment: 'Replacement of milestones'},
          {id: 43, cat_id: 7, inspec_id: 1, name: 'Traffic Signs - Damaged / Theft', deadline_days: 25, treatment: 'Replacement of sign board'},
          {id: 44, cat_id: 7, inspec_id: 1, name: 'Light fixtures - Damaged / Theft', deadline_days: 1, treatment: 'Replacement / repair of fixtures'},
          {id: 45, cat_id: 7, inspec_id: 1, name: 'Light fixtures - Non-functioning', deadline_days: 1, treatment: 'Replacement / electric repairs'},
          {id: 46, cat_id: 8, inspec_id: 2, name: 'Tree causing obstruction in a min headroom of 5.5m', deadline_days: 1, treatment: 'Removal of tree'},
          {id: 47, cat_id: 8, inspec_id: 1, name: 'Detoration in health of trees', deadline_days: 90, treatment: 'Timely watering/necessary treatment'},
          {id: 48, cat_id: 9, inspec_id: 1, name: 'Other Project facilities & approach roads - Damage/detoriation', deadline_days: 15, treatment: 'Repair'},
          {id: 49, cat_id: 10, inspec_id: 2, name: 'Obstructed flow section', deadline_days: 30, treatment: 'Clearing of debris'},
          {id: 50, cat_id: 10, inspec_id: 2, name: 'Expansion joint - Damaged', deadline_days: 30, treatment: 'Fixing with sealant '},
          {id: 51, cat_id: 10, inspec_id: 2, name: 'Protection works - Damaged', deadline_days: 30, treatment: 'Suitable repairs'},
          {id: 52, cat_id: 11, inspec_id: 1, name: 'Poor riding quality', deadline_days: 15, treatment: 'Repairing of wearing coat'},
          {id: 53, cat_id: 11, inspec_id: 1, name: 'Bump at expansion Joint', deadline_days: 15, treatment: 'Repair of BC/Profile correction'},
          {id: 54, cat_id: 11, inspec_id: 1, name: 'Crash barrier/ Guard rail - Damaged', deadline_days: 3, treatment: 'Repair/Replacement'},
          {id: 55, cat_id: 11, inspec_id: 2, name: 'Rusted reinforcements', deadline_days: 15, treatment: 'Applynig anti-corrosive coat'},
          {id: 56, cat_id: 11, inspec_id: 2, name: 'Spaling of concrete', deadline_days: 15, treatment: 'Repair with epoxy mortar/concrete'},
          {id: 57, cat_id: 11, inspec_id: 1, name: 'Delamination', deadline_days: 15, treatment: 'Repair with epoxy mortar/concrete'},
          {id: 58, cat_id: 11, inspec_id: 1, name: 'Deck surface defects', deadline_days: 30, treatment: 'Deck surface repairs'},
          {id: 59, cat_id: 11, inspec_id: 2, name: 'Exp joints deformation / damage', deadline_days: 15, treatment: 'Joints repairs / replacement'},
          {id: 60, cat_id: 11, inspec_id: 2, name: 'Clogging of drainage spouts', deadline_days: 3, treatment: 'Cleaning'},
          {id: 61, cat_id: 11, inspec_id: 2, name: 'Bearing deformation / damage', deadline_days: 90, treatment: 'Bearing repairs / replacements'},
          {id: 62, cat_id: 11, inspec_id: 2, name: 'Scouring around foundation', deadline_days: 30, treatment: 'Suitable protection works'},
          {id: 63, cat_id: 12, inspec_id: 1, name: 'Median drains - Chocking/silt', deadline_days: 25, treatment: 'Median Drain cleaning'},
          {id: 64, cat_id: 12, inspec_id: 1, name: 'RCC drains - Chocking/silt', deadline_days: 25, treatment: 'RCC drain cleaning'},
          {id: 65, cat_id: 12, inspec_id: 1, name: 'Earthen drains - Chocking/silt', deadline_days: 25, treatment: 'Earthen drain cleaning'},
          {id: 66, cat_id: 12, inspec_id: 1, name: 'Culverts - Chocking/silt', deadline_days: 25, treatment: 'Culvert cleaning'},
          {id: 67, cat_id: 13, inspec_id: 1, name: 'Truck/Bus Bay - Litter/Dust/Dirt', deadline_days: 25, treatment: 'Cleaning & repairs'},
          {id: 68, cat_id: 13, inspec_id: 1, name: 'Toilet blocks - Unhygienic condition', deadline_days: 1, treatment: 'Cleaning & repairs'},
          {id: 69, cat_id: 14, inspec_id: 1, name: 'Plaza Rigid pavement -  defects & damages', deadline_days: 25, treatment: 'PPot hole / panel repairot'},
          {id: 70, cat_id: 14, inspec_id: 1, name: 'Plaza cleaning - litter/dust/dirt', deadline_days: 1, treatment: 'Plaza cleaning'},
          {id: 71, cat_id: 15, inspec_id: 2, name: 'Availability of Safe Sight Distance', deadline_days: 1, treatment: 'Removal of obstruction within 24 hours, in case of sight line affected by temporary objects such as trees, temporary encroachments.In case of permanent structure or design deficiency: Removal of obstruction/improvement of deficiency at the earliest. Speed Restriction boards and suitable traffic calming measures such as transverse bar marking, blinkers, etc. shall be applied during the period of rectification.'},
          {id: 72, cat_id: 16, inspec_id: 1, name: 'Reflective PavementMarkers (Road Studs)', deadline_days: 60, treatment: 'New Installation'},
          {id: 73, cat_id: 16, inspec_id: 1, name: 'Pedestrian Guardrail', deadline_days: 15, treatment: 'Rectification'},
          {id: 74, cat_id: 16, inspec_id: 1, name: 'Traffic Safety Barriers', deadline_days: 7, treatment: 'Rectification'},
          {id: 75, cat_id: 16, inspec_id: 1, name: 'End Treatment of Traffic Safety Barriers', deadline_days: 7, treatment: 'Rectification'},
          {id: 76, cat_id: 16, inspec_id: 1, name: 'Attenuators', deadline_days: 7, treatment: 'Rectification'},
          {id: 77, cat_id: 16, inspec_id: 1, name: 'Guard Posts and Delineators', deadline_days: 1, treatment: ''},
          {id: 78, cat_id: 16, inspec_id: 1, name: 'Overhead Sign Structure', deadline_days: 15, treatment: 'Rectification'},
          {id: 79, cat_id: 16, inspec_id: 1, name: 'Traffic Blinkers', deadline_days: 7, treatment: 'Rectification'},
          {id: 80, cat_id: 17, inspec_id: 1, name: 'Highway Lights', deadline_days: 1, treatment: 'Improvement in Lighting System'},
          {id: 81, cat_id: 17, inspec_id: 2, name: 'Highway Lights', deadline_days: 1, treatment: 'Rectification of failure'},
          {id: 82, cat_id: 17, inspec_id: 1, name: 'Toll Plaza Canopy Lights', deadline_days: 1, treatment: 'Improvement in Lighting System'},
          {id: 83, cat_id: 18, inspec_id: 1, name: 'Cleaning of toilets', deadline_days: 1, treatment: ''},
          {id: 84, cat_id: 18, inspec_id: 1, name: 'Defects in electrical, water and sanitary - installations', deadline_days: 1, treatment: ''},
          {id: 85, cat_id: 19, inspec_id: 2, name: 'Free waterway/unobstructed flow section', deadline_days: 15, treatment: 'Cleaning silt up soils and debris in culvert barrel after rainy season, removal of bushes and vegetation, U/s of barrel, under barrel and D/s of barrel before rainy season.'},
          {id: 86, cat_id: 19, inspec_id: 2, name: 'Leak-proof expansion joints if any', deadline_days: 30, treatment: 'Fixing with sealant suitably'},
          {id: 87, cat_id: 19, inspec_id: 2, name: 'Structurally sound', deadline_days: 15, treatment: 'Repairs to spalling, cracking, delamination, rusting shall be followed as per IRC:SP:40-1993.'},
          {id: 88, cat_id: 19, inspec_id: 2, name: 'Protection works in good condition', deadline_days: 30, treatment: 'Repairs to damaged aprons and pitching'},
          {id: 89, cat_id: 20, inspec_id: 1, name: 'User safety (condition of crash barrier and guard rail)', deadline_days: 3, treatment: 'Repairs and replacement of safety barriers as the case may be'},
          {id: 90, cat_id: 20, inspec_id: 2, name: 'Rusted reinforcement', deadline_days: 15, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti-corrosive coating before carrying out the repairs to affected concrete portion with epoxy mortar/concrete.'},
          {id: 91, cat_id: 20, inspec_id: 2, name: 'Spalling of concrete', deadline_days: 15, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti-corrosive coating before carrying out the repairs to affected concrete portion with epoxy mortar/concrete.'},
          {id: 92, cat_id: 20, inspec_id: 1, name: 'Delamination', deadline_days: 15, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti-corrosive coating before carrying out the repairs to affected concrete portion with epoxy mortar/concrete.'},
          {id: 93, cat_id: 20, inspec_id: 2, name: 'Cracks wider than 0.30 mm', deadline_days: 2, treatment: 'Grouting with epoxy mortar, investigating causes for cracks development and carry out necessary rehabilitation.'},
          {id: 94, cat_id: 20, inspec_id: 2, name: 'Rainwater seepage through deck slab', deadline_days: 30, treatment: 'Grouting of deck slab at leakage areas, waterproofing, repairs to drainage spouts'},
          {id: 95, cat_id: 20, inspec_id: 3, name: 'Deflection due to permanent loads and live loads', deadline_days: 180, treatment: 'Carry out major rehabilitation works on bridge to retain original design loads capacity'},
          {id: 96, cat_id: 20, inspec_id: 3, name: 'Vibrations in bridge deck due to moving trucks', deadline_days: 120, treatment: 'Strengthening of super structure'},
          {id: 97, cat_id: 20, inspec_id: 2, name: 'Leakage in Expansion joints', deadline_days: 15, treatment: 'Replace of seal in expansion joint'},
          {id: 98, cat_id: 20, inspec_id: 2, name: 'Debris and dust in strip seal expansion joint', deadline_days: 3, treatment: 'Cleaning of expansion joint gaps thoroughly'},
          {id: 99, cat_id: 20, inspec_id: 2, name: 'Drainage spouts', deadline_days: 3, treatment: 'Cleaning of drainage spouts thoroughly. Replacement of missing/broken down take pipes with a minimum pipe extension of 500mm below soffit of slab. Providing sealant around the drainage spout if any leakages observed.'},
          {id: 100, cat_id: 21, inspec_id: 2, name: 'Cracks/spalling of concrete/rusted steel', deadline_days: 30, treatment: 'All the corroded reinforcement shall need to be thoroughly cleaned from rusting and applied with anti- corrosive coating before carrying out repairs to substructure by grouting/guiniting and micro concreting depending on type of defect noticed'},
          {id: 101, cat_id: 21, inspec_id: 2, name: 'Bearings', deadline_days: 90, treatment: 'In case of failure of even one bearing on any pier/abutment, all the bearings on that pier/abutment shall be replaced, in order to get uniform load transfer on to bearings.'},
          {id: 102, cat_id: 22, inspec_id: 2, name: 'Scouring around foundations', deadline_days: 30, treatment: 'Suitable protection works around pier/abutment'},
          {id: 103, cat_id: 23, inspec_id: 1, name: 'Toll Lane Controller', deadline_days: 1, treatment: ''},
          {id: 104, cat_id: 23, inspec_id: 1, name: 'AVC Controller', deadline_days: 1, treatment: ''},
          {id: 105, cat_id: 23, inspec_id: 1, name: 'Operator Monitor', deadline_days: 1, treatment: ''},
          {id: 106, cat_id: 23, inspec_id: 1, name: 'Dedicated Keyboard', deadline_days: 1, treatment: ''},
          {id: 107, cat_id: 23, inspec_id: 1, name: 'Receipt Printer', deadline_days: 1, treatment: ''},
          {id: 108, cat_id: 23, inspec_id: 1, name: 'Overhead Lane Signal', deadline_days: 1, treatment: ''},
          {id: 109, cat_id: 23, inspec_id: 1, name: 'User Fare Display', deadline_days: 1, treatment: ''},
          {id: 110, cat_id: 23, inspec_id: 1, name: 'High Speed Barriers (0.9 sec)', deadline_days: 1, treatment: ''},
          {id: 111, cat_id: 23, inspec_id: 1, name: 'Traffic light', deadline_days: 1, treatment: ''},
          {id: 112, cat_id: 23, inspec_id: 1, name: 'Manual Booth Controller', deadline_days: 1, treatment: ''},
          {id: 113, cat_id: 23, inspec_id: 1, name: 'Siren with Amber light', deadline_days: 1, treatment: ''},
          {id: 114, cat_id: 23, inspec_id: 1, name: 'Bar Code Readers', deadline_days: 1, treatment: ''},
          {id: 115, cat_id: 23, inspec_id: 1, name: 'Panic Alarm Switch', deadline_days: 1, treatment: ''},
          {id: 116, cat_id: 23, inspec_id: 1, name: 'Incident Camera', deadline_days: 1, treatment: ''},
          {id: 117, cat_id: 23, inspec_id: 1, name: 'Cash drawers', deadline_days: 1, treatment: ''},
          {id: 118, cat_id: 23, inspec_id: 1, name: 'Smart card reader', deadline_days: 1, treatment: ''},
          {id: 119, cat_id: 23, inspec_id: 1, name: 'SSWIM', deadline_days: 1, treatment: ''},
          {id: 120, cat_id: 23, inspec_id: 1, name: 'ETC Reader', deadline_days: 1, treatment: ''},
          {id: 121, cat_id: 24, inspec_id: 1, name: 'Plaza Server', deadline_days: 1, treatment: ''},
          {id: 122, cat_id: 24, inspec_id: 1, name: 'Workstations', deadline_days: 1, treatment: ''},
          {id: 123, cat_id: 24, inspec_id: 1, name: 'Laser Printer', deadline_days: 1, treatment: ''},
          {id: 124, cat_id: 24, inspec_id: 1, name: 'Point of Sale', deadline_days: 1, treatment: ''},
          {id: 125, cat_id: 24, inspec_id: 1, name: 'Networking Switches', deadline_days: 1, treatment: ''},
          {id: 126, cat_id: 24, inspec_id: 1, name: 'Networking Wiring', deadline_days: 1, treatment: ''},
          {id: 127, cat_id: 24, inspec_id: 1, name: 'Cabling & Accessories', deadline_days: 1, treatment: ''},
          {id: 128, cat_id: 24, inspec_id: 1, name: 'Master Intercom', deadline_days: 1, treatment: ''},
          {id: 129, cat_id: 24, inspec_id: 1, name: 'UPS Control Room', deadline_days: 1, treatment: ''},
          {id: 130, cat_id: 24, inspec_id: 1, name: 'Incident Capture Software', deadline_days: 1, treatment: ''},
          {id: 131, cat_id: 24, inspec_id: 1, name: 'UPS ETC Lane', deadline_days: 1, treatment: ''},
          {id: 132, cat_id: 24, inspec_id: 1, name: 'UPS Cash Lane', deadline_days: 1, treatment: ''},
          {id: 133, cat_id: 24, inspec_id: 1, name: 'UPS AVC', deadline_days: 1, treatment: ''},
          {id: 134, cat_id: 24, inspec_id: 1, name: 'Plaza monitoring camera', deadline_days: 1, treatment: ''},
          {id: 135, cat_id: 24, inspec_id: 1, name: 'DVR (Toll Plaza)', deadline_days: 1, treatment: ''},
          {id: 136, cat_id: 24, inspec_id: 1, name: 'CCTV Monitor', deadline_days: 1, treatment: ''},
          {id: 137, cat_id: 1, inspec_id: 2, name: 'Roughness beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008'},
          {id: 138, cat_id: 1, inspec_id: 2, name: 'Skid number beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008'},
          {id: 139, cat_id: 1, inspec_id: 2, name: 'Rutting beyond LOS', deadline_days: 30, treatment: 'MORT&H Specification 3004.2'},
          {id: 140, cat_id: 1, inspec_id: 2, name: 'Pavement Condition Index beyond LOS', deadline_days: 180, treatment: 'IRC:82-2015'},
          {id: 141, cat_id: 1, inspec_id: 2, name: 'Other Pavement Distresses beyond LOS', deadline_days: 7, treatment: 'IRC:82-2015'},
          {id: 142, cat_id: 1, inspec_id: 2, name: 'Deflection/Remaining Life criteria infringement', deadline_days: 180, treatment: 'IRC:115-2014'},
          {id: 143, cat_id: 3, inspec_id: 2, name: 'Roughness beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008'},
          {id: 144, cat_id: 3, inspec_id: 2, name: 'Skid number beyond LOS', deadline_days: 180, treatment: 'IRC:SP:83-2008'},
      ];
  }

  getIssueTypeId(projectId, type, status) {
      this.reportService.getIssueTypeId(projectId, type).subscribe((res: any) => {
          if (res.length > 0) {
              this.getIssues(res[0].id, res[0].name, status);
          } else {
              this.dataTable = {
                  dataRows: []
              };
              this.issues = [];
          }
      },
          err => {
          }
      );
  }

  getIssues(typeId: any, typeName:any, status: any) {
      this.typeId = typeId;
      this.typeName = typeName;
      this.issueStatus = status;
      var startDateString = this.startDate.format('YYYY-MM-DD');
      var endDateString = this.endDate.format('YYYY-MM-DD');
      this.reportService.getIssues(this.projectId.toString(), typeId, typeName, status,this.statusId, startDateString, endDateString, this.asset_type, this.performace_parameter).subscribe((res:any) => {
          this.dataTable = {
              dataRows: []
          };
          this.issues = res;
          this.dataTable.dataRows = this.issues;
          this.dataTable.dataRows.forEach((item, index) => {
              this.dataTable.dataRows[index]['created_date'] = item['created_date'].substring(0, 10);
              this.dataTable.dataRows[index]['inspPhoto'] = [];
              this.dataTable.dataRows[index]['maintPhoto'] = [];
          });
          if((this.selectedType == 'Issue' || this.selectedType == 'Compliance') && this.photo_selection == 'with photo'){
            this.getAttachments();
          }
          this.isReportGenerated = false;
      }, err => {});
  }

  getAttachments() {
      this.dataTable.dataRows.forEach((item, index) => {
          var issueId = item['id'];
          this.reportService.getIssueAttachments(this.projectId, issueId).subscribe((res: any) => {
            var newIssueAttachments = [];
            var newComplianceAttachments = [];
            res.forEach((attachmentDetails, index) => {
              var url = attachmentDetails.url;
              var extension = (/[.]/.exec(url)) ? /[^.]+$/.exec(url) : undefined;
              if (this.allImageExtensions.indexOf(extension+'')==-1){
                  attachmentDetails['isFile'] = true;
              }else{
                  attachmentDetails['isFile'] = false;
              }
              if (attachmentDetails.description == 'Compliances') {
                  newComplianceAttachments.push(attachmentDetails);
              }else{
                  newIssueAttachments.push(attachmentDetails);
              }
            });
              this.dataTable.dataRows[index]['inspPhoto'] = newIssueAttachments;
              this.dataTable.dataRows[index]['maintPhoto'] = newComplianceAttachments;
          }, err => {});
      });
  }

  showErrorMsg(msg: any) {
    swal({
      type: 'warning',
      html: msg,
      confirmButtonClass: 'btn btn-success',
      buttonsStyling: false
    })
  }

  onInvestigationAssetSelected(selectedAsset: any) {
      if (selectedAsset != '') {
          if (this.selectedType == 'Investigation') {
              var cat_id = '';
              this.testAssetList.forEach((item, index) => {
                  if (item.name == selectedAsset) {
                      cat_id = item.id
                  }
              });
              var newAssetList = [];
              this.testNameList.forEach((item, index) => {
                  if (item.asset_id == cat_id) {
                      newAssetList.push(item);
                  }
              });
              this.selectedTestNameList = newAssetList;
              this.performace_parameter = "";
          } else {
              var cat_id = '';
              this.issueTypeListMaster.forEach((item, index) => {
                  if (item.name == selectedAsset) {
                      cat_id = item.id
                  }
              });
              var newAssetList = [];
              this.srcIssueSubTypes.forEach((item, index) => {
                  if (item.cat_id == cat_id) {
                      newAssetList.push(item);
                  }
              });
              this.selectedTestNameList = newAssetList;
              this.performace_parameter = "";
          }
          if (this.typeId != '' && this.issueStatus != '' && this.typeName!='') {
              this.getIssues(this.typeId, this.typeName, this.issueStatus);
          }
      }else{
          this.performace_parameter = "";
          this.selectedTestNameList = [];
          if(this.typeId != '' && this.issueStatus != '' && this.typeName!=''){
              this.getIssues(this.typeId, this.typeName, this.issueStatus);
          }
      }
  }

  onInvestigationTestSelected() {
      if (this.typeId != '' && this.issueStatus != '' && this.typeName!='') {
          this.getIssues(this.typeId, this.typeName, this.issueStatus);
      }
  }

  onPhotoOptionSelected(photoSelection: any) {
      if (photoSelection != '') {
          if(this.typeId != '' && this.issueStatus != '' && this.typeName!=''){
              this.getIssues(this.typeId, this.typeName, this.issueStatus);
          }
      }
  }
  
  getProjectTitle() {
    let projectTitle = localStorage.getItem('project_title') || '';
    return projectTitle;
  }

  fromDateChange(res) {
      if (res.startDate != null) {
          var newStartDate = res.startDate;
          if (newStartDate.isAfter(this.endDate)) {
              this.showErrorMsg('Please select valid from date');
          } else {
              this.startDate = newStartDate;
              if(this.typeId != '' && this.issueStatus != '' && this.typeName!=''){
                  this.getIssues(this.typeId, this.typeName, this.issueStatus);
              }
          }
      }
  }

  toDateChange(res) {
      if (res.endDate != null) {
          var newEndDate = res.endDate;
          if (newEndDate.isBefore(this.startDate)) {
              this.showErrorMsg('Please select valid to date');
          } else {
              this.endDate = newEndDate;
              if(this.typeId != '' && this.issueStatus != '' && this.typeName!=''){
                  this.getIssues(this.typeId, this.typeName, this.issueStatus);
              }
          }
      }
  }

  onExportProjectClicked(type: String) {
    this.selectedType = type;
    this.asset_type = '';
    this.selectedTestNameList = [];
    this.performace_parameter = '';
    this.photo_selection = 'with photo';
    if(this.selectedType == 'Investigation'){
        this.selectedAssetList = this.testAssetList;
    }else{
        this.selectedAssetList = this.issueTypeListMaster;
    }
    switch (this.selectedType) {
        case 'Issue':
            this.dataTable = {
                dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Issue', 'Open');
            break;
        case 'Compliance':
            this.dataTable = {
                dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Issue', 'Closed');
            break;
        case 'Accident':
            this.dataTable = {
                dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Accident', 'Open');
            break;
        case 'Investigation':
            this.dataTable = {
                dataRows: []
            };
            this.getIssueTypeId(this.projectId, 'Investigation', 'Open');
            break;
    }
  }
  onExportCsvOrPdf(exportType){
    var startDateString = this.startDate.format('YYYY-MM-DD');
    var endDateString = this.endDate.format('YYYY-MM-DD');
    this.exportMsg = 'Generating report of the project. Please DO NOT close this page.'
    this.reportService.exportProject(this.projectId.toString(), this.selectedType, startDateString, endDateString, this.asset_type, this.performace_parameter, this.photo_selection, exportType, this.statusId).subscribe(res => {
      this.reportObj = res;
      this.isReportGenerated = true;
      this.exportMsg = 'If the download doesn\'t start automatically';
      var selectedAsset = "";
      if(this.asset_type!=''){
        selectedAsset = "&asset_cat=" + this.asset_type;
      }
      var selectedPerformance = "";
      if(this.performace_parameter!=''){
        selectedPerformance = "&performance_cat=" + this.performace_parameter;
      }
      var selectedReportType = "";
      if (this.selectedType == 'Accident'){
          selectedReportType = "&accident_report_type=" + this.report_type;
      }
      if (this.selectedType == 'Compliance'){
        this.downloadURL = environment.BASE_URL + "api/v1/issues/csv?uuid=" + this.reportObj.uuid + "&start_date=" + startDateString + "&end_date=" + endDateString + "&type=Issue&status=" + this.statusId + selectedAsset + selectedPerformance + selectedReportType + "&photo=" + this.photo_selection + "&doc_type=" + exportType + "&type_name=" + this.selectedType;
      }else{
        this.downloadURL = environment.BASE_URL + "api/v1/issues/csv?uuid=" + this.reportObj.uuid + "&start_date=" + startDateString + "&end_date=" + endDateString + "&type=" + this.selectedType + selectedAsset + selectedPerformance + selectedReportType + "&photo=" + this.photo_selection + "&doc_type=" + exportType + "&type_name=" + this.selectedType;
      }
    },
      err => {
          swal({
          type: 'warning',
          html: err.error._error_message,
          confirmButtonClass: 'btn btn-success',
          buttonsStyling: false
        })
      }
    );
  }
  ngAfterViewInit() {
//      $('#datatable').DataTable({
//          "bFilter": false,
//          "bInfo": false,
//          responsive: true,
//          "language": {
//              emptyTable: null,
//              loadingRecords: null,
//              zeroRecords: null
//          },
//          "order": [[1, "desc"]]
//      });
//      var table = $('#datatable').DataTable();
//      table.on('click', '.edit', function () {
//          let $tr = $(this).closest('tr');
//          var data = table.row($tr).data();
//          alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
//      });
//      table.on('click', '.remove', function (e) {
//          let $tr = $(this).closest('tr');
//          table.row($tr).remove().draw();
//          e.preventDefault();
//      });
//      table.on('click', '.like', function () {
//          alert('You clicked on Like button');
//      });
  }
}