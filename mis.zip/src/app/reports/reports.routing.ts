import { Routes } from '@angular/router';
import { ReportsComponent } from './reports.component';

export const ReportsRoutes: Routes = [{
    path: 'reports',
    children: [{
        path: '',
        component: ReportsComponent
    }]
}];