import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ProfileService } from './profile.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  userData = {
    full_name: '',
    email: '',
    mobile_no: '',
    aadhaar_no: '',
    address: ''
  }
  changePasswordData = {
    current_password: '',
    password: '',
    cpassword: ''
  }
  showOldPasswordError: boolean = false;
  showNewPasswordError: boolean = false;
  showConfirmPasswordError: boolean = false;
  showNameError: boolean = false;
  showAddressError: boolean = false;
  nameErrorMsg = '*Invalid name';
  addressErrorMsg = '*Invalid address';
  oldPasswordErrorMsg = '*Invalid password';
  newPasswordErrorMsg = '*Invalid password';
  confirmPasswordErrorMsg = '*Invalid password';

  constructor(private titleService: Title,
    private profileService: ProfileService) { }

  ngOnInit() {
    localStorage.setItem('page_title', 'Profile');
    this.titleService.setTitle('Profile - Asset Management Tool');
    this.userData = JSON.parse(localStorage.getItem('user_data'));
  }

  onUpdateProfile() {
    this.showNameError = false;
    this.showAddressError = false;
    if (this.userData.full_name.length >= 2 && /^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/.test(this.userData.full_name)) {
      if (this.userData.address.length >= 2) {
        this.profileService.updateProfile(this.userData).subscribe(res => {
          localStorage.setItem('user_data', JSON.stringify(res));
          this.userData = JSON.parse(localStorage.getItem('user_data'));
          swal({
            type: 'success',
            html: 'Profile updated successfully.',
            confirmButtonClass: 'btn btn-success',
            buttonsStyling: false
          })
        },
          err => {
            swal({
              type: 'warning',
              html: err.error._error_message,
              confirmButtonClass: 'btn btn-success',
              buttonsStyling: false
            })
          }
        );
      } else
        this.showAddressError = true;
    } else
      this.showNameError = true;
  }

  onChangePassword() {
    this.showOldPasswordError = false;
    this.showNewPasswordError = false;
    this.showConfirmPasswordError = false;
    var pattern = new RegExp(/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{7,19}$/);
    if (this.changePasswordData.current_password.length >= 6 && pattern.test(this.changePasswordData.current_password)) {
      if (this.changePasswordData.password.length >= 6 && pattern.test(this.changePasswordData.password)) {
        if (this.changePasswordData.cpassword.length >= 6 && pattern.test(this.changePasswordData.cpassword)) {
          if (this.changePasswordData.password === this.changePasswordData.cpassword) {
            this.profileService.changePassword(this.changePasswordData).subscribe(res => {
              swal({
                type: 'success',
                html: 'Password updated successfully.',
                confirmButtonClass: 'btn btn-success',
                buttonsStyling: false
              })
            },
              err => {
                swal({
                  type: 'warning',
                  html: err.error._error_message,
                  confirmButtonClass: 'btn btn-success',
                  buttonsStyling: false
                })
              }
            );
          } else {
            this.showConfirmPasswordError = true;
            this.confirmPasswordErrorMsg = '*Password does not matches';
          }
        } else {
          this.showConfirmPasswordError = true;
          this.confirmPasswordErrorMsg = '*Invalid password';
        }
      } else {
        this.showNewPasswordError = true;
        this.newPasswordErrorMsg = '*Invalid password';
      }
    } else {
      this.showOldPasswordError = true;
      this.oldPasswordErrorMsg = '*Invalid password';
    }
  }

  resetPasswordFields() {
    this.changePasswordData = {
      current_password: '',
      password: '',
      cpassword: ''
    }
  }
}