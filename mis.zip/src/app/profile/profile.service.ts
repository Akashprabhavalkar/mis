import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class ProfileService {
    constructor(private http: HttpClient) { }

    updateProfile(updateProfile: any) {
        var payload = {
            full_name: updateProfile.full_name,
            username: updateProfile.username,
            address: updateProfile.address,
            read_new_terms: true,
        }
        var user_data = JSON.parse(localStorage.getItem('user_data'));
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/users/" + user_data.id, payload, options)
    }

    changePassword(passwordObj: any) {
        var payload = {
            'current_password': passwordObj.current_password,
            'password': passwordObj.password
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/users/change_password", payload, options)
    }
}