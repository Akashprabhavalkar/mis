import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class DashboardService {
    constructor(private http: HttpClient) { }

    getDashboardStats(projectId: any) {
        let user_data = JSON.parse(localStorage.getItem('user_data'));
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "dashboard/" + projectId, options)
    }

    getIssueStatuses(projectId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-statuses?project=" + projectId, options)
    }

    getUserDetails() {
        let user_data = JSON.parse(localStorage.getItem('user_data'));
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/users/" + user_data.id, options)
    }

    getGraph(projectId: any) {
        let user_data = JSON.parse(localStorage.getItem('user_data'));
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "dashboard-graph-data/" + projectId, options)
    }

    getProjects() {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/projects", options)
    }
}