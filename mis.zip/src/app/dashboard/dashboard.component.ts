import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardService } from './dashboard.service';
import Chart from 'chart.js';
import swal from 'sweetalert2';

declare const $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public gradientStroke;
  public chartColor;
  public canvas: any;
  public ctx;
  public gradientFill;
  public gradientChartOptionsConfiguration: any;
  public gradientChartOptionsConfigurationWithNumbersAndGrid: any;
  public activeUsersChartType;
  public activeUsersChartData: Array<any>;
  public activeUsersChartOptions: any;
  public activeUsersChartLabels: Array<any>;
  public activeUsersChartColors: Array<any>;
  isProjectSelected: boolean = false;
  isShowRegisterCompliance: boolean = false;
  isShowKPIReport: boolean = false;
  registerComplianceStatusId: String = '';
  issuesIdentifiedCount: String = 'NA';
  issuesClosedCount: String = 'NA';
  accidentsReportedCount: String = 'NA';
  usersCount: String = '';
  testAndInvestigationCount: String = '';
  projectNotSelectedMsg: String = '';
  selected_project;
  selected_project_id;
  dashboardObj;
  projectList;
  userDetailsObj;
  numIssuesIdentified: Number = 0;
  numIssuesClosed = 0;
  numAccidentsReported = 0;
  userType;

  constructor(private titleService: Title,
    private dashboardService: DashboardService,
    private _router: Router) {

  }

  public chartClicked(e: any): void {
  }

  public chartHovered(e: any): void {
  }
  public hexToRGB(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16),
      g = parseInt(hex.slice(3, 5), 16),
      b = parseInt(hex.slice(5, 7), 16);

    if (alpha) {
      return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
    } else {
      return "rgb(" + r + ", " + g + ", " + b + ")";
    }
  }
  public ngOnInit() {
    this.projectNotSelectedMsg = 'Please wait... Loading projects';
    this.getProjects();
    this.getUserDetails();
    // this.getDashboardStats();
    this.getUserDetails();
    localStorage.setItem('page_title', 'Dashboard');
    this.titleService.setTitle('Dashboard - Asset Management Tool');
    this.chartColor = "#FFFFFF";
    var cardStatsMiniLineColor = "#fff",
      cardStatsMiniDotColor = "#fff";
    this.canvas = document.getElementById("chartActivity");
    this.ctx = this.canvas.getContext("2d");
    this.gradientStroke = this.ctx.createLinearGradient(500, 0, 100, 0);
    this.gradientStroke.addColorStop(0, '#80b6f4');
    this.gradientStroke.addColorStop(1, this.chartColor);
    this.gradientFill = this.ctx.createLinearGradient(0, 170, 0, 50);
    this.gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
    this.gradientFill.addColorStop(1, "rgba(249, 99, 59, 0.40)");
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    this.userType = user_data.custom_role;
    myChart = new Chart(this.ctx, {
      type: 'bar',
      data: {
        labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
        datasets: [
          {
            label: "Data",
            borderColor: '#fcc468',
            fill: true,
            backgroundColor: '#fcc468',
            hoverBorderColor: '#fcc468',
            borderWidth: 8,
            data: [100, 120, 80, 100, 90, 130, 110, 100, 80, 110, 130, 140, 130, 120, 130, 80, 100, 90, 120, 130],
          },
          {
            label: "Data",
            borderColor: '#4cbdd7',
            fill: true,
            backgroundColor: '#4cbdd7',
            hoverBorderColor: '#4cbdd7',
            borderWidth: 8,
            data: [80, 140, 50, 120, 50, 150, 60, 130, 50, 130, 150, 100, 110, 80, 140, 50, 140, 50, 110, 150],
          }
        ]
      },
      options: {

        tooltips: {
          tooltipFillColor: "rgba(0,0,0,0.5)",
          tooltipFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
          tooltipFontSize: 14,
          tooltipFontStyle: "normal",
          tooltipFontColor: "#fff",
          tooltipTitleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
          tooltipTitleFontSize: 14,
          tooltipTitleFontStyle: "bold",
          tooltipTitleFontColor: "#fff",
          tooltipYPadding: 6,
          tooltipXPadding: 6,
          tooltipCaretSize: 8,
          tooltipCornerRadius: 6,
          tooltipXOffset: 10,
        },


        legend: {

          display: false
        },
        scales: {

          yAxes: [{
            ticks: {
              fontColor: "#9f9f9f",
              fontStyle: "bold",
              beginAtZero: true,
              maxTicksLimit: 5,
              padding: 20
            },
            gridLines: {
              zeroLineColor: "transparent",
              display: true,
              drawBorder: false,
              color: '#9f9f9f',
            }

          }],
          xAxes: [{
            barPercentage: 0.4,
            gridLines: {
              zeroLineColor: "white",
              display: false,

              drawBorder: false,
              color: 'transparent',
            },
            ticks: {
              padding: 20,
              fontColor: "#9f9f9f",
              fontStyle: "bold"
            }
          }]
        }
      }
    });

    Chart.pluginService.register({
      beforeDraw: function (chart) {
        if (chart.config.options.elements.center) {
          //Get ctx from string
          var ctx = chart.chart.ctx;

          //Get options from the center object in options
          var centerConfig = chart.config.options.elements.center;
          var fontStyle = centerConfig.fontStyle || 'Arial';
          var txt = centerConfig.text;
          var color = centerConfig.color || '#000';
          var sidePadding = centerConfig.sidePadding || 20;
          var sidePaddingCalculated = (sidePadding / 100) * (chart.innerRadius * 2)
          //Start with a base font of 30px
          ctx.font = "30px " + fontStyle;

          //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
          var stringWidth = ctx.measureText(txt).width;
          var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

          // Find out how much the font can grow in width.
          var widthRatio = elementWidth / stringWidth;
          var newFontSize = Math.floor(30 * widthRatio);
          var elementHeight = (chart.innerRadius * 2);

          // Pick a new font size so it will not be larger than the height of label.
          var fontSizeToUse = Math.min(newFontSize, elementHeight);

          //Set font settings to draw it correctly.
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
          var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
          ctx.font = fontSizeToUse + "px " + fontStyle;
          ctx.fillStyle = color;

          //Draw text in center
          ctx.fillText(txt, centerX, centerY);
        }
      }
    });

    this.canvas = document.getElementById("chartDonut1");
    this.ctx = this.canvas.getContext("2d");

    myChart = new Chart(this.ctx, {
      type: 'pie',
      data: {
        labels: [1, 2],
        datasets: [{
          label: "Emails",
          pointRadius: 0,
          pointHoverRadius: 0,
          backgroundColor: ['#4acccd', '#f4f3ef'],
          borderWidth: 0,
          data: [60, 40]
        }]
      },
      options: {
        elements: {
          center: {
            text: '60%',
            color: '#66615c', // Default is #000000
            fontStyle: 'Arial', // Default is Arial
            sidePadding: 60 // Defualt is 20 (as a percentage)
          }
        },
        cutoutPercentage: 90,
        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              display: false
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent"
            },
            ticks: {
              display: false,
            }
          }]
        },
      }
    });

    this.canvas = document.getElementById("chartDonut2");
    this.ctx = this.canvas.getContext("2d");

    myChart = new Chart(this.ctx, {
      type: 'pie',
      data: {
        labels: [1, 2],
        datasets: [{
          label: "Emails",
          pointRadius: 0,
          pointHoverRadius: 0,
          backgroundColor: ['#fcc468', '#f4f3ef'],
          borderWidth: 0,
          data: [34, 66]
        }]
      },
      options: {
        elements: {
          center: {
            text: '34%',
            color: '#66615c', // Default is #000000
            fontStyle: 'Arial', // Default is Arial
            sidePadding: 60 // Defualt is 20 (as a percentage)
          }
        },
        cutoutPercentage: 90,
        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              display: false
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent"
            },
            ticks: {
              display: false,
            }
          }]
        },
      }
    });

    this.canvas = document.getElementById("chartDonut3");
    this.ctx = this.canvas.getContext("2d");

    myChart = new Chart(this.ctx, {
      type: 'pie',
      data: {
        labels: [1, 2],
        datasets: [{
          label: "Emails",
          pointRadius: 0,
          pointHoverRadius: 0,
          backgroundColor: ['#f17e5d', '#f4f3ef'],
          borderWidth: 0,
          data: [80, 20]
        }]
      },
      options: {
        elements: {
          center: {
            text: '80%',
            color: '#66615c', // Default is #000000
            fontStyle: 'Arial', // Default is Arial
            sidePadding: 60 // Defualt is 20 (as a percentage)
          }
        },
        cutoutPercentage: 90,
        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              display: false
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent"
            },
            ticks: {
              display: false,
            }
          }]
        },
      }
    });


    this.canvas = document.getElementById("chartDonut4");
    this.ctx = this.canvas.getContext("2d");

    var myChart = new Chart(this.ctx, {
      type: 'pie',
      data: {
        labels: [1, 2],
        datasets: [{
          label: "Emails",
          pointRadius: 0,
          pointHoverRadius: 0,
          backgroundColor: ['#66615b', '#f4f3ef'],
          borderWidth: 0,
          data: [11, 89]
        }]
      },
      options: {
        elements: {
          center: {
            text: '11%',
            color: '#66615c', // Default is #000000
            fontStyle: 'Arial', // Default is Arial
            sidePadding: 60 // Defualt is 20 (as a percentage)
          }
        },
        cutoutPercentage: 90,
        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              display: false
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent"
            },
            ticks: {
              display: false,
            }
          }]
        },
      }
    });

    this.canvas = document.getElementById("activeCountries");
    this.ctx = this.canvas.getContext("2d");

    this.gradientStroke = this.ctx.createLinearGradient(500, 0, 100, 0);
    this.gradientStroke.addColorStop(0, '#2CA8FF');
    this.gradientStroke.addColorStop(1, this.chartColor);

    this.gradientFill = this.ctx.createLinearGradient(0, 170, 0, 50);
    this.gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
    this.gradientFill.addColorStop(1, this.hexToRGB('#2CA8FF', 0.4));

    var a = {
      type: "line",
      data: {
        labels: ["January", "February", "March", "April", "May"],
        datasets: [{
          label: "Active Countries",
          backgroundColor: this.gradientFill,
          borderColor: "#fbc658",
          pointHoverRadius: 0,
          pointRadius: 0,
          fill: false,
          borderWidth: 3,
          data: [80, 78, 86, 96, 83]
        }]
      },
      options: {

        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              fontColor: "#9f9f9f",
              beginAtZero: false,
              maxTicksLimit: 5,
              //padding: 20
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent",
              display: false,
            },
            ticks: {
              padding: 20,
              fontColor: "#9f9f9f"
            }
          }]
        },
      }
    };

    var viewsChart = new Chart(this.ctx, a);



    var mapData = {
      "AU": 760,
      "BR": 550,
      "CA": 120,
      "DE": 1300,
      "FR": 540,
      "GB": 690,
      "GE": 200,
      "IN": 200,
      "RO": 600,
      "RU": 300,
      "US": 2920,
    };

    $('#worldMap').vectorMap({
      map: 'world_mill_en',
      backgroundColor: "transparent",
      zoomOnScroll: false,
      regionStyle: {
        initial: {
          fill: '#e4e4e4',
          "fill-opacity": 0.9,
          stroke: 'none',
          "stroke-width": 0,
          "stroke-opacity": 0
        }
      },

      series: {
        regions: [{
          values: mapData,
          scale: ["#AAAAAA", "#444444"],
          normalizeFunction: 'polynomial'
        }]
      },
    });
  }

  onOpenIssues() {
      this._router.navigate(['/issues'], {queryParams: {project: this.selected_project_id, type: 'Issues'}});
  }
  onOpenCompliancess() {
      this._router.navigate(['/issues'], {queryParams: {project: this.selected_project_id, type: 'Compliances'}});
  }
  onOpenAccidents() {
      this._router.navigate(['/issues'], {queryParams: {project: this.selected_project_id, type: 'Accidents'}});
  }
  // onOpeSafety() {
  //     this._router.navigate(['/issues'], {queryParams: {project: 
  //     this.selected_project_id, type: 'Safety'}});
  // }
  onOpenRaiseIssue() {
      this._router.navigate(['/issue'], { queryParams: { project: this.selected_project_id, type: 'Issues' } });
  }
  onOpenInvestigationIssue() {
      this._router.navigate(['/issues'], { queryParams: { project: this.selected_project_id, type: 'Investigations' } });
  }
  onOpenRegisterCompliance() {
      this._router.navigate(['/issues'], {queryParams: {project: this.selected_project_id, type: 'Issues', isRegisterCompliance: true, statusId: this.registerComplianceStatusId}});
  }
  onOpenReport() {
    this._router.navigate(['/reports'], { queryParams: { project: this.selected_project_id, statusId: this.registerComplianceStatusId } });
  }

  onOpenKPIReport() {
    this._router.navigate(['/kpi-reports'], { queryParams: { project: this.selected_project_id, statusId: this.registerComplianceStatusId } });
  }
  getProjects() {
    console.log('getProjects');
    this.dashboardService.getProjects().subscribe(res => {
      this.projectNotSelectedMsg = 'Select project to view dashboard';
      this.projectList = res;
      var selectedProject = localStorage.getItem('project_title');
      if(selectedProject){
          this.selected_project = selectedProject;
          this.onProjectSelected(selectedProject);
      }
    },
      err => {
      }
    );
  }

  getDashboardStats(projectId: any) {
    this.dashboardService.getDashboardStats(projectId).subscribe(res => {
      this.isProjectSelected = true;
      this.dashboardObj = res;
      this.issuesIdentifiedCount = this.dashboardObj.issues_identified;
      this.issuesClosedCount = this.dashboardObj.issue_closed;
      this.accidentsReportedCount = this.dashboardObj.accidents_report;
      this.usersCount = this.dashboardObj.user_count;
      this.testAndInvestigationCount = this.dashboardObj.test_and_investigation;
      this.getGraphDetails(projectId);
    },
      err => {
        this.getGraphDetails(projectId);
      }
    );
  }

  getIssueStatuses(projectId: any) {
      this.dashboardService.getIssueStatuses(projectId).subscribe((res: any) => {
          var statusIdArray = [];
          for (let eachStatus of res) {
              if (eachStatus.slug == 'open' || eachStatus.slug == 'pending' || eachStatus.slug == 'closed') {
                  statusIdArray.push(eachStatus.id);
              }
          }
          this.registerComplianceStatusId = statusIdArray.toString();
          this.isShowRegisterCompliance = true;
          if (this.userType == 2){
            this.isShowKPIReport = false;
          }
          else{
            this.isShowKPIReport = true;
          }
          
      },
          err => {
              console.log(err);
          }
      );
  }

  getUserDetails() {
    this.dashboardService.getUserDetails().subscribe(res => {
      this.userDetailsObj = res;
      var user_data = JSON.parse(localStorage.getItem('user_data'));
      user_data.custom_role = this.userDetailsObj.custom_role;
      if (user_data.username == 'admin')
        user_data.custom_role = '1';
      if (user_data.username == 'neelmani.katdare@safewayconcessions.com')
        user_data.custom_role = '1';
      if (user_data.username == 'parmod.kumar@safewayconcessions.com')
        user_data.custom_role = '1';
      if (user_data.username == 'nandan.kunal@safewayconcessions.com')
        user_data.custom_role = '1';
      if (user_data.username == 'rahul.mishra@safewayconcessions.com')
        user_data.custom_role = '1';
      localStorage.setItem('user_data', JSON.stringify(user_data));
    },
      err => {
      }
    );
  }

  getGraphDetails(projectId: any) {
    this.numIssuesIdentified = 0;
    this.numIssuesClosed = 0;
    this.numAccidentsReported = 0;
    this.dashboardService.getGraph(projectId).subscribe(res => {
      this.isProjectSelected = true;
      let issuesIdentified = [];
      let issuesClosed = [];
      let accidentsReported = [];
      let graphResponse = res;
      for (let i = 0; i < 6; i++) {
        let obj = { month: '', count: '' };
        obj.month = graphResponse['issue_identified'][i].month;
        obj.count = graphResponse['issue_identified'][i].count;
        this.numIssuesIdentified = Number(this.numIssuesIdentified + obj.count);
        issuesIdentified.push(obj);

        let obj2 = { month: '', count: '' };
        obj2.month = graphResponse['issue_closed'][i].month;
        obj2.count = graphResponse['issue_closed'][i].count;
        this.numIssuesClosed = Number(this.numIssuesClosed + obj2.count);
        issuesClosed.push(obj2);

        let obj1 = { month: '', count: '' };
        obj1.month = graphResponse['accident'][i].month;
        obj1.count = graphResponse['accident'][i].count;
        this.numAccidentsReported = Number(this.numAccidentsReported + obj1.count);
        accidentsReported.push(obj1);
      }
      this.drawGraph(issuesIdentified, issuesClosed, accidentsReported);
      console.log('issuesIdentified: ', issuesIdentified[4]);
      console.log('issuesClosed: ', issuesClosed);
      console.log('accidentsReported: ', accidentsReported);
    },
      err => {
      }
    );
  }

  drawGraph(issuesIdentified: any, issuesClosed: any, accidentsReported: any) {
    this.canvas = document.getElementById("activeUsers");
    this.ctx = this.canvas.getContext("2d");

    this.gradientStroke = this.ctx.createLinearGradient(500, 0, 100, 0);
    this.gradientStroke.addColorStop(0, '#80b6f4');
    this.gradientStroke.addColorStop(1, this.chartColor);

    this.gradientFill = this.ctx.createLinearGradient(0, 170, 0, 50);
    this.gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
    this.gradientFill.addColorStop(1, "rgba(249, 99, 59, 0.40)");

    var myChart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: [issuesClosed[5].month, issuesClosed[4].month, issuesClosed[3].month, issuesClosed[2].month, issuesClosed[1].month, issuesClosed[0].month],
        datasets: [{
          label: "Active Users",
          borderColor: "#6bd098",
          pointRadius: 0,
          pointHoverRadius: 0,
          fill: false,
          borderWidth: 3,
          data: [issuesClosed[5].count, issuesClosed[4].count, issuesClosed[3].count, issuesClosed[2].count, issuesClosed[1].count, issuesClosed[0].count]
        }]
      },
      options: {

        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              fontColor: "#9f9f9f",
              beginAtZero: false,
              maxTicksLimit: 5,
              //padding: 20
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent",
              display: false,
            },
            ticks: {
              padding: 20,
              fontColor: "#9f9f9f"
            }
          }]
        },
      }
    });

    //
    this.canvas = document.getElementById("emailsCampaignChart");
    this.ctx = this.canvas.getContext("2d");

    this.gradientStroke = this.ctx.createLinearGradient(500, 0, 100, 0);
    this.gradientStroke.addColorStop(0, '#18ce0f');
    this.gradientStroke.addColorStop(1, this.chartColor);

    this.gradientFill = this.ctx.createLinearGradient(0, 170, 0, 50);
    this.gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
    this.gradientFill.addColorStop(1, this.hexToRGB('#18ce0f', 0.4));

    var myChart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: [accidentsReported[5].month, accidentsReported[4].month, accidentsReported[3].month, accidentsReported[2].month, accidentsReported[1].month, accidentsReported[0].month],
        datasets: [{
          label: "Email Stats",
          borderColor: "#ef8156",
          pointHoverRadius: 0,
          pointRadius: 0,
          fill: false,
          backgroundColor: this.gradientFill,
          borderWidth: 3,
          data: [accidentsReported[5].count, accidentsReported[4].count, accidentsReported[3].count, accidentsReported[2].count, accidentsReported[1].count, accidentsReported[0].count]
        }]
      },
      options: {

        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              fontColor: "#9f9f9f",
              beginAtZero: false,
              maxTicksLimit: 5,
              //padding: 20
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent",
              display: false,
            },
            ticks: {
              padding: 20,
              fontColor: "#9f9f9f"
            }
          }]
        },
      }
    });

    //
    this.canvas = document.getElementById("activeCountries");
    this.ctx = this.canvas.getContext("2d");

    this.gradientStroke = this.ctx.createLinearGradient(500, 0, 100, 0);
    this.gradientStroke.addColorStop(0, '#18ce0f');
    this.gradientStroke.addColorStop(1, this.chartColor);

    this.gradientFill = this.ctx.createLinearGradient(0, 170, 0, 50);
    this.gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
    this.gradientFill.addColorStop(1, this.hexToRGB('#18ce0f', 0.4));

    var myChart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: [issuesIdentified[5].month, issuesIdentified[4].month, issuesIdentified[3].month, issuesIdentified[2].month, issuesIdentified[1].month, issuesIdentified[0].month],
        datasets: [{
          label: "Email Stats",
          borderColor: "#ef8156",
          pointHoverRadius: 0,
          pointRadius: 0,
          fill: false,
          backgroundColor: this.gradientFill,
          borderWidth: 3,
          data: [issuesIdentified[5].count, issuesIdentified[4].count, issuesIdentified[3].count, issuesIdentified[2].count, issuesIdentified[1].count, issuesIdentified[0].count]
        }]
      },
      options: {

        legend: {

          display: false
        },

        tooltips: {
          enabled: false
        },

        scales: {
          yAxes: [{

            ticks: {
              fontColor: "#9f9f9f",
              beginAtZero: false,
              maxTicksLimit: 5,
              //padding: 20
            },
            gridLines: {
              drawBorder: false,
              zeroLineColor: "transparent",
              color: 'rgba(255,255,255,0.05)'
            }

          }],

          xAxes: [{
            barPercentage: 1.6,
            gridLines: {
              drawBorder: false,
              color: 'rgba(255,255,255,0.1)',
              zeroLineColor: "transparent",
              display: false,
            },
            ticks: {
              padding: 20,
              fontColor: "#9f9f9f"
            }
          }]
        },
      }
    });
  }

  onProjectSelected(projectName: any) {
    console.log('selected_project:', this.selected_project);
    localStorage.setItem('project_title', this.selected_project);
    this.isShowRegisterCompliance = false;
    for (let project of this.projectList) {
      if (project.name == projectName) {
        console.log('selected project: ', project.id);
        this.selected_project_id = project.id;
        this.getDashboardStats(project.id);
        this.getIssueStatuses(project.id);
        break;
      }
    }
  }

  /* onProjectSelected(selectedMembersPos: any, $event) {
     let selectElement = $event.target;
     var optionIndex = selectElement.selectedIndex;
     var optionText = selectElement.options[optionIndex];
     console.log('selected project is: ' + this.projectList[optionText.index].name);
     console.log('selected project id is: ' + this.projectList[optionText.index].id);
     this.getDashboardStats(this.projectList[optionText.index].id);
   }*/

  onUserWidgetClikced() {
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    if (user_data.custom_role == '1') {
      this._router.navigate(['/users']);
    } else {
      swal({
        type: 'warning',
        html: 'You dont have this permission',
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      })
    }
  }
}