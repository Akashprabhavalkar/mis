import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class RegisterService {
    constructor(private http: HttpClient) { }

    registerUser(user: any) {
        return this.http.post(environment.BASE_URL + "api/v1/auth/register",
            {
                "email": user.email,
                "full_name": user.full_name,
                "password": user.password,
                "type": "public",
                "username": user.email,
                "accepted_terms": true,
                "mobile_no": user.mobile_no,
                "aadhaar_no": user.aadhaar_no,
                "address": user.address,
                "custom_role": "5"
            }
        )
    }
}