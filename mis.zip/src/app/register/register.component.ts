import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { RegisterService } from './register.service';
import { Title } from '@angular/platform-browser';
import swal from 'sweetalert2';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'register-cmp',
    templateUrl: './register.component.html'
})

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    focus;
    focus1;
    focus2;
    test: Date = new Date();
    private toggleButton;
    private sidebarVisible: boolean;
    private nativeElement: Node;
    showNameError: boolean = false;
    showMobileError: boolean = false;
    showEmailError: boolean = false;
    showAddressError: boolean = false;
    showAadharError: boolean = false;
    showPasswordError: boolean = false;
    showCPasswordError: boolean = false;
    passwordErrorMsg = '*Invalid password';
    user = {
        "email": "",
        "full_name": "",
        "password": "",
        "cpassword": "",
        "type": "public",
        "username": "",
        "accepted_terms": true,
        "mobile_no": "",
        "aadhaar_no": "",
        "address": "",
    };

    constructor(private element: ElementRef,
        private registerService: RegisterService,
        private _router: Router,
        private titleService: Title) {
        this.nativeElement = element.nativeElement;
        this.sidebarVisible = false;
    }

    ngOnInit() {
        this.titleService.setTitle('Register - Asset Management Tool');
        this.checkFullPageBackgroundImage();
        var navbar: HTMLElement = this.element.nativeElement;
        this.toggleButton = navbar.getElementsByClassName('navbar-toggle')[0];
        setTimeout(function () {
            $('.card').removeClass('card-hidden');
        }, 700)
    }

    checkFullPageBackgroundImage() {
        var $page = $('.full-page');
        var image_src = $page.data('image');
        var body = document.getElementsByTagName('body')[0];
        body.classList.add('register-page');
        if (image_src !== undefined) {
            var image_container = '<div class="full-page-background" style="background-image: url(' + image_src + ') "/>'
            $page.append(image_container);
        }
    };

    ngOnDestroy() {
        var body = document.getElementsByTagName('body')[0];
        body.classList.remove('register-page');
    }

    sidebarToggle() {
        var toggleButton = this.toggleButton;
        var body = document.getElementsByTagName('body')[0];
        var sidebar = document.getElementsByClassName('navbar-collapse')[0];
        if (this.sidebarVisible == false) {
            setTimeout(function () {
                toggleButton.classList.add('toggled');
            }, 500);
            body.classList.add('nav-open');
            this.sidebarVisible = true;
        } else {
            this.toggleButton.classList.remove('toggled');
            this.sidebarVisible = false;
            body.classList.remove('nav-open');
        }
    }

    onRegister() {
        this.showNameError = false;
        this.showMobileError = false;
        this.showEmailError = false;
        this.showAddressError = false;
        this.showAadharError = false;
        this.showPasswordError = false;
        this.showCPasswordError = false;
        if (this.user.full_name.length >= 2 && /^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/.test(this.user.full_name)) {
            if (this.user.mobile_no.length == 10 && /^\d+$/.test(this.user.mobile_no) && (this.user.mobile_no.startsWith("9") || this.user.mobile_no.startsWith("8") || this.user.mobile_no.startsWith("7"))) {
                var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if (re.test(String(this.user.email).toLowerCase())) {
                    if (this.user.address.length >= 2) {
                        if (/^\d+$/.test(this.user.aadhaar_no) && this.user.aadhaar_no.length == 12) {
                            var pattern = new RegExp(/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d][A-Za-z\d!@#$%^&*()_+]{6,19}$/);
                            if (pattern.test(this.user.password)) {
                                if (this.user.password === this.user.cpassword) {
                                    this.registerService.registerUser(this.user).subscribe(res => {
                                        swal({
                                            title: "Registration Completed!",
                                            text: "You can login using your email and password",
                                            buttonsStyling: false,
                                            confirmButtonClass: "btn btn-success",
                                            type: "success"
                                        }).then((result) => {
                                            if (result.value) {
                                                this._router.navigate(['/login']);
                                            }
                                        })
                                    },
                                        err => {
                                            swal({
                                                type: 'warning',
                                                html: err.error._error_message.replace("Username", "Email"),
                                                confirmButtonClass: 'btn btn-success',
                                                buttonsStyling: false
                                            })
                                        }
                                    );
                                } else
                                    this.showCPasswordError = true;
                            } else {
                                this.showPasswordError = true;
                                this.passwordErrorMsg = '*Minimum 6 characters - should contain at least one capital letter, one numeric character and  one special character';
                            }
                        } else
                            this.showAadharError = true;
                    } else
                        this.showAddressError = true;
                } else
                    this.showEmailError = true;
            } else
                this.showMobileError = true;
        } else
            this.showNameError = true;
    }
}