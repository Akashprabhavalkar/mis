import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class ProjectService {
    constructor(private http: HttpClient) { }

    createProject(createProject: any) {
        var payload = {
            creation_template: 1,
            description: 'Ashoka Buildcon Project',
            is_backlog_activated: false,
            is_issues_activated: true,
            is_kanban_activated: true,
            is_private: false,
            is_wiki_activated: true,
            total_milestones: 3,
            total_story_points: 20.0,
            videoconferences: 'appear-in',
            videoconferences_extra_data: null,
            name: createProject.name,
            authority: createProject.authority,
            concessionaire: createProject.concessionaire,
            package_no: createProject.package_no,
            start_and_end_chainage: createProject.start_chainage + "#" + createProject.end_chainage,
            independent_consultant_during_O_and_M_period: createProject.independent_consultant_during_O_and_M_period,
            epc_contractor: createProject.epc_contractor,
            /*date_of_signing_of_concession_agreement: createProject.date_of_signing_of_concession_agreement ? createProject.date_of_signing_of_concession_agreement.year + "-" + createProject.date_of_signing_of_concession_agreement.month + "-" + createProject.date_of_signing_of_concession_agreement.day : null,
            appointed_date: createProject.appointed_date ? createProject.appointed_date.year + "-" + createProject.appointed_date.month + "-" + createProject.appointed_date.day : null,
            O_M_handover_date: createProject.O_M_handover_date ? createProject.O_M_handover_date.year + "-" + createProject.O_M_handover_date.month + "-" + createProject.O_M_handover_date.day : null,
            scheduled_end_of_concession: createProject.scheduled_end_of_concession ? createProject.scheduled_end_of_concession.year + "-" + createProject.scheduled_end_of_concession.month + "-" + createProject.scheduled_end_of_concession.day : null,*/
            date_of_signing_of_concession_agreement: createProject.date_of_signing_of_concession_agreement,
            appointed_date: createProject.appointed_date,
            O_M_handover_date: createProject.O_M_handover_date,
            scheduled_end_of_concession: createProject.scheduled_end_of_concession,
            concession_period: createProject.concession_period
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/projects", payload, options)
    }

    updateProjectDetails(projectObj: any, projectId: String) {
        var payload = {
            description: 'NHAI Project',
            name: projectObj.name,
            authority: projectObj.authority,
            concessionaire: projectObj.concessionaire,
            package_no: projectObj.package_no,
            start_and_end_chainage: projectObj.start_chainage + "#" + projectObj.end_chainage,
            independent_consultant_during_O_and_M_period: projectObj.independent_consultant_during_O_and_M_period,
            epc_contractor: projectObj.epc_contractor,
            date_of_signing_of_concession_agreement: projectObj.date_of_signing_of_concession_agreement,
            appointed_date: projectObj.appointed_date,
            O_M_handover_date: projectObj.O_M_handover_date,
            scheduled_end_of_concession: projectObj.scheduled_end_of_concession,
            concession_period: projectObj.concession_period
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/projects/" + projectId, payload, options)
    }

    getProject(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/projects/" + projectId, options)
    }

    createAssets(projectId: any) {
        var payload = {
            content: 'Assets',
            project: projectId,
            slug: 'assets'
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/wiki", payload, options)
    }

    createLocations(projectId: any) {
        var payload = {
            content: 'Locations',
            project: projectId,
            slug: 'locations'
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/wiki", payload, options)
    }

    uploadAssetFile(fileToUpload: File, object_id: any, projectId: any) {
        let headers = new HttpHeaders({
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        const formData: FormData = new FormData();
        formData.append('attached_file', fileToUpload, fileToUpload.name);
        formData.append('object_id', object_id);
        formData.append('project', projectId);
        return this.http.post(environment.BASE_URL + "api/v1/wiki/attachments", formData, { headers: headers })
    }

    getUsers() {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/users", options)
    }

    getRoles(projectId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/roles?project=" + projectId.toString(), options)
    }

    getPermissions(roleId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/roles/" + roleId.toString(), options)
    }

    getMemberList(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/memberships?project=" + projectId, options)
    }

    getGuestList(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/nomemberusers?project=" + projectId, options)
    }

    addNewUser(project: any, role: any, username: any, role_name: any) {
        var payload = {
            project: project,
            role: role,
            role_name: role_name,
            username: username
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.post(environment.BASE_URL + "api/v1/memberships", payload, options)
    }

    updateUserRole(memberId: any, role: String, role_name: any) {
        var payload = {
            role: role,
            role_name: role_name
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.patch(environment.BASE_URL + "api/v1/memberships/" + memberId, payload, options)
    }

    getProjects() {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/projects", options)
    }

    closeProject(projectId: String) {
        var payload = {
            is_closed: 'NHAI Project',
        }
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.put(environment.BASE_URL + "api/v1/close_project?project=" + projectId, payload, options)
    }

    removeMember(memberId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.delete(environment.BASE_URL + "api/v1/memberships/" + memberId, options)
    }

    getIssueStatuses(projectId: any) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/issue-statuses?project=" + projectId, options)
    }
}