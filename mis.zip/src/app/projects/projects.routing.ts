import { Routes } from '@angular/router';

import { ProjectsComponent } from './projects.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { ProjectlinkComponent } from './projectlink/projectlink.component';

export const ProjectsRoutes: Routes = [{
    path: 'projects',
    children: [{
        path: '',
        component: ProjectsComponent
    }]
},{
    path: 'project',
    children: [{
        path: '',
        component: AddProjectComponent
    }]
},{
    path: 'project/:project-slug/issue/:issueid',
    children: [{
        path: '',
        component: ProjectlinkComponent
    }]
}];