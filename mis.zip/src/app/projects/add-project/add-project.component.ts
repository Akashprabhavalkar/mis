import { Component, OnInit, OnChanges, AfterViewInit, SimpleChanges } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { ProjectService } from '.././project.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { startsWithPipe } from './customstart.pipes';

declare var swal: any;
declare var $: any;

interface FileReaderEventTarget extends EventTarget {
  result: string
}

interface FileReaderEvent extends Event {
  target: FileReaderEventTarget;
  getMessage(): string;
}

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})

export class AddProjectComponent implements OnInit, AfterViewInit {
  userList;
  roleList;
  focus;
  focus1;
  focus2;
  projectRoles;
  selectedUsers: any;
  query: string = '';
  buttonType: String = 'Create Project';
  isUpdateProject: boolean = false;
  isAddUserClicked: boolean = false
  sub: any;
  projectId: any;
  projectResposeObj: any;
  wikiResponseObj: any;
  assetFileToUpload: File = null;
  assetsResponseObj: any;
  locationFileToUpload: File = null;
  locationResponseObj: any;
  activeTab: number = 0;
  isProjectFormValid: boolean = false;
  isProjectCreated: boolean = false;
  isAssetsCreated: boolean = false;
  isLocationsCreated: boolean = false;
  guestUsers: any;
  userType;
  selectedRoles = [];
  showProjectNameError: boolean = false;
  projectNameErrorMsg = '*Project name required';
  createProject = {
    name: '',
    authority: '',
    concessionaire: '',
    package_no: '',
    start_chainage: '',
    end_chainage: '',
    start_and_end_chainage: '',
    independent_consultant_during_O_and_M_period: '',
    epc_contractor: '',
    date_of_signing_of_concession_agreement: '',
    appointed_date: '',
    O_M_handover_date: '',
    scheduled_end_of_concession: '',
    concession_period: '',
    asset_wiki_page_id: '',
    location_wiki_page_id: ''
  };

  constructor(private projectService: ProjectService,
    private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute) {

  }

  readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e: FileReaderEvent) {
        $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  handleFileInput(files: FileList) {
    this.assetFileToUpload = files.item(0);
  }

  handleLocationFileInput(files: FileList) {
    this.locationFileToUpload = files.item(0);
  }

  onPreviousClicked() {
    if (this.activeTab > 0) {
      this.activeTab = this.activeTab - 1;
    }
  }

  checkForm() {
    return this.isProjectFormValid;
  }

  onProjectCreateClicked() {
    if (!this.isProjectCreated) {
      if (this.createProject.name != '') {
        this.onCreateProject();
      }
    }
  }

  onUploadAssetFilesClicked() {
    if (this.isProjectCreated || this.isUpdateProject) {
      this.projectService.getProject(String(this.projectId)).subscribe(res => {
        this.projectResposeObj = res;
        this.createProject.asset_wiki_page_id = res['asset_wiki_page_id'];
        this.createProject.location_wiki_page_id = res['location_wiki_page_id'];
        this.projectService.uploadAssetFile(this.assetFileToUpload, this.createProject.asset_wiki_page_id, this.projectResposeObj.id).subscribe(res => {
          swal({
            title: "Successful!",
            text: "Asset file uploaded",
            buttonsStyling: false,
            confirmButtonClass: "btn btn-success",
            type: "success"
          }).catch(swal.noop)
        },
          err => {
          }
        );
      },
        err => {
        }
      );
    } else {
      swal({
        title: "Please create project first",
        text: "",
        timer: 2000,
        showConfirmButton: false
      }).catch(swal.noop)
    }
  }

  onUploadLocationFilesClicked() {
    if (this.isProjectCreated || this.isUpdateProject) {
      this.projectService.getProject(String(this.projectId)).subscribe(res => {
        this.projectResposeObj = res;
        this.createProject.asset_wiki_page_id = res['asset_wiki_page_id'];
        this.createProject.location_wiki_page_id = res['location_wiki_page_id'];
        this.projectService.uploadAssetFile(this.locationFileToUpload, this.createProject.location_wiki_page_id, this.projectResposeObj.id).subscribe(res => {
          swal({
            title: "Successful!",
            text: "Location file uploaded",
            buttonsStyling: false,
            confirmButtonClass: "btn btn-success",
            type: "success"
          }).catch(swal.noop)
        },
          err => {
          }
        );
      },
        err => {
        }
      );
    } else {
      swal({
        title: "Please create project first",
        text: "",
        timer: 2000,
        showConfirmButton: false
      }).catch(swal.noop)
    }
  }

  onCreateProject() {
    if (!this.isUpdateProject) {
      this.projectService.createProject(this.createProject).subscribe(res => {
        swal({
          title: "Successful!",
          text: "Project created",
          buttonsStyling: false,
          confirmButtonClass: "btn btn-success",
          type: "success"
        }).catch(swal.noop)
        this.projectResposeObj = res;
        this.projectId = this.projectResposeObj.id.toString();
        this.getProjectDetails();
        this.isProjectCreated = true;
        this.getAllRoles();
        this.projectService.createAssets(this.projectResposeObj.id).subscribe(res => {
          this.assetsResponseObj = res;
          this.projectResposeObj.asset_wiki_page_id = this.assetsResponseObj.id;
          this.isAssetsCreated = true;
          this.projectService.createLocations(this.projectResposeObj.id).subscribe(res => {
            this.locationResponseObj = res;
            this.projectResposeObj.location_wiki_page_id = this.assetsResponseObj.id;
            this.isLocationsCreated = true;
          },
            err => {
            }
          );
        },
          err => {
          }
        );
      },
        err => {
        }
      );
    } else {
      this.projectService.updateProjectDetails(this.createProject, this.projectId).subscribe(res => {
        this.locationResponseObj = res;
        this.isLocationsCreated = true;
        swal({
          title: "Successful!",
          text: "Project details updated",
          buttonsStyling: false,
          confirmButtonClass: "btn btn-success",
          type: "success"
        }).catch(swal.noop)
      },
        err => {
        }
      );
    }
  }

  ngOnInit() {
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    this.userType = user_data.custom_role;
    this.sub = this.route
      .queryParams
      .subscribe(params => {
        this.projectId = +params['project'] || 0;
        if (this.projectId == 0) {
          this.isUpdateProject = false;
          localStorage.setItem('page_title', 'Create Project');
          this.titleService.setTitle('Create Project - Asset Management Tool');
          this.buttonType = 'Create Project';
        } else {
          localStorage.setItem('page_title', 'Update Project Details');
          this.titleService.setTitle('Update Project - Asset Management Tool');
          this.isUpdateProject = true;
          this.buttonType = 'Update Details';
          this.getProjectDetails();
        }
      });
    this.getAllUsers();
    this.getAllRoles();
    this.getMembers();
    this.getGuestUsers();
    if ($(".selectpicker").length != 0) {
      $(".selectpicker").selectpicker({
        iconBase: "nc-icon",
        tickIcon: "nc-check-2"
      });
    }
    setTimeout(function () {
      $('.card.card-wizard').addClass('active');
    }, 600);
    const $validator = $('.card-wizard form').validate({
    });
    $('.card-wizard').bootstrapWizard({
      'tabClass': 'nav nav-pills',
      'nextSelector': '.btn-next',
      'previousSelector': '.btn-previous',
      onNext: function (tab, navigation, index) {
        /* var $valid = $('.card-wizard form').valid();
         if (!$valid) {
           $validator.focusInvalid();
           return false;
         }*/
      },
      onInit: function (tab: any, navigation: any, index: any) {
        let $total = navigation.find('li').length;
        let $wizard = navigation.closest('.card-wizard');
        let $first_li = navigation.find('li:first-child a').html();
        let $moving_div = $('<div class="moving-tab">' + $first_li + '</div>');
        $('.card-wizard .wizard-navigation').append($moving_div);
        $total = $wizard.find('.nav li').length;
        let $li_width = 100 / $total;
        let total_steps = $wizard.find('.nav li').length;
        let move_distance = $wizard.width() / total_steps;
        let index_temp = index;
        let vertical_level = 0;
        let mobile_device = $(document).width() < 600 && $total > 3;
        if (mobile_device) {
          move_distance = $wizard.width() / 2;
          index_temp = index % 2;
          $li_width = 50;
        }
        $wizard.find('.nav li').css('width', $li_width + '%');
        let step_width = move_distance;
        move_distance = move_distance * index_temp;
        let $current = index + 1;
        if ($current == 1 || (mobile_device == true && (index % 2 == 0))) {
          move_distance -= 8;
        } else if ($current == total_steps || (mobile_device == true && (index % 2 == 1))) {
          move_distance += 8;
        }
        if (mobile_device) {
          let x: any = index / 2;
          vertical_level = parseInt(x);
          vertical_level = vertical_level * 38;
        }
        $wizard.find('.moving-tab').css('width', step_width);
        $('.moving-tab').css({
          'transform': 'translate3d(' + move_distance + 'px, ' + vertical_level + 'px, 0)',
          'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
        });
        $('.moving-tab').css('transition', 'transform 0s');
      },
      onTabClick: function (tab: any, navigation: any, index: any) {
        const $valid = $('.card-wizard form').valid();
      },
      onTabShow: function (tab: any, navigation: any, index: any) {
        var $total = navigation.find('li').length;
        var $current = index + 1;
        var $wizard = navigation.closest('.card-wizard');
        if ($current >= $total) {
          $($wizard).find('.btn-next').hide();
          $($wizard).find('.btn-finish').show();
        } else {
          $($wizard).find('.btn-next').show();
          $($wizard).find('.btn-finish').hide();
        }
        let button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
          $('.moving-tab').html(button_text);
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (index == 0) {
          $(checkbox).css({
            'opacity': '0',
            'visibility': 'hidden',
            'position': 'absolute'
          });
        } else {
          $(checkbox).css({
            'opacity': '1',
            'visibility': 'visible'
          });
        }
        $total = $wizard.find('.nav li').length;
        let $li_width = 100 / $total;
        let total_steps = $wizard.find('.nav li').length;
        let move_distance = $wizard.width() / total_steps;
        let index_temp = index;
        let vertical_level = 0;
        let mobile_device = $(document).width() < 600 && $total > 3;
        if (mobile_device) {
          move_distance = $wizard.width() / 2;
          index_temp = index % 2;
          $li_width = 50;
        }
        $wizard.find('.nav li').css('width', $li_width + '%');
        let step_width = move_distance;
        move_distance = move_distance * index_temp;
        $current = index + 1;
        if (mobile_device) {
          let x: any = index / 2;
          vertical_level = parseInt(x);
          vertical_level = vertical_level * 38;
        }
        $wizard.find('.moving-tab').css('width', step_width);
        $('.moving-tab').css({
          'transform': 'translate3d(' + move_distance + 'px, ' + vertical_level + 'px, 0)',
          'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
        });
      }
    });
    $('#wizard-picture').change(function () {
      const input = $(this);
      if (input[0].files && input[0].files[0]) {
        const reader = new FileReader();
        reader.onload = function (e: FileReaderEvent) {
          $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
        };
        reader.readAsDataURL(input[0].files[0]);
      }
    });
    $('[data-toggle="wizard-radio"]').click(function () {
      let wizard = $(this).closest('.card-wizard');
      wizard.find('[data-toggle="wizard-radio"]').removeClass('active');
      $(this).addClass('active');
      $(wizard).find('[type="radio"]').removeAttr('checked');
      $(this).find('[type="radio"]').attr('checked', 'true');
    });
    $('[data-toggle="wizard-checkbox"]').click(function () {
      if ($(this).hasClass('active')) {
        $(this).removeClass('active');
        $(this).find('[type="checkbox"]').removeAttr('checked');
      } else {
        $(this).addClass('active');
        $(this).find('[type="checkbox"]').attr('checked', 'true');
      }
    });
    $('.set-full-height').css('height', 'auto');
  }
  
  getProjectTitle() {
    let projectTitle = localStorage.getItem('project_title') || '';
    return projectTitle;
  }

  ngAfterViewInit() {
    $(window).resize(() => {
      $('.card-wizard').each(function () {
        const $wizard = $(this);
        const index = $wizard.bootstrapWizard('currentIndex');
        let $total = $wizard.find('.nav li').length;
        let $li_width = 100 / $total;
        let total_steps = $wizard.find('.nav li').length;
        let move_distance = $wizard.width() / total_steps;
        let index_temp = index;
        let vertical_level = 0;
        let mobile_device = $(document).width() < 600 && $total > 3;
        if (mobile_device) {
          move_distance = $wizard.width() / 2;
          index_temp = index % 2;
          $li_width = 50;
        }
        $wizard.find('.nav li').css('width', $li_width + '%');
        let step_width = move_distance;
        move_distance = move_distance * index_temp;
        let $current = index + 1;
        if ($current == 1 || (mobile_device == true && (index % 2 == 0))) {
          move_distance -= 8;
        } else if ($current == total_steps || (mobile_device == true && (index % 2 == 1))) {
          move_distance += 8;
        }
        if (mobile_device) {
          let x: any = index / 2;
          vertical_level = parseInt(x);
          vertical_level = vertical_level * 38;
        }
        $wizard.find('.moving-tab').css('width', step_width);
        $('.moving-tab').css({
          'transform': 'translate3d(' + move_distance + 'px, ' + vertical_level + 'px, 0)',
          'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
        });
        $('.moving-tab').css({
          'transition': 'transform 0s'
        });
      });
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    const input = $(this);
    if (input[0].files && input[0].files[0]) {
      const reader: any = new FileReader();
      reader.onload = function (e: FileReaderEvent) {
        $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
      };
      reader.readAsDataURL(input[0].files[0]);
    }
  }

  getProjectDetails() {
    this.projectService.getProject(String(this.projectId)).subscribe(res => {
      this.projectResposeObj = res;
      this.createProject.name = res['name'];
      this.createProject.authority = res['authority'];
      this.createProject.concessionaire = res['concessionaire'];
      this.createProject.package_no = res['package_no'];
      let chainage = this.createProject.start_and_end_chainage = res['start_and_end_chainage'].split("#");
      this.createProject.start_chainage = chainage[0];
      this.createProject.end_chainage = chainage[1];
      this.createProject.independent_consultant_during_O_and_M_period = res['independent_consultant_during_O_and_M_period'];
      this.createProject.epc_contractor = res['epc_contractor'];
      this.createProject.date_of_signing_of_concession_agreement = res['date_of_signing_of_concession_agreement'];
      this.createProject.date_of_signing_of_concession_agreement = res['date_of_signing_of_concession_agreement'];
      this.createProject.date_of_signing_of_concession_agreement = res['date_of_signing_of_concession_agreement'];
      this.createProject.appointed_date = res['appointed_date'];
      this.createProject.O_M_handover_date = res['O_M_handover_date'];
      this.createProject.scheduled_end_of_concession = res['scheduled_end_of_concession'];
      this.createProject.concession_period = res['concession_period'];
      this.createProject.asset_wiki_page_id = res['asset_wiki_page_id'];
      this.createProject.location_wiki_page_id = res['location_wiki_page_id'];
    },
      err => {
      }
    );
  }

  getAllUsers() {
    this.projectService.getUsers().subscribe(res => {
      this.userList = res;
    },
      err => {
      }
    );
  }

  getAllRoles() {
    this.roleList = [];
    this.projectService.getRoles(this.projectId).subscribe(res => {
      this.roleList = res;
      this.projectRoles = res;
    },
      err => {
      }
    );
  }

  getMembers() {
    this.projectService.getMemberList(this.projectId).subscribe(res => {
      this.selectedUsers = res;
      this.selectedUsers.forEach((item, index) => {
        this.selectedUsers[index].member_id = item.id;
      });
    },
      err => {
        this.selectedUsers = [];
      }
    );
  }

  getGuestUsers() {
    this.projectService.getGuestList(this.projectId).subscribe(res => {
      this.guestUsers = res;
      this.guestUsers.forEach((item, index) => {
        this.guestUsers[index].member_id = '';
      });
    },
      err => {
      }
    );
  }

  onAddSelectionRow() {
    this.isAddUserClicked = true;
    this.getGuestUsers();
  }

  onInviteUserClose() {
    this.isAddUserClicked = false;
  }

  onNewUserSelected(selectedUser: any) {
    selectedUser.member_id = selectedUser.is;
    selectedUser.is_new = '1';
    this.selectedUsers.push(selectedUser);
    this.selectedRoles.push({});
    this.isAddUserClicked = false;
  }

  onRemoveSelectionRow(position: any) {
    this.projectService.removeMember(this.selectedUsers[position].member_id).subscribe(res => {
      this.selectedUsers.splice(position, 1);
      this.selectedRoles.splice(position, 1);
    },
      err => {
        swal({
          type: 'warning',
          html: err.error._error_message,
          confirmButtonClass: 'btn btn-success',
          buttonsStyling: false
        })
      }
    );
  }

  onUserSelected(selectedMembersPos: any, $event) {
    let selectElement = $event.target;
    var optionIndex = selectElement.selectedIndex;
    var optionText = selectElement.options[optionIndex];
  }

  onRoleSelected(selectedMembersPos: any, $event) {
    console.log("---------ww------------->");
    console.log(this.userType);
    if (this.userType == '1' || this.userType == '2' || this.userType == '3') {
      console.log($event);
      let selectElement = $event.target;
      var optionIndex = selectElement.selectedIndex;
      var optionText = selectElement.options[optionIndex];
      this.selectedUsers[selectedMembersPos].role_name = this.roleList[optionText.index].name;
      if (this.selectedUsers[selectedMembersPos].is_new == '1') {
        this.projectService.addNewUser(this.projectId, this.roleList[optionText.index].id, this.selectedUsers[selectedMembersPos].username, this.selectedUsers[selectedMembersPos].role_name).subscribe(res => {
          swal({
            title: "Successful!",
            text: "User added",
            buttonsStyling: false,
            confirmButtonClass: "btn btn-success",
            type: "success"
          }).catch(swal.noop)
          this.getMembers();
        },
          err => {
            this.selectedUsers.splice(selectedMembersPos, 1);
            this.selectedRoles.splice(selectedMembersPos, 1);
            swal({
              type: 'warning',
              html: err.error._error_message,
              confirmButtonClass: 'btn btn-success',
              buttonsStyling: false
            })
          }
        );
      } else {
        this.projectService.updateUserRole(this.selectedUsers[selectedMembersPos].id, this.roleList[optionText.index].id, this.selectedUsers[selectedMembersPos].role_name).subscribe(res => {
          swal({
            title: "Successful!",
            text: "User role updated",
            buttonsStyling: false,
            confirmButtonClass: "btn btn-success",
            type: "success"
          }).catch(swal.noop)
        },
          err => {
            swal({
              type: 'warning',
              html: err.error._error_message,
              confirmButtonClass: 'btn btn-success',
              buttonsStyling: false
            })
          }
        );
      }

    } else {
      swal({
        type: 'warning',
        html: 'You dont have permission',
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      })
    }
  }
}