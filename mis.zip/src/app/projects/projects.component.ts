import { Component, OnInit } from '@angular/core';
import { ProjectService } from './project.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import swal from 'sweetalert2';
declare var $: any;
declare interface DataTable {
  dataRows: string[];
}

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})

export class ProjectsComponent implements OnInit {
  public dataTable: DataTable;
  projects: any;
  issueTypes: any;
  isLoading: boolean = false;
  userType;

  constructor(private _router: Router,
    private projectService: ProjectService,
    private titleService: Title) {
  }

  ngOnInit() {
    let user_data = JSON.parse(localStorage.getItem('user_data'));
    this.userType = user_data.custom_role;
    console.log('this.userType: ', this.userType);
    this.dataTable = {
      dataRows: []
    };
    this.isLoading = true;
    localStorage.setItem('page_title', 'Projects');
    this.titleService.setTitle('Projects - Asset Management Tool');
    this.getProjects();
  }

  getProjects() {
    this.projectService.getProjects().subscribe(res => {
      this.dataTable = {
        dataRows: []
      };
      this.projects = res;
      this.dataTable.dataRows = this.projects;
      this.isLoading = false;
    },
      err => {
      }
    );
  }

  onEditProject(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['project'], { queryParams: { project: project.id } });
  }

  onOpenIssues(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['/issues'], { queryParams: { project: project.id, type: 'Issues' } });
  }
  
  onPendingIssues(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['/issues'], { queryParams: { project: project.id, type: 'Issues', isPending: true } });
  }

  onOpenCompliancess(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['/issues'], { queryParams: { project: project.id, type: 'Compliances' } });
  }

  onOpenAccidents(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['/issues'], { queryParams: { project: project.id, type: 'Accidents' } });
  }

  onOpenAssets(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['/project-files'], { queryParams: { project: project.id, id: project.asset_wiki_page_id, type: 'assets' } });
  }

  onOpenLocations(project: any) {
    localStorage.setItem('project_title', project.name);
    this._router.navigate(['/project-files'], { queryParams: { project: project.id, id: project.location_wiki_page_id, type: 'locations' } });
  }

  onOpenReports(project: any) {
    localStorage.setItem('project_title', project.name);
    this.projectService.getIssueStatuses(project['id'] || '').subscribe((res: any) => {
          var statusIdArray = [];
          for (let eachStatus of res) {
              if (eachStatus.slug == 'open' || eachStatus.slug == 'pending' || eachStatus.slug == 'closed') {
                  statusIdArray.push(eachStatus.id);
              }
          }
          this._router.navigate(['/reports'], { queryParams: { project: project.id, statusId: statusIdArray.toString() } });
      },
          err => {
              console.log(err);
          }
      );
//      this._router.navigate(['/reports'], { queryParams: { project: project.id } });
  }

  onCloseProject(project: any) {
    swal({
      title: 'Close Project',
      text: "Are you sure, you want to close this project?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonClass: 'btn btn-success',
      cancelButtonClass: 'btn btn-danger',
      confirmButtonText: 'Close',
      buttonsStyling: false
    }).then((result) => {
      this.projectService.closeProject(project.id).subscribe(res => {
        if (result.value) {
          swal(
            {
              title: 'Successful!',
              text: 'Project closed',
              type: 'success',
              confirmButtonClass: "btn btn-success",
              buttonsStyling: false
            }
          ).then((result) => {
          })
        }
      },
        err => {
        }
      );
      this.getProjects();
    })
  }

  ngAfterViewInit() {
    $('#datatable').DataTable({
      "bFilter": false,
      "bPaginate": false,
      "bInfo": false,
      responsive: true,
      "language": {
        emptyTable: null,
        loadingRecords: null,
        zeroRecords: null
      }
    });
  }
}