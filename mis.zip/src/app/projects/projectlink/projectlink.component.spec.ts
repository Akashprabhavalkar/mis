import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectlinkComponent } from './projectlink.component';

describe('ProjectlinkComponent', () => {
  let component: ProjectlinkComponent;
  let fixture: ComponentFixture<ProjectlinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectlinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectlinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
