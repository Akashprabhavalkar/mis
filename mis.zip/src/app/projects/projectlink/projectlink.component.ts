import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../../environments/environment';

@Component({
    selector: 'app-projectlink',
    templateUrl: './projectlink.component.html',
    styleUrls: ['./projectlink.component.css']
})
export class ProjectlinkComponent implements OnInit {
    sub: any;
    constructor(
        private _router: Router,
        private route: ActivatedRoute,
        private http: HttpClient
    ) {}
    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            let issueRef = params['issueid'] || '';
            let projectSlug = params['project-slug'] || '';
            this.getProjectDetails(projectSlug, issueRef)
        });
    }
    getProjectDetails(projectSlug: String, issueRef: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = {headers: headers};
        this.http.get(environment.BASE_URL + "api/v1/projects/by_slug?slug=" + projectSlug, options).subscribe((res: any) => {
            let projectId = res.id;
            if (projectId){
                this.getIssueDetails(projectId, issueRef);
            } else {
                this._router.navigate(['/dashboard']);
            }
        },
            err => {
                this._router.navigate(['/dashboard']);
            }
        );
    }
    getIssueDetails(projectId: String, issueRef: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = {headers: headers};
        this.http.get(environment.BASE_URL + "api/v1/issues/by_ref?project=" + projectId + "&ref=" + issueRef, options).subscribe((res: any) => {
            let issueId = res.id;
            if(issueId){
                let issueType = 'Issues';
                if(res.status_name == 'Closed'){
                    issueType = 'Compliances';
                }
                this._router.navigate(['/issue'], { queryParams: { project: projectId, type: issueType, id:  issueId} });
            }else{
                this._router.navigate(['/dashboard']);
            }
        },
            err => {
                this._router.navigate(['/dashboard']);
            }
        );
    }

}
