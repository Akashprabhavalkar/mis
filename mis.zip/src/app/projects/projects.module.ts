import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { JWBootstrapSwitchModule } from 'jw-bootstrap-switch-ng2';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TagInputModule } from 'ngx-chips';
import { ProjectsComponent } from './projects.component';
import { ProjectsRoutingModule } from './projects-routing.module';
import { ProjectsRoutes } from './projects.routing';
import { FormsModule } from '@angular/forms';
import { AddProjectComponent } from './add-project/add-project.component';
import { ProjectlinkComponent } from './projectlink/projectlink.component';
import { startsWithPipe } from './add-project/customstart.pipes';

@NgModule({
  imports: [
    TagInputModule,
    JWBootstrapSwitchModule,
    NgbModule,
    CommonModule,
    FormsModule,
    RouterModule.forChild(ProjectsRoutes),
    FormsModule,
    ProjectsRoutingModule
  ],
  declarations: [ProjectsComponent,
    AddProjectComponent,
    ProjectlinkComponent,
    startsWithPipe]
})
export class ProjectsModule { }