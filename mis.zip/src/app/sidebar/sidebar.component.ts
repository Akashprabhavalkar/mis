import { Component, OnInit, AfterViewInit, AfterViewChecked, AfterContentInit, ElementRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';


var misc: any = {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
}
//Metadata
export interface RouteInfo {
    path: string;
    title: string;
    type: string;
    icontype: string;
    // icon: string;
    children?: ChildrenItems[];
}

export interface ChildrenItems {
    path: string;
    title: string;
    ab: string;
    type?: string;
}

//Menu Items
export const ROUTES: RouteInfo[] = [{
    path: '/dashboard',
    title: 'Dashboard',
    type: 'link',
    icontype: 'fa fa-home'
}, {
    path: '/projects',
    title: 'Projects',
    type: 'link',
    icontype: 'fa fa-road'
}/*, {
    path: '/assets',
    title: 'Assets',
    type: 'link',
    icontype: 'fa fa-building'
}, {
    path: '/compliances',
    title: 'Compliances',
    type: 'link',
    icontype: 'fa fa-gavel'
}, {
    path: '/issues',
    title: 'Issues',
    type: 'link',
    icontype: 'fa fa-exclamation-circle'
}, {
    path: '/accidents',
    title: 'Accidents',
    type: 'link',
    icontype: 'fa fa-exclamation-triangle'
}, {
    path: '/locations',
    title: 'Locations',
    type: 'link',
    icontype: 'fa fa-map-signs'
}, {
    path: '/reports',
    title: 'Reports',
    type: 'link',
    icontype: 'fa fa-pie-chart'
}*/, {
    path: '/users',
    title: 'Users',
    type: 'link',
    icontype: 'fa fa-users'
}/*, {
    path: '/l9',
    title: 'Logout',
    type: 'link',
    icontype: 'fa fa-sign-out'
}*/, /*{
    path: '/components',
    title: 'Components',
    type: 'sub',
    icontype: 'nc-icon nc-layout-11',
    children: [
        { path: 'buttons', title: 'Buttons', ab: 'B' },
        { path: 'grid', title: 'Grid System', ab: 'GS' },
        { path: 'panels', title: 'Panels', ab: 'P' },
        { path: 'sweet-alert', title: 'Sweet Alert', ab: 'SA' },
        { path: 'notifications', title: 'Notifications', ab: 'N' },
        { path: 'icons', title: 'Icons', ab: 'I' },
        { path: 'typography', title: 'Typography', ab: 'T' }
    ]
}, {
    path: '/forms',
    title: 'Forms',
    type: 'sub',
    icontype: 'nc-icon nc-ruler-pencil',
    children: [
        { path: 'regular', title: 'Regular Forms', ab: 'RF' },
        { path: 'extended', title: 'Extended Forms', ab: 'EF' },
        { path: 'validation', title: 'Validation Forms', ab: 'VF' },
        { path: 'wizard', title: 'Wizard', ab: 'W' }
    ]
}, {
    path: '/tables',
    title: 'Tables',
    type: 'sub',
    icontype: 'nc-icon nc-single-copy-04',
    children: [
        { path: 'regular', title: 'Regular Tables', ab: 'RT' },
        { path: 'extended', title: 'Extended Tables', ab: 'ET' },
        { path: 'datatables.net', title: 'Datatables.net', ab: 'DT' }
    ]
}, {
    path: '/maps',
    title: 'Maps',
    type: 'sub',
    icontype: 'nc-icon nc-pin-3',
    children: [
        { path: 'google', title: 'Google Maps', ab: 'GM' },
        { path: 'fullscreen', title: 'Full Screen Map', ab: 'FSM' },
        { path: 'vector', title: 'Vector Map', ab: 'VM' }
    ]
}, {
    path: '/widgets',
    title: 'Widgets',
    type: 'link',
    icontype: 'nc-icon nc-box'

}, {
    path: '/charts',
    title: 'Charts',
    type: 'link',
    icontype: 'nc-icon nc-chart-bar-32'

}, {
    path: '/calendar',
    title: 'Calendar',
    type: 'link',
    icontype: 'nc-icon nc-calendar-60'
}, {
    path: '/pages',
    title: 'Pages',
    type: 'sub',
    icontype: 'nc-icon nc-book-bookmark',
    children: [
        { path: 'timeline', title: 'Timeline Page', ab: 'T' },
        { path: 'user', title: 'User Page', ab: 'UP' },
        { path: 'login', title: 'Login Page', ab: 'LP' },
        { path: 'register', title: 'Register Page', ab: 'RP' },
        { path: 'lock', title: 'Lock Screen Page', ab: 'LSP' }
    ]
}*/
];

export const ADMIN_ROUTES: RouteInfo[] = [{
    path: '/dashboard',
    title: 'Dashboard',
    type: 'link',
    icontype: 'fa fa-home'
}, {
    path: '/projects',
    title: 'Projects',
    type: 'link',
    icontype: 'fa fa-road'
}, {
    path: '/users',
    title: 'Users',
    type: 'link',
    icontype: 'fa fa-users'
}
];

export const USER_ROUTES: RouteInfo[] = [{
    path: '/dashboard',
    title: 'Dashboard',
    type: 'link',
    icontype: 'fa fa-home'
}, {
    path: '/projects',
    title: 'Projects',
    type: 'link',
    icontype: 'fa fa-road'
}
];

@Component({
    moduleId: module.id,
    selector: 'sidebar-cmp',
    templateUrl: 'sidebar.component.html',
})

export class SidebarComponent {
    private listTitles: any[];
    location: Location;
    private nativeElement: Node;
    private toggleButton;
    private sidebarVisible: boolean;
    fullName='';
    public menuItems: any[];
    newUserCount: number;
    constructor(private http: HttpClient, location: Location,private element: ElementRef,) 
    {this.location = location; this.nativeElement = element.nativeElement;
        this.sidebarVisible = false;}
    isNotMobileMenu() {
        if (window.outerWidth > 991) {
            return false;
        }
        return true;
    }

    ngOnInit() {
        // this.menuItems = ROUTES.filter(menuItem => menuItem);
        let user_data = JSON.parse(localStorage.getItem('user_data'));
        if (user_data.username == 'admin@gmail.com' || user_data.username == 'neelmani.katdare@safewayconcessions.com' || user_data.username == 'parmod.kumar@safewayconcessions.com' || user_data.username == 'nandan.kunal@safewayconcessions.com' || user_data.username == 'rahul.mishra@safewayconcessions.com') {
            this.menuItems = ADMIN_ROUTES.filter(menuItem => menuItem);
            let headers = new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': localStorage.getItem('auth_token')
            });
            let options = {headers: headers};
            this.http.get(environment.BASE_URL + "new_registerd_user/", options).subscribe(res => {
                this.newUserCount = res['new_registered_user'] || 0;
            }, err => {
                console.log(err);
            }
            );
        } else {
            this.menuItems = USER_ROUTES.filter(menuItem => menuItem);
        }
        const body = document.getElementsByTagName('body')[0];
        document.body.classList.add('sidebar-mini');
        if (body.classList.contains('sidebar-mini')) {
            misc.sidebar_mini_active = true;
        }


        
    }
    ngAfterViewInit() {
    }

    minimizeSidebar() {
        const body = document.getElementsByTagName('body')[0];

        if (misc.sidebar_mini_active === true) {
            body.classList.remove('sidebar-mini');
            misc.sidebar_mini_active = false;

        } else {
            setTimeout(function () {
                body.classList.add('sidebar-mini');

                misc.sidebar_mini_active = true;
            }, 300);
        }

        // we simulate the window Resize so the charts will get updated in realtime.
        const simulateWindowResize = setInterval(function () {
            window.dispatchEvent(new Event('resize'));
        }, 180);

        // we stop the simulation of Window Resize after the animations are completed
        setTimeout(function () {
            clearInterval(simulateWindowResize);
        }, 1000);
    }

    sidebarOpen() {
        var toggleButton = this.toggleButton;
        var html = document.getElementsByTagName('html')[0];
        setTimeout(function () {
            toggleButton.classList.add('toggled');
        }, 500);
        const mainPanel = <HTMLElement>document.getElementsByClassName('main-panel')[0];
        if (window.innerWidth < 991) {
            mainPanel.style.position = 'fixed';
        }
        html.classList.add('nav-open');
        this.sidebarVisible = true;
    }
    sidebarClose() {
        var html = document.getElementsByTagName('html')[0];
        this.toggleButton.classList.remove('toggled');
        this.sidebarVisible = false;
        html.classList.remove('nav-open');
        const mainPanel = <HTMLElement>document.getElementsByClassName('main-panel')[0];

        if (window.innerWidth < 991) {
            setTimeout(function () {
                mainPanel.style.position = '';
            }, 500);
        }
    }
    sidebarToggle() {
        // var toggleButton = this.toggleButton;
        // var body = document.getElementsByTagName('body')[0];
        if (this.sidebarVisible == false) {
            this.sidebarOpen();
        } else {
            this.sidebarClose();
        }
    }

    getTitle() {
        var titlee = this.location.prepareExternalUrl(this.location.path());
        if (titlee.charAt(0) === '#') {
            titlee = titlee.slice(2);
        }
        for (var item = 0; item < this.listTitles.length; item++) {
            var parent = this.listTitles[item];
            if (parent.path === titlee) {
                return parent.title;
            } else if (parent.children) {
                var children_from_url = titlee.split("/")[2];
                for (var current = 0; current < parent.children.length; current++) {
                    if (parent.children[current].path === children_from_url) {
                        return parent.children[current].title;
                    }
                }
            } else {

            }
        }
        return localStorage.getItem('page_title');
    }

    getPath() {
        // console.log(this.location);
        return this.location.prepareExternalUrl(this.location.path());
    }

    goBack() {
        this.location.back();
    }

}