import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { KPIReportsService } from '../kpi-reports.service';
import { Location } from '@angular/common';
import swal from 'sweetalert2';
import * as jquery from 'jquery';


@Component({
  selector: 'app-create-kpi',
  templateUrl: './create-kpi.component.html',
  styleUrls: ['./create-kpi.component.css']
})
export class CreateKpiComponent implements OnInit {
  projectId: any;
  sub: any;
  KPIResponseObj : any;
  KPIdetailsResponseObj: any;
  AssessmentResponseObj: any;
  KPINameObj: any;
  isLoading: boolean = false;
  edit: String;
  isDisabled: boolean = false;
  createKPIObj = {
    assessment_category:'',
    performance_indicator: '',
    priority: '',
    time: '',
    time_format: '',
    weightage: '',
    data: ''
  }
  priority = [];
  time = [];
  time_format = [];
  kpi: String;
  disableInput: boolean;
  AssessmentCategories = [];
  PerformanceIndicator = [];
  issueTypeList = [];

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,private kpiService: KPIReportsService,private _location: Location) { 
    
  }

  ngOnInit() {
    this.initIssues();
    console.log(this.AssessmentCategories);
    localStorage.setItem('page_title', 'Reports');
    this.titleService.setTitle('Reports - Asset Management Tool');
    this.sub = this.route.queryParams.subscribe(params => {
        this.projectId = params['project'];
        this.kpi = params['id'] || '';
        this.edit = params['edit'] || '';
    });

    if (this.edit == 'create'){
      this.disableInput = false;
    }

    

    this.getAssessmentCategoryObj();
    this.getKPI();
    this.getKPIdetails();
    this.getKPINames();
    this.priority = [
      1.1, 1.2
    ]
    this.time_format = [
      'Hours', "Days"
    ]

    // jquery('.js-example-basic-single').select2();
  }


  getKPINames(){
    this.kpiService.getKPINames().subscribe(res => {
      this.isLoading = false;
      this.KPINameObj = res;
    });
  }
  

  getAssessmentCategoryObj(){
    this.kpiService.getAssessmentCategory().subscribe(res => {
      this.isLoading = false;
      this.AssessmentResponseObj = res;
    });
  }
  
  getKPI(){
    this.kpiService.getKPIs().subscribe(res => {
      this.isLoading = false;
      this.KPIResponseObj = res;
    });
  }

  addKPI(){
    console.log(this.createKPIObj);
    if (this.createKPIObj.assessment_category == '') {
      this.showErrorMsg('Please enter assessment category');
      return;
    }

    if (this.createKPIObj.performance_indicator == '') {
      this.showErrorMsg('Please enter performance indicator');
      return;
    }

    if (this.createKPIObj.priority == '') {
      this.showErrorMsg('Please enter priority');
      return;
    }

    if (this.createKPIObj.time == '') {
      this.showErrorMsg('Please enter time');
      return;
    }

    if (this.createKPIObj.time_format == '') {
      this.showErrorMsg('Please enter time format');
      return;
    }

    if (this.createKPIObj.weightage == '') {
      this.showErrorMsg('Please enter weightage');
      return;
    }
    console.log(this.createKPIObj.weightage);
    console.log(this.isNumber(this.createKPIObj.weightage));

    if (!this.isNumber(this.createKPIObj.weightage)){
      this.showErrorMsg('Please enter a number for weightage');
      return;
    }

    if (!this.isNumber(this.createKPIObj.time)){
      this.showErrorMsg('Please enter a number for time');
      return;
    }

    this.isLoading = true;
    this.kpiService.addKPI(this.createKPIObj).subscribe(res => {
      this.isLoading = false;
      swal(
        {
          title: 'Successful!',
          text: "KPI Created Successfully!",
          type: 'success',
          confirmButtonClass: "btn btn-success",
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this._location.back();
        }
      })
    } ,err => {
      swal({
        type: 'warning',
        html: err.error._error_message,
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      });
  });

  }

  getKPIdetails(){
    
    this.kpiService.getKPIdetails(this.kpi).subscribe(res => {
      this.isLoading = false;
      // this.edit = true;
      this.isDisabled = true;
      this.KPIResponseObj = res;
      this.createKPIObj.performance_indicator = this.KPIResponseObj[0]['performance_indicator'];
      this.createKPIObj.assessment_category = this.KPIResponseObj[0]['assessment_category']['assessment_category'];
      this.createKPIObj.weightage = this.KPIResponseObj[0]['weightage'];
      this.createKPIObj.data = this.KPIResponseObj[0]['data'];
   
    });
  }
  

  showErrorMsg(msg: any) {
    swal({
      type: 'warning',
      html: msg,
      confirmButtonClass: 'btn btn-success',
      buttonsStyling: false
    })
  }

  onPerformanceIndicatorSelected(PerformanceIndicator: any){
    this.createKPIObj.performance_indicator = PerformanceIndicator;
  }

  onAssessmentCategorySelected(AssessmentCategory: any){
    this.createKPIObj.assessment_category = AssessmentCategory;
    // this.createIssue.inspection_category = selectedInsCategory;
    var assessmentCatId;
    this.AssessmentCategories.forEach((item, index) => {
      if (item.name == AssessmentCategory) {
        assessmentCatId = item.id;
      }
    });
    this.issueTypeList = [];
    this.PerformanceIndicator.forEach((item, index) => {
      if (item.inspec_id == assessmentCatId) {
        this.issueTypeList.push(item);
      }
    });
    this.createKPIObj.performance_indicator = this.issueTypeList[0].name;
    // this.onIssueCategorySelected(this.createKPIObj.assessment_category);
  }

  onPrioritySelected(Priority: any){
    this.createKPIObj.priority = Priority;
    var dd = this.createKPIObj.data;
  }

  onFormatSelected(TimeFormat: any){
    this.createKPIObj.time_format = TimeFormat;
  }

  editKPI(id: String){
    this.createKPIObj.performance_indicator = (document.getElementById("performance_indicator") as HTMLTextAreaElement).value;
    this.createKPIObj.assessment_category = (document.getElementById("assessment_category")as HTMLTextAreaElement).value;
    this.createKPIObj.time = (document.getElementById("time")as HTMLTextAreaElement).value
    this.createKPIObj.time_format = (document.getElementById("time_format")as HTMLTextAreaElement).value
    this.createKPIObj.weightage = (document.getElementById("weightage")as HTMLTextAreaElement).value
    this.createKPIObj.priority = (document.getElementById("priority")as HTMLTextAreaElement).value

    this.kpiService.editKPI(this.createKPIObj, id).subscribe(res => {
      swal(
        {
          title: 'Successful!',
          text: "KPI Updated Successfully!",
          type: 'success',
          confirmButtonClass: "btn btn-success",
          buttonsStyling: false
        }
      )
    });
   
  }

  deactivateKPI(id: String, type: String){
    this.kpiService.deactivateKPI(id).subscribe(res => {
      console.log(type);
      if (type=="deactivate"){
        var msg = "KPI Deactivated!";
      }
      else if (type=="activate"){
        var msg = "KPI Activated!";
      }
      swal(
        {
          title: 'Successful!',
          text: msg,
          type: 'success',
          confirmButtonClass: "btn btn-success",
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          window.location.reload();
        }
      })

    });
  }

  isNumber(n) { return /^-?[\d.]+(?:e-?\d+)?$/.test(n); } 


  initIssues(){

    this.AssessmentCategories = [
      {
          id: 1,
          name: 'Maintenance - Main Carriageway, and Service Road'
      },
      {
          id: 2,
          name: 'Road Furniture'
      },
      {
          id: 3,
          name: 'Structure'
      },
      {
        id: 4,
        name: 'Road Safety'
      },
      {
        id: 5,
        name: 'Landscaping/Planting'
      },
      {
        id: 6,
        name: 'General upkeep/Housekeeping'
      },
      {
        id: 7,
        name: 'Reporting Compliance'
      }

    ]

    this.PerformanceIndicator = [
      { id: 1, inspec_id: 1, name: 'Pothole' },
      { id: 2, inspec_id: 1, name: 'Cracking' },
      { id: 3, inspec_id: 1, name: 'Rutting' },
      { id: 4, inspec_id: 1, name: 'Corrugations and Shoving' },
      { id: 5, inspec_id: 1, name: 'Bleeding' },
      { id: 6, inspec_id: 1, name: 'Ravelling/Stripping' },
      { id: 7, inspec_id: 1, name: 'Edge Deformation/Breaking' },
      { id: 8, inspec_id: 1, name: 'Edge Drop at shoulders' },
      { id: 9, inspec_id: 1, name: 'Embankment Slopes' },
      { id: 10, inspec_id: 1, name: 'Embankment Protection' },
      { id: 11, inspec_id: 1, name: 'Camber/Cross-fall at shoulders' },
      // 
      { id: 12, inspec_id: 2, name: 'Road Markings' },
      { id: 13, inspec_id: 2, name: 'Signages (Cautionary,Mandatory Information, etc.)' },
      { id: 14, inspec_id: 2, name: 'Signages (Gantry/Cantilever Sign Boards)' },
      { id: 15, inspec_id: 2, name: 'Highway Lights' },
      { id: 16, inspec_id: 2, name: 'Toll Plaza Canopy Lights' },
      { id: 17, inspec_id: 2, name: 'Kerb' },
      { id: 18, inspec_id: 2, name: 'Reflective Pavement Markers(Road Studs)' },
      { id: 19, inspec_id: 2, name: 'Guard Rails, MBCB, Crash Barriers and Boundary/Km stones etc' },
      // 
      { id: 20, inspec_id: 3, name: 'Bridges-Riding quality or user comfort' },
      { id: 21, inspec_id: 3, name: 'Bumps' },
      { id: 22, inspec_id: 3, name: 'User safety (condition of crash barrier and guard rail)' },
      { id: 23, inspec_id: 3, name: 'Debris and dust in strip seal expansion joint' },
      { id: 24, inspec_id: 3, name: 'Drainage spouts' },
      // 
      // { id: 25, inspec_id: 4, name: 'Safety Compliance' },
      { id: 25, inspec_id: 4, name: 'PPE'},
      { id: 26, inspec_id: 4, name: 'Work Zone Safety'},
      { id: 27, inspec_id: 4, name: 'Work permit not available'},
      { id: 28, inspec_id: 4, name: 'SOP not available'},
      { id: 29, inspec_id: 4, name: 'Work in buffer zone'},
      { id: 30, inspec_id: 4, name: 'Any Other'},
      // 
      { id: 31, inspec_id: 5, name: 'Watering the Plants and Trees' },
      { id: 32, inspec_id: 5, name: 'Trimming of the Plants' },
      { id: 33, inspec_id: 5, name: 'Removal of all sort of obstructions' },
      { id: 34, inspec_id: 5, name: 'Maintaining vegetation' },
      { id: 35, inspec_id: 5, name: 'Replacement of decayed Plants and Trees' },
      // 
      { id: 36, inspec_id: 6, name: 'Cleaning of Main Carriageway (MCW)' },
      { id: 37, inspec_id: 6, name: 'Cleaning of Service Road (SR)' },
      { id: 38, inspec_id: 6, name: 'Cleaning of Toll Collection Building' },
      { id: 39, inspec_id: 6, name: 'Cleaning of Rest Area (if any)' },
      { id: 40, inspec_id: 6, name: 'Cleaning of Public Toilets' },
      { id: 41, inspec_id: 6, name: 'Cleaning of open and Covered Drains' },
      { id: 42, inspec_id: 6, name: 'Petty repair to railings, Parapet wall and Footpath & Ducts etc' },
      // 
      { id: 43, inspec_id: 7, name: 'Daily/ Routine Inspection Report'},
      { id: 44, inspec_id: 7, name: 'Monthly Status/ Inspection Report'},
      { id: 45, inspec_id: 7, name: 'Test Reports'},
      { id: 46, inspec_id: 7, name: 'Remedial measures report'},
      { id: 47, inspec_id: 7, name: 'Daily Reports of Unusual Occurrence'},
      { id: 48, inspec_id: 7, name: 'Weekly Reports of Unusual Occurrence'},
      { id: 49, inspec_id: 7, name: 'Monthly Reports of Unusual Occurrence'},

    
    ]
  
  }


}



