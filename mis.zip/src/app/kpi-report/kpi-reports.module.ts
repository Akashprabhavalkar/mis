import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { KpiReportComponent } from './kpi-report.component';
import { KPIReportsRoutingModule } from './kpi-reports-routing.module';
import { KPIReportsRoutes } from './kpi-reports.routing';
import { CreateKpiComponent } from './create-kpi/create-kpi.component';
import { ExportReportComponent } from './export-report/export-report.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(KPIReportsRoutes),
    KPIReportsRoutingModule,
    NgxDaterangepickerMd.forRoot(),
    FormsModule
  ],
  declarations: [KpiReportComponent, CreateKpiComponent, ExportReportComponent]
})
export class KPIReportsModule { }