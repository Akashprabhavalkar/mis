import { KpiReportComponent } from './kpi-report.component';

describe('KPIReportsModule', () => {
  let kpireportsModule: KpiReportComponent;

  beforeEach(() => {
    kpireportsModule = new KpiReportComponent();
  });
  it('should create an instance', () => {
    expect(kpireportsModule).toBeTruthy();
  });
});
