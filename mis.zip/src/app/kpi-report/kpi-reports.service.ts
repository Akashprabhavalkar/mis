import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class KPIReportsService {
    constructor(private http: HttpClient) { }


    getAssessmentCategory() {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/kpi/assessment_category", options)
    }

    getKPIs() {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/kpi", options)
    }

    addKPI(KPIObj: any){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        var payload =
            {
                assessment_category: KPIObj.assessment_category,
                performance_indicator: KPIObj.performance_indicator,
                priority: KPIObj.priority,
                time: KPIObj.time,
                time_format: KPIObj.time_format,
                weightage: KPIObj.weightage
            }
        return this.http.post(environment.BASE_URL + "api/v1/kpi", payload, options)
    }

    getKPIdetails(kpi: String){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/kpi?performance_indicator="+kpi, options)
    }

    getKPINames(){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/kpi/kpis", options)
    }

    getContractors(projectId: String) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/memberships/contractor?project=" + projectId, options)
    }

    editKPI(KPIObj: any, id: String){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        var payload = 
            {
                assessment_category: KPIObj.assessment_category,
                performance_indicator: KPIObj.performance_indicator,
                priority: KPIObj.priority,
                time: KPIObj.time,
                time_format: KPIObj.time_format,
                weightage: KPIObj.weightage
            }
        return this.http.put(environment.BASE_URL + "api/v1/kpi/"+id, payload, options)
    }
    
    deactivateKPI(id: String){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.delete(environment.BASE_URL + "api/v1/kpi/"+id , options)
    }

    reportQuery(defect_type: String, start_date: any, end_date: any, contractor: any, exportType: any){
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': localStorage.getItem('auth_token')
        });
        let options = { headers: headers };
        return this.http.get(environment.BASE_URL + "api/v1/kpi/reports?defect_type="+ defect_type + "&start_date=" + start_date + "&end_date=" + end_date + "&contractor=" + contractor+"&export="+exportType, options)
    }
}

