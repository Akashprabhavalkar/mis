import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { KPIReportsService } from './kpi-reports.service';

@Component({
  selector: 'app-kpi-report',
  templateUrl: './kpi-report.component.html',
  styleUrls: ['./kpi-report.component.css']
})
export class KpiReportComponent implements OnInit {
  projectId: any;
  statusId: String = '';
  sub: any;
  KPIResponseObj: any;
  AssessmentResponseObj: any;
  isLoading: boolean = false;
  kpi: String;
  
  
  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private kpiService: KPIReportsService) {
  }

  ngOnInit() {
    localStorage.setItem('page_title', 'Reports');
    this.titleService.setTitle('Reports - Asset Management Tool');
    this.sub = this.route.queryParams.subscribe(params => {
        this.projectId = params['project'];
        this.statusId = params['statusId'] || '';
        this.kpi = params['id'] || '';
    });

    this.getKPI();
  }
  
 

  onAddClicked(type: String) {
    this._router.navigate(['/create-kpi'], { queryParams: { project: this.projectId, type: type, edit:'create' } });
  }

  openKPIDetails(kpi: String){
    this._router.navigate(['/create-kpi'], { queryParams: { project: this.projectId, type: 'KPI', id: kpi, edit:'edit' } });

  }

  goToReport(kpi: String){
    this._router.navigate(['/export-kpi'], { queryParams: { project: this.projectId, type: 'KPI', id: kpi } });
  }

  generateScoreard(kpi: String){
    this._router.navigate(['/export-kpi'], { queryParams: { project: this.projectId, type: 'KPI', id: kpi } });
  }

  

  getProjectTitle() {
    let projectTitle = localStorage.getItem('project_title') || '';
    return projectTitle;
  }

  getKPI(){
    this.kpiService.getKPIs().subscribe(res => {
      this.isLoading = false;
      this.KPIResponseObj = res;
      
    });
  }

  
  
}
