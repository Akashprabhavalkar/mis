import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { KPIReportsService } from '../kpi-reports.service';
import { environment } from '../../../environments/environment';
import * as moment from 'moment';
declare var swal: any;
import * as jquery from 'jquery';
import { container } from '@angular/core/src/render3/instructions';

@Component({
  selector: 'app-export-report',
  templateUrl: './export-report.component.html',
  styleUrls: ['./export-report.component.css']
})
export class ExportReportComponent implements OnInit {
  projectId: any;
  statusId: String = '';
  sub: any;
  isLoading: boolean = false;
  kpi: String;
  selectedFromDate: any;
  selectedToDate: any;
  maxDate: any;
  startDate: any;
  endDate: any;
  // KPIResponseObj: [];
  KPIResponseObj:any = [];
  selectedType: String = '';
  isReportGenerated: boolean = false;
  isScorecardGenerated: boolean = false;
  contractor: String = '';
  exportType: String = '';
  downloadURL: String = '';
  defect_type: String = '';
  KPINameObj: any;
  performance_indicator: any;
  contractorList:any = [];
  monthList = [];
  yearList = [];

  constructor(private _router: Router,
    private titleService: Title,
    private route: ActivatedRoute,
    private kpiService: KPIReportsService) {
      this.maxDate = moment();
      this.selectedFromDate = moment();
      this.selectedToDate = moment();
      this.startDate = moment();
      this.endDate = moment();
     }

  ngOnInit() {
    
    localStorage.setItem('page_title', 'Reports');
    this.titleService.setTitle('Reports - Asset Management Tool');
    this.sub = this.route.queryParams.subscribe(params => {
        this.projectId = params['project'];
        this.statusId = params['statusId'] || '';
        this.kpi = params['id'] || '';
    });

    this.getContractorList()
    this.selectedType = 'kpi';
    this.getKPINames();

  }

  getKPINames(){
    this.kpiService.getKPINames().subscribe(res => {
      this.isLoading = false;
      this.KPINameObj = res;
    });
  }

  getProjectTitle() {
    let projectTitle = localStorage.getItem('project_title') || '';
    return projectTitle;
  }

  onExportProjectClicked(type: String){
    this.selectedType = type;

  }

  showErrorMsg(msg: any) {
    swal({
      type: 'warning',
      html: msg,
      confirmButtonClass: 'btn btn-success',
      buttonsStyling: false
    })
  }

  reportQuery(defect_type){
    var startDateString = this.startDate.format('YYYY-MM-DD');
    var endDateString = this.endDate.format('YYYY-MM-DD');
    this.kpiService.reportQuery(this.kpi, startDateString, endDateString, this.contractor, '').subscribe(res => {
      this.isLoading = false;
      this.isReportGenerated = false;
      this.KPIResponseObj = res;
      
    },
    err => {
        swal({
        type: 'warning',
        html: err.error._error_message,
        confirmButtonClass: 'btn btn-success',
        buttonsStyling: false
      })
    });
  }

  onPerformanceIndicatorSelected(performance_indicator){
    this.kpi = performance_indicator;
    this.reportQuery(this.kpi);
  }

  getContractorList() {
    this.kpiService.getContractors(this.projectId).subscribe(res => {
      this.contractorList = res;
    },
      err => {
      }
    );
  }

  fromDateChange(res) {
    if (res.startDate != null) {
        var newStartDate = res.startDate;
        if (newStartDate.isAfter(this.endDate)) {
            this.showErrorMsg('Please select valid from date');
        } else {
            if (this.kpi == "Scorecard"){
              this.isScorecardGenerated = true;
            }
            else{
              this.startDate = newStartDate;
              this.reportQuery(this.kpi);
            }
        }
    }
}

  toDateChange(res) {
    if (res.endDate != null) {
        var newEndDate = res.endDate;
        if (newEndDate.isBefore(this.startDate)) {
            this.showErrorMsg('Please select valid to date');
        } else {
            this.endDate = newEndDate;
            this.reportQuery(this.kpi);
        }
    }
  }


  onContractorSelected(contractor: any) {
   
    if (this.kpi == "Scorecard"){
      this.isScorecardGenerated = true;
    }
    else{
      this.contractor = contractor;
      this.reportQuery(this.kpi);  
    }
  }


  onExportCsvOrPdf(exportType){
    var startDateString = this.startDate.format('YYYY-MM-DD');
    var endDateString = this.endDate.format('YYYY-MM-DD');
    this.downloadURL = environment.BASE_URL + "api/v1/kpi/reports?defect_type="+ this.kpi + "&start_date=" + startDateString + "&end_date=" + endDateString + "&contractor=" + this.contractor+"&export=CSV"
  }

  onClicked(){
    var startDateString = this.startDate.format('YYYY-MM-DD');
    // var endDateString = this.endDate.format('YYYY-MM-DD');
    console.log(startDateString)
    console.log(this.contractor)

    if (startDateString == ''){
      this.showErrorMsg('Please select Month');
    }

    if (this.contractor == '') {
      this.showErrorMsg('Please select contractor');
    }
    this.downloadURL = environment.BASE_URL + "api/v1/kpi/reports?defect_type="+ this.kpi + "&start_date=" + startDateString + "&end_date=" + "&contractor=" + this.contractor+"&export=Scorecard"
    // this.downloadURL = environment.BASE_URL + "api/v1/kpi/reports?defect_type="+ this.kpi + "&start_date=" + startDateString + "&end_date=" + endDateString + "&contractor=" + this.contractor+"&export=Scorecard"
    console.log(this.downloadURL);
  }

}
