import { Routes } from '@angular/router';
import { KpiReportComponent } from './kpi-report.component';
import { CreateKpiComponent } from './create-kpi/create-kpi.component';
import { ExportReportComponent } from './export-report/export-report.component';


export const KPIReportsRoutes: Routes = [{
    path: 'kpi-reports',
    children: [{
        path: '',
        component: KpiReportComponent
    }]
}, {
    path: 'create-kpi',
    children: [{
        path: '',
        component: CreateKpiComponent
    }]
}, {
    path: 'export-kpi',
    children: [{
        path: '',
        component: ExportReportComponent
    }]
}];